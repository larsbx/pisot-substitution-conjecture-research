#!/usr/bin/env python3
"""Run the unchanged acceptance gate, retaining exact-revision process evidence."""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path('/workspace/scratch/f96c28a561ad')
REPO = BASE / 'psc-compact'
LOG = BASE / 'compact-isolated-lean.log'
RECEIPT = BASE / 'compact-isolated-process.json'

def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()

if git('status', '--porcelain'):
    raise SystemExit('Refusing exact-revision acceptance from a dirty worktree.')
subject = git('rev-parse', 'HEAD')
tree = git('rev-parse', 'HEAD^{tree}')
paths = sorted(set(git('ls-files', 'proof/PscVerif', 'tools/check_lean.sh',
    'tools/setup_lean.sh', 'tools/make_proof_bank.py', 'proof/proof-bank.json',
    'claim_governance.toml').splitlines()))
sources = {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in paths}
env = os.environ.copy()
env['ELAN_HOME'] = '/workspace/scratch/84c835820757/toolchains/elan'
env['PATH'] = env['ELAN_HOME'] + '/bin:' + env['PATH']
env['TMPDIR'] = str(BASE / 'lean-isolation-tmp')
Path(env['TMPDIR']).mkdir(exist_ok=True)
receipt = {'schema': 'c4-compact-isolated-process-v1', 'subject_revision': subject,
    'subject_tree': tree, 'started_at_utc': now(), 'command': ['./tools/check_lean.sh'],
    'working_directory': str(REPO), 'log': str(LOG), 'source_sha256': sources,
    'status': 'running', 'acceptance_complete': False}
RECEIPT.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'subject_revision': subject, 'tree': tree, 'status': 'running'}), flush=True)
start = time.monotonic()
with LOG.open('wb') as log:
    run = subprocess.run(['./tools/check_lean.sh'], cwd=REPO, env=env,
        stdout=log, stderr=subprocess.STDOUT)
post_sources = {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in paths}
stable = git('rev-parse', 'HEAD') == subject and git('rev-parse', 'HEAD^{tree}') == tree
stable = stable and not git('status', '--porcelain') and post_sources == sources
receipt.update(ended_at_utc=now(), elapsed_seconds=round(time.monotonic()-start, 3),
    exit_code=run.returncode, unchanged_head_tree_and_sources=stable,
    log_bytes=LOG.stat().st_size, log_sha256=hashlib.sha256(LOG.read_bytes()).hexdigest(),
    status='passed' if run.returncode == 0 and stable else 'failed',
    acceptance_complete=run.returncode == 0 and stable)
RECEIPT.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'source_sha256'}), flush=True)
print('\n'.join(LOG.read_text().splitlines()[-8:]), flush=True)
raise SystemExit(0 if receipt['acceptance_complete'] else (run.returncode or 1))
