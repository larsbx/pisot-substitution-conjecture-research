# Interrupted compact-neighborhood gate: attempt 01

This archive preserves the original raw log, original process receipt and
runner bytes after the root agent reported session 25398 returned
"Unknown process id" at approximately 18:36 UTC on 2026-11-12.

**Terminal outcome: unknown. No complete gate acceptance is established.**
The original receipt is retained unchanged: its status still says running,
acceptance_complete is false, and it contains no terminal exit code. This
archive does not rewrite that historical receipt into either a pass or a
mathematical failure.

The raw log records progress through job 9021/9023 and build-success markers
for all three new modules. It contains no PSC_AUDIT_COMPLETE marker, compiled
axiom records or final audit acknowledgement. Partial build progress cannot
replace the required aggregate build, compiled audit and terminal process
receipt. The session-loss mechanism and actual process exit are not established
by this preservation.

The source subject remains code 6915e8d592b7ea5cb7c6950249811e354dc6c3e7,
tree c79e97bdae1224068895afa9dcf6cca6d7fe9fbb. observation.json records the
snapshot times, original file metadata, byte hashes, reported tool error and
limits of the observations. The active source files were not overwritten.

A separately authorized retained-workspace diagnostic is owned by measure_route.
Such segmented work is supplemental and does not satisfy the existing unchanged
checker/finalizer acceptance contract. Root owns any fresh full rerun.

A fresh runner may emit JSON heartbeats to its own stdout every 20 seconds while
leaving child stdout/stderr exclusively in the raw binary log. This makes liveness
visible and avoids a fully silent wrapper. It does not prove the cause of this
session loss or guarantee survival of a server-side session-duration limit.
The retry wrapper and attempt02 paths are separate from this historical archive.
No build, retry, compiler, CI request or finalization was launched by preservation.
