"""Bounded source/object-bound scratch consumer probes; never rebuild imports."""
from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/91efcf4b7b58/psc')
PROJECT = ROOT / 'proof/PscVerif'
LEAN = Path('/tmp/psc-lean/bin/lean')
variant = sys.argv[1]
if variant not in {'Baseline', 'LocalDepth', 'Selectors'}:
    raise SystemExit('Expected Baseline, LocalDepth, or Selectors')
SOURCE = OUT / f'{variant}.lean'
RUN = OUT / variant
RUN.mkdir()
OBJECT = RUN / f'{variant}.olean'
TERMINAL = OUT.parent / 'carrier1-split-terminal.json'
HANDOFF = OUT.parent / 'carrier1-success-audit-handoff.json'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

terminal = json.loads(TERMINAL.read_text())
handoff = json.loads(HANDOFF.read_text())
assert terminal['status'] == 'passed' and terminal['compiler_returncode'] == 0
assert terminal['source_unchanged'] and terminal['object_exists']
assert digest(Path(handoff['source_path'])) == handoff['source_sha256']
assert digest(Path(handoff['object_path'])) == terminal['object_sha256'] == handoff['object_sha256']
assert digest(LEAN) == 'e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
assert re.findall(r'^import (.+)$', SOURCE.read_text(), re.M) == ['PscVerif.NamedForwardCarrierData1']

sys.path.insert(0, str(ROOT / 'tools'))
from make_proof_bank import lean_code

paths = [PROJECT / '.lake/build/lib/lean']
paths += sorted(path / '.lake/build/lib/lean'
                for path in (PROJECT / '.lake/packages').iterdir() if path.is_dir())
external_paths = paths[1:] + [LEAN.parent.parent / 'lib/lean']
modules, external, pending = set(), set(), ['PscVerif.NamedForwardCarrierData1']
while pending:
    module = pending.pop()
    if module in modules:
        continue
    modules.add(module)
    source = (PROJECT / Path(*module.split('.'))).with_suffix('.lean')
    imports = re.findall(r'(?m)^\s*(?:public\s+)?import\s+([^\s]+)\s*$', lean_code(source.read_text()))
    for imported in imports:
        if imported.startswith('PscVerif.'):
            pending.append(imported)
        else:
            external.add(imported)
assert 'PscVerif.NamedStrictExclusion' not in modules
inputs = {SOURCE, Path(__file__).resolve(), TERMINAL, HANDOFF, LEAN,
          ROOT / 'tools/make_proof_bank.py',
          PROJECT / 'lean-toolchain', PROJECT / 'lakefile.toml', PROJECT / 'lake-manifest.json',
          LEAN.parent.parent / 'lib/lean/Lean/Util/CollectAxioms.olean'}

def include_objects(obj):
    assert obj.is_file(), obj
    inputs.add(obj)
    for suffix in ('.private', '.server'):
        extra = Path(str(obj) + suffix)
        if extra.is_file():
            inputs.add(extra)

for module in modules:
    relative = Path(*module.split('.'))
    inputs.add((PROJECT / relative).with_suffix('.lean'))
    include_objects((PROJECT / '.lake/build/lib/lean' / relative).with_suffix('.olean'))
boundaries = []
for module in sorted(external):
    relative = Path(*module.split('.')).with_suffix('.olean')
    found = [directory / relative for directory in external_paths if (directory / relative).is_file()]
    assert len(found) == 1, (module, found)
    include_objects(found[0])
    boundaries.append({'module': module, 'object_path': str(found[0]), 'object_sha256': digest(found[0])})

def snapshot():
    return {str(p): {'sha256': digest(p), 'bytes': p.stat().st_size} for p in sorted(inputs)}

before = snapshot()
env = {k: v for k, v in os.environ.items() if not k.startswith('LEAN_')}
env['LEAN_PATH'] = os.pathsep.join(map(str, paths))
env['LEAN_NUM_THREADS'] = '2'
command = ['stdbuf', '-oL', '-eL', str(LEAN), '--root=' + str(OUT), '--profile', '-j', '2',
           '-DElab.async=false', '-Dtrace.Kernel=true', '-o', str(OBJECT), str(SOURCE)]
receipt = {
    'schema': 'psc-consumer-depth-probe-v1', 'variant': variant,
    'scope': 'Focused fixture-1 conversion probe with actual cached Data1; empty unclaimed fixture-0 carrier branch',
    'full_isolated_acceptance': False, 'termination_claimed': False,
    'repository_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'local_import_closure': sorted(modules), 'external_boundary_objects': boundaries,
    'external_dependency_transitive_objects_all_hashed': False,
    'input_scope': 'Complete local import-closure sources and olean/private/server objects; direct external boundary objects, compiler, selected core inputs, dependency manifest; external cached transitive objects remain explicit trust inputs',
    'input_files': before, 'command': command, 'cwd': str(PROJECT),
    'environment': {k: env[k] for k in ('LEAN_PATH', 'LEAN_NUM_THREADS')},
    'compiler_version': subprocess.check_output([str(LEAN), '--version'], text=True).strip(),
    'wall_guard_seconds': 600, 'rss_guard_bytes': 4000000000,
    'sample_interval_seconds': 0.25, 'maximum_sampled_rss_bytes': 0,
    'stop_reason': None, 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
}
(RUN / 'start.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
(RUN / 'INPUTS.sha256').write_text(''.join(f"{v['sha256']}  {p}\n" for p, v in before.items()))
started = time.monotonic()
with (RUN / 'compile.log').open('xb') as log, (RUN / 'resources.jsonl').open('x') as resources:
    process = subprocess.Popen(command, cwd=PROJECT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    while process.poll() is None:
        elapsed = time.monotonic() - started
        try:
            rss = int(Path(f'/proc/{process.pid}/statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
        except (FileNotFoundError, ProcessLookupError):
            rss = 0
        receipt['maximum_sampled_rss_bytes'] = max(receipt['maximum_sampled_rss_bytes'], rss)
        resources.write(json.dumps({'elapsed_seconds': elapsed, 'rss_bytes': rss}) + '\n')
        resources.flush()
        reason = ('rss_guard' if rss >= receipt['rss_guard_bytes'] else
                  'wall_guard' if elapsed >= receipt['wall_guard_seconds'] else
                  'requested_stop' if (RUN / 'STOP').exists() else None)
        if reason:
            receipt['stop_reason'] = reason
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
            break
        time.sleep(0.25)
    receipt['compiler_returncode'] = process.wait()
receipt['elapsed_seconds'] = round(time.monotonic() - started, 6)
receipt['ended_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
receipt['input_bytes_unchanged'] = snapshot() == before
receipt['source_sha256'] = digest(SOURCE)
receipt['object_exists'] = OBJECT.is_file()
receipt['object_sha256'] = digest(OBJECT) if OBJECT.is_file() else None
receipt['compile_log_sha256'] = digest(RUN / 'compile.log')
receipt['resources_sha256'] = digest(RUN / 'resources.jsonl')
lines = (RUN / 'compile.log').read_text().splitlines()
audited = {}
for line in lines:
    if line.startswith('PSC_CONSUMER_AXIOMS\t'):
        fields = line.split('\t')
        assert len(fields) == 3 and fields[1] not in audited
        audited[fields[1]] = sorted(filter(None, fields[2].split(',')))
expected = {'Psc.ConsumerDepthProbe.check_fixture1', 'Psc.GeneratedForwardCarrier.fixture1ForwardCheck'}
receipt['audited_theorems'] = audited
receipt['axiom_audit_passed'] = (set(audited) == expected
    and all(set(a) <= {'propext', 'Classical.choice', 'Quot.sound'} for a in audited.values())
    and lines.count('PSC_CONSUMER_COMPLETE\t2') == 1)
receipt['maximum_recursion_error_present'] = any('maximum recursion depth' in line for line in lines)
receipt['status'] = ('passed' if receipt['compiler_returncode'] == 0 and receipt['stop_reason'] is None
    and receipt['input_bytes_unchanged'] and receipt['object_exists'] and receipt['axiom_audit_passed'] else 'failed')
(RUN / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
(RUN / 'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in sorted(RUN.iterdir())
    if p.is_file() and p.name != 'SHA256SUMS'))
print(json.dumps({k: receipt[k] for k in ('variant', 'status', 'compiler_returncode', 'elapsed_seconds',
    'maximum_sampled_rss_bytes', 'stop_reason', 'object_exists', 'object_sha256', 'source_sha256',
    'input_bytes_unchanged', 'maximum_recursion_error_present', 'axiom_audit_passed')}, indent=2, sort_keys=True))
raise SystemExit(0 if receipt['status'] == 'passed' else 1)
