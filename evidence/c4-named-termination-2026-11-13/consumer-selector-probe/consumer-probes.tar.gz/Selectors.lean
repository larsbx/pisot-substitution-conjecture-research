import PscVerif.NamedForwardCarrierData1

/- Focused consumer conversion probe. The unused fixture-0 carrier is empty
only to avoid importing its absent local object; no fixture-0 claim is made.
The literal substitution table and fixture-1 carrier/proof are unchanged. -/
namespace Psc.ConsumerDepthProbe

def sigma0 : Fin 3 → List (Fin 3) := ![[1], [0, 2, 1], [0, 0, 1]]
def sigma1 : Fin 3 → List (Fin 3) := ![[1], [0, 1, 2], [0, 0, 1]]
def substitution (fixture : Fin 2) : Fin 3 → List (Fin 3) := ![sigma0, sigma1] fixture

def check (fixture : Fin 2) (states : List (List (Fin 3) × List (Fin 3))) : Bool :=
  Psc.ForwardCarrier.check (substitution fixture) states

noncomputable def checkedStates (fixture : Fin 2) : List (List (Fin 3) × List (Fin 3)) :=
  ![[], Psc.GeneratedForwardCarrier.fixture1States] fixture

theorem check_fixture1 : check 1 (checkedStates 1) = true := by
  simp only [check, checkedStates, substitution,
    Matrix.cons_val_one, Matrix.cons_val_zero]
  exact Psc.GeneratedForwardCarrier.fixture1ForwardCheck

end Psc.ConsumerDepthProbe

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  if env.header.moduleNames.contains `PscVerif.NamedStrictExclusion then
    throwError "Unexpected NamedStrictExclusion import"
  let names := #[`Psc.ConsumerDepthProbe.check_fixture1,
    `Psc.GeneratedForwardCarrier.fixture1ForwardCheck]
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  for name in names do
    let some info := env.find? name | throwError "Missing audit theorem: {name}"
    if !info.isTheorem then throwError "Audit declaration is not a theorem: {name}"
    let axioms ← collectAxioms name
    for ax in axioms do
      if !allowed.contains ax then throwError "Nonstandard axiom in {name}: {ax}"
    liftIO <| IO.println s!"PSC_CONSUMER_AXIOMS\t{name}\t{String.intercalate "," (axioms.toList.map toString)}"
  liftIO <| IO.println "PSC_CONSUMER_COMPLETE\t2"
