"""Preserve the second independent hosted consumer failure at its exact source."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile
import zipfile

BASE = Path(__file__).resolve().parent
REPO = BASE.parent / 'psc'
OUT = BASE.parent / 'hosted-fulllean-failed-6021f042'
TAR = OUT.with_suffix('.tar.gz')
SOURCE = '6021f042056d3cb0f9717d2488144339721c2071'
TREE = '3355716258114a4f5353b10233fa1fa79bb34bbd'
RUN, JOB, ARTIFACT = 43435276869, 131918630728, 14053920825


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parsed(name):
    return json.loads((BASE / name).read_text())


def source_blob(name):
    return subprocess.check_output(['git', 'show', SOURCE + ':' + name], cwd=REPO)


run = parsed('fulllean-run-poll-04.provider.json')
jobs = parsed('fulllean-jobs-poll-04.provider.json')['jobs']
artifacts = parsed('fulllean-terminal-artifacts.provider.json')['artifacts']
assert run['id'] == RUN and run['head_sha'] == SOURCE and run['run_attempt'] == 1
assert run['status'] == 'completed' and run['conclusion'] == 'failure'
assert len(jobs) == 1 and jobs[0]['id'] == JOB
job = jobs[0]
assert job['head_sha'] == SOURCE and job['run_attempt'] == 1
assert job['status'] == 'completed' and job['conclusion'] == 'failure'
failed = [step for step in job['steps'] if step['conclusion'] == 'failure']
assert len(failed) == 1 and failed[0]['name'] == 'Compile from isolated sources and audit every local declaration'
assert len(artifacts) == 1 and artifacts[0]['id'] == ARTIFACT
metadata = artifacts[0]
assert metadata['workflow_run']['id'] == RUN and metadata['workflow_run']['head_sha'] == SOURCE
zip_path = BASE / 'fulllean-43435276869-6021f042.zip'
data = zip_path.read_bytes()
assert metadata['digest'] == 'sha256:' + sha(data)
assert metadata['size_in_bytes'] == len(data) == 4533
log_path = BASE / 'fulllean-failed-artifact/c4-overlap-lean-audit.log'
with zipfile.ZipFile(io.BytesIO(data)) as archive:
    assert archive.namelist() == ['c4-overlap-lean-audit.log']
    assert archive.read(archive.namelist()[0]) == log_path.read_bytes()
log = log_path.read_text()
job_log_path = BASE / 'fulllean-terminal-job-log.log'
job_log = job_log_path.read_text()
error = 'error: PscVerif/NamedForwardCarrier.lean:77:4: maximum recursion depth has been reached'
for marker in ['Built PscVerif.NamedForwardCarrierData1 (558s)',
               'Built PscVerif.NamedForwardCarrierData0 (986s)', error]:
    assert marker in log and marker in job_log
assert 'Process completed with exit code 1.' in job_log
consumer_path = 'proof/PscVerif/PscVerif/NamedForwardCarrier.lean'
assert source_blob(consumer_path).decode().splitlines()[76] == '  · change Psc.ForwardCarrier.check'
commit = subprocess.check_output(['git', 'cat-file', 'commit', SOURCE], cwd=REPO)
assert hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest() == SOURCE
assert commit.splitlines()[0] == ('tree ' + TREE).encode()

OUT.mkdir(exist_ok=False)
(OUT / 'artifact').mkdir()
(OUT / 'rest').mkdir()
shutil.copyfile(zip_path, OUT / zip_path.name)
shutil.copyfile(log_path, OUT / 'artifact/c4-overlap-lean-audit.log')
shutil.copyfile(job_log_path, OUT / 'job.log')
shutil.copyfile(BASE / 'fulllean-terminal-job-log.json', OUT / 'job-provider-response.json')
for name in ['fulllean-run-poll-04.provider.json', 'fulllean-jobs-poll-04.provider.json',
             'fulllean-terminal-artifacts.provider.json']:
    shutil.copyfile(BASE / name, OUT / 'rest' / name)
acquisition = {}
for name in ['fulllean-run-poll-04.json', 'fulllean-jobs-poll-04.json',
             'fulllean-terminal-artifacts.json']:
    wrapper = parsed(name)
    acquisition[name] = {key: wrapper[key] for key in ('retrieved_at_utc', 'url')}
(OUT / 'rest/acquisition.json').write_text(json.dumps(acquisition, indent=2, sort_keys=True) + '\n')
source_paths = [consumer_path, run['path'], 'tools/check_lean.sh']
for name in source_paths:
    path = OUT / 'source' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(source_blob(name))
(OUT / 'source/commit.raw').write_bytes(commit)
shutil.copyfile(Path(__file__), OUT / 'assemble_failed_fulllean_packet.py')
review = {
    'schema': 'psc-hosted-failed-fulllean-preservation-v1',
    'source_commit': SOURCE, 'source_tree': TREE,
    'run_id': RUN, 'job_id': JOB, 'run_attempt': 1, 'artifact_id': ARTIFACT,
    'workflow_conclusion': 'failure', 'overall_formal_acceptance': False,
    'compiled_axiom_audit_completed': False, 'termination_claimed': False,
    'zip_sha256': sha(data), 'zip_bytes': len(data),
    'extracted_log_matches_original_zip': True,
    'raw_provider_run_job_artifact_exact_source_agree': True,
    'artifact_has_source_hash_inventory': False,
    'compiled_objects_retained': False,
    'reported_successful_modules': [
        {'module': 'PscVerif.NamedForwardCarrierData1', 'reported_seconds': 558},
        {'module': 'PscVerif.NamedForwardCarrierData0', 'reported_seconds': 986},
    ],
    'observed_failure': error,
    'failed_step': failed[0],
    'failure_classification': 'compiler recursion-depth error in consumer elaboration, followed by build exit1',
    'same_run_did_not_report_timeout_or_cancellation': True,
    'local_lean_invocations_in_this_review': 0,
    'source_files': {name: sha(source_blob(name)) for name in source_paths},
    'audit_log_sha256': sha(log_path.read_bytes()),
    'job_log_sha256': sha(job_log_path.read_bytes()),
}
(OUT / 'review.json').write_text(json.dumps(review, indent=2, sort_keys=True) + '\n')
(OUT / 'README.md').write_text("""# Failed hosted full Lean gate at 6021f042

This packet preserves GitHub Actions run 43435276869, attempt 1, job
131918630728, at exact source 6021f042056d3cb0f9717d2488144339721c2071
(tree 3355716258114a4f5353b10233fa1fa79bb34bbd).

The run reported successful compilation of NamedForwardCarrierData1
(558 seconds) and NamedForwardCarrierData0 (986 seconds). It then failed
at NamedForwardCarrier.lean line 77 with "maximum recursion depth has been
reached", followed by build exit 1. The same consumer diagnostic was also
observed in the separate archived-payload run 43435276766; that run has its
own preserved evidence packet. Neither failure was reported as a timeout.

This packet contains the original 4,533-byte ZIP, its single audit log,
raw REST run/job/artifact metadata, the full decoded job log and provider
response, exact source consumer/workflow/gate blobs and commit identity,
plus the executed preservation review code and receipt.

The ZIP digest and byte size match raw provider metadata. Its log matches
the extracted bytes. Run, job and artifact metadata agree on source and run
identity. The artifact contains no compiled object or source hash inventory.
Reported module compilation does not establish completed whole-repository
acceptance or the missing compiled axiom audit. No termination acceptance
is claimed, and no local Lean compiler was invoked for this review.

SHA256SUMS covers the retained files other than itself; review.json records
the checks. The enclosing tar has sorted entries, zero timestamps and fixed
owner/mode fields. Earlier evidence is unchanged.
""")
files = sorted(path for path in OUT.rglob('*') if path.is_file())
(OUT / 'SHA256SUMS').write_text(''.join(
    f'{sha(path.read_bytes())}  {path.relative_to(OUT).as_posix()}\n' for path in files))
with TAR.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for path in sorted(path for path in OUT.rglob('*') if path.is_file()):
            data = path.read_bytes()
            info = tarfile.TarInfo(path.relative_to(OUT).as_posix())
            info.size, info.mode = len(data), 0o644
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            tar.addfile(info, io.BytesIO(data))
with tarfile.open(TAR, 'r:gz') as archive:
    for member in archive.getmembers():
        assert archive.extractfile(member).read() == (OUT / member.name).read_bytes()
assembly = {
    'packet_directory': str(OUT), 'tar_path': str(TAR),
    'tar_sha256': sha(TAR.read_bytes()), 'tar_bytes': TAR.stat().st_size,
    'manifest_sha256': sha((OUT / 'SHA256SUMS').read_bytes()), 'manifest_entries': len(files),
    'archive_all_members_verified': True,
}
(BASE / 'failed-fulllean-packet-assembly.json').write_text(json.dumps(assembly, indent=2, sort_keys=True) + '\n')
print(json.dumps(assembly, indent=2, sort_keys=True))
