"""Authorized deterministic addition of the missing unpublished inner manifest."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

OUT = Path(__file__).resolve().parent
EVIDENCE = Path('/workspace/scratch/91efcf4b7b58/psc/evidence/c4-named-termination-2026-11-13')
TARGET = EVIDENCE / 'local-fixture0-sigkill-1ce54efe/local-failure-evidence.tar.gz'
README = TARGET.parent / 'README.md'
EXPECTED_OLD = '855460ef5e97096b692acaa539f3ca53c11787fe67a1135776be7b6ed353545a'

def sha(data):
    return hashlib.sha256(data).hexdigest()

old = TARGET.read_bytes()
assert sha(old) == EXPECTED_OLD
original_copy = OUT / 'original-local-failure-evidence.tar.gz'
with original_copy.open('xb') as stream:
    stream.write(old)
other_before = {str(p): sha(p.read_bytes()) for p in sorted(EVIDENCE.rglob('*.tar.gz')) if p != TARGET}
with tarfile.open(fileobj=io.BytesIO(old), mode='r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == 8 and all(m.isfile() for m in members)
    assert len({m.name for m in members}) == 8
    original = {m.name: archive.extractfile(m).read() for m in members}
assert 'SHA256SUMS' not in original
contents = dict(original)
contents['SHA256SUMS'] = ''.join(f'{sha(data)}  {name}\n'
    for name, data in sorted(original.items())).encode()

def encode():
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(contents.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            member.uid = member.gid = 0
            member.uname = member.gname = ''
            member.mtime = 0
            archive.addfile(member, io.BytesIO(data))
    result = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=result, compresslevel=9, mtime=0) as stream:
        stream.write(tar_buffer.getvalue())
    return result.getvalue()

new = encode()
assert new == encode()
with tarfile.open(fileobj=io.BytesIO(new), mode='r:gz') as archive:
    reconstructed = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
assert reconstructed == contents
assert all(reconstructed[name] == data for name, data in original.items())
readme_before = README.read_bytes()
assert readme_before.count(EXPECTED_OLD.encode()) == 1
readme_after = readme_before.replace(EXPECTED_OLD.encode(), sha(new).encode())
temporary = TARGET.with_suffix(TARGET.suffix + '.review-new')
with temporary.open('xb') as stream:
    stream.write(new)
temporary.replace(TARGET)
README.write_bytes(readme_after)
assert other_before == {str(p): sha(p.read_bytes()) for p in sorted(EVIDENCE.rglob('*.tar.gz')) if p != TARGET}
receipt = {
    'schema': 'psc-unpublished-local-failure-manifest-repair-v1',
    'authorization': 'Parent requested preserving all eight original member bytes, adding a complete inner SHA256SUMS and deterministic metadata, updating only the outer README archive hash.',
    'archive_path': str(TARGET), 'old_archive_sha256': sha(old), 'new_archive_sha256': sha(new),
    'old_archive_bytes': len(old), 'new_archive_bytes': len(new),
    'original_archive_copy': str(original_copy),
    'original_member_hashes': {name: sha(data) for name, data in sorted(original.items())},
    'all_eight_original_member_bytes_preserved': True,
    'added_manifest_sha256': sha(contents['SHA256SUMS']),
    'manifest_entries': 8, 'deterministic_reencode_byte_equal': True,
    'metadata': {'tar_format': 'PAX', 'uid': 0, 'gid': 0, 'uname': '', 'gname': '',
                 'mtime': 0, 'mode': '0644', 'member_order': 'lexicographic',
                 'gzip_mtime': 0, 'gzip_filename': '', 'gzip_compresslevel': 9},
    'outer_readme_sha256_before': sha(readme_before), 'outer_readme_sha256_after': sha(readme_after),
    'outer_readme_change': 'exact single old archive hash replaced with new hash',
    'other_four_archive_hashes': other_before, 'other_four_archives_unchanged': True,
    'status': 'passed',
}
(OUT / 'repair-receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: receipt[key] for key in ('status', 'old_archive_sha256', 'new_archive_sha256',
    'old_archive_bytes', 'new_archive_bytes', 'all_eight_original_member_bytes_preserved',
    'other_four_archives_unchanged')}, indent=2, sort_keys=True))
