"""Read-only evidence/member/hash/sensitive-text review; execute no packet code."""
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit, parse_qsl
from collections import Counter
import base64
import hashlib
import io
import json
import os
import re
import stat
import subprocess
import tarfile
import time
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/91efcf4b7b58/psc')
EVIDENCE = ROOT / 'evidence/c4-named-termination-2026-11-13'
BASELINE = '1ce54efeff586ecda2ec1bd11a2f9c6617b2fb87'
problems, findings, archives, text_sources = [], [], [], []
text_count, text_bytes, binary_count = 0, 0, 0
url_hosts, query_keys = Counter(), Counter()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def safe_path(name):
    p = PurePosixPath(name)
    return (bool(name) and not p.is_absolute() and '\\' not in name
        and not any(ord(c) < 32 or ord(c) == 127 for c in name)
        and not any(part in {'.', '..'} for part in name.rstrip('/').split('/'))
        and str(p) == name.rstrip('/') and not re.match(r'^[A-Za-z]:', name))

def manifests(files, label):
    results = []
    for name in sorted(n for n in files if PurePosixPath(n).name == 'SHA256SUMS'):
        parent = str(PurePosixPath(name).parent)
        prefix = '' if parent == '.' else parent + '/'
        expected = {n for n in files if n.startswith(prefix) and n != name}
        bound = {}
        for line in files[name].decode('utf-8').splitlines():
            match = re.fullmatch(r'([0-9a-f]{64}) [ *](.+)', line)
            if not match or not safe_path(match[2]):
                problems.append(f'{label}:{name}: malformed/unsafe manifest entry')
                continue
            digest, relative = match.groups()
            target = prefix + relative
            if target in bound:
                problems.append(f'{label}:{name}: duplicate manifest target {relative}')
            bound[target] = digest
            if target not in files or sha(files[target]) != digest:
                problems.append(f'{label}:{name}: absent/hash-mismatched target {relative}')
        missing, extra = expected - set(bound), set(bound) - expected
        if missing or extra:
            problems.append(f'{label}:{name}: incomplete manifest missing={sorted(missing)} extra={sorted(extra)}')
        results.append({'path': name, 'sha256': sha(files[name]), 'entries': len(bound),
                        'expected_files': len(expected), 'complete': not missing and not extra})
    return results

patterns = {
    'private_key': r'-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
    'github_token': r'\b(?:github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9]{30,})\b',
    'gitlab_token': r'\bglpat-[A-Za-z0-9_-]{20,}\b',
    'slack_token': r'\bxox[baprs]-[A-Za-z0-9-]{20,}\b',
    'openai_key': r'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}\b',
    'aws_access_id': r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'google_api_key': r'\bAIza[0-9A-Za-z_-]{35}\b',
    'jwt': r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b',
    'azure_account_key': r'(?i)AccountKey\s*=\s*[A-Za-z0-9+/]{30,}={0,2}',
    'authorization_header': r'(?i)\bauthorization["\x27]?\s*[:=]\s*["\x27]?(?:Bearer|Basic|token)\s+([^\s"\x27,;]+)',
    'credential_assignment': r'(?i)\b(?:api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret|password|gh_token|github_token)["\x27]?\s*[:=]\s*["\x27]?([^"\x27\s,;]+)',
}
placeholder = re.compile(r'^(?:\*+|<.*|\$.*|\{.*|None|null|true|false|os\..*|environ.*|secrets\..*|YOUR_.*|TOKEN|token|password|secret|changeme)$', re.I)
url_pattern = re.compile(r'https?://[^\s<>"\x27`]+')
signed_keys = {'x-amz-signature', 'x-amz-credential', 'x-amz-security-token', 'x-goog-signature',
               'x-goog-credential', 'sig', 'signature', 'awsaccesskeyid',
               'access_token', 'auth_token', 'token', 'api_key', 'apikey', 'key-pair-id', 'policy'}

def scan_text(label, text):
    for kind, pattern in patterns.items():
        for match in re.finditer(pattern, text):
            value = match[1] if match.lastindex else match[0]
            if kind in {'credential_assignment', 'authorization_header'} and placeholder.fullmatch(value):
                continue
            findings.append({'source': label, 'kind': kind,
                             'line': text.count('\n', 0, match.start()) + 1,
                             'matched_characters': len(value)})
    for match in url_pattern.finditer(text):
        try:
            url = urlsplit(match[0].rstrip(').,;]'))
            url_hosts[url.hostname or '<missing-host>'] += 1
            fields = parse_qsl(url.query, keep_blank_values=True)
            query_keys.update(k.lower() for k, _ in fields)
            flagged = sorted({k.lower() for k, v in fields if k.lower() in signed_keys and v})
            if flagged or url.username is not None or url.password is not None:
                findings.append({'source': label, 'kind': 'signed_or_credential_url',
                                 'line': text.count('\n', 0, match.start()) + 1,
                                 'host': url.hostname, 'query_keys': flagged,
                                 'userinfo_present': url.username is not None or url.password is not None})
        except ValueError:
            findings.append({'source': label, 'kind': 'unparseable_url',
                             'line': text.count('\n', 0, match.start()) + 1})

def json_strings(value, label, depth=0):
    if depth > 6:
        return
    if isinstance(value, dict):
        if value.get('encoding') == 'base64' and isinstance(value.get('content'), str):
            try:
                scan_text(label + '#decoded-base64-content', base64.b64decode(value['content']).decode('utf-8'))
            except (ValueError, UnicodeDecodeError):
                pass
        for key, child in value.items():
            json_strings(child, label + '#' + str(key), depth + 1)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            json_strings(child, label + '#' + str(i), depth + 1)
    elif isinstance(value, str):
        scan_text(label, value)
        if value.lstrip().startswith(('{', '[')):
            try:
                json_strings(json.loads(value), label + '#nested-json', depth + 1)
            except ValueError:
                pass

def scan_file(label, data):
    global text_count, text_bytes, binary_count
    try:
        if b'\0' in data:
            raise UnicodeDecodeError('utf-8', data, 0, 1, 'binary NUL')
        text = data.decode('utf-8-sig')
    except UnicodeDecodeError:
        binary_count += 1
        return
    text_count += 1
    text_bytes += len(data)
    scan_text(label, text)
    if label.endswith('.json'):
        try:
            json_strings(json.loads(text), label)
        except ValueError:
            pass

archive_paths = sorted(EVIDENCE.rglob('*.tar.gz'))
assert len(archive_paths) == 5
before = {str(p): sha(p.read_bytes()) for p in archive_paths}
for path in archive_paths:
    label = str(path.relative_to(ROOT))
    data = path.read_bytes()
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        members = archive.getmembers()
        names = [m.name for m in members]
        if len(names) != len(set(names)) or len({n.rstrip('/') for n in names}) != len(names):
            problems.append(label + ': duplicate member path')
        for member in members:
            if not safe_path(member.name) or not (member.isfile() or member.isdir()):
                problems.append(label + ': unsafe member ' + member.name)
        files = {m.name: archive.extractfile(m).read() for m in members if m.isfile()}
        manifest_results = manifests(files, label)
        if not any(m['path'] == 'SHA256SUMS' for m in manifest_results):
            problems.append(label + ': missing root SHA256SUMS')
        nested = []
        for name, content in sorted(files.items()):
            if not name.endswith('.zip'):
                scan_file(label + '!' + name, content)
                continue
            with zipfile.ZipFile(io.BytesIO(content)) as zip_archive:
                infos = zip_archive.infolist()
                zip_names = [m.filename for m in infos]
                if len(zip_names) != len(set(zip_names)):
                    problems.append(label + '!' + name + ': duplicate ZIP member')
                zip_files = {}
                for member in infos:
                    mode = stat.S_IFMT(member.external_attr >> 16)
                    if (not safe_path(member.filename) or member.flag_bits & 1
                            or mode not in {0, stat.S_IFREG, stat.S_IFDIR}):
                        problems.append(label + '!' + name + ': unsafe ZIP member ' + member.filename)
                    if not member.is_dir():
                        zip_files[member.filename] = zip_archive.read(member)
                prefix = 'native-artifact/' if 'hosted-native-' in label else 'artifact/'
                for zip_name, zip_data in zip_files.items():
                    if files.get(prefix + zip_name) != zip_data:
                        problems.append(label + '!' + name + ': extracted copy mismatch ' + zip_name)
                    scan_file(label + '!' + name + '!' + zip_name, zip_data)
                nested.append({'path': name, 'sha256': sha(content), 'regular_files': len(zip_files),
                               'manifest_checks': manifests(zip_files, label + '!' + name),
                               'extracted_copies_byte_identical': all(files.get(prefix + n) == d for n, d in zip_files.items())})
        archives.append({'path': label, 'sha256': sha(data), 'bytes': len(data),
                         'members': len(members), 'regular_files': len(files),
                         'directories': sum(m.isdir() for m in members),
                         'safe_regular_or_directory_members_only': all(safe_path(m.name) and (m.isfile() or m.isdir()) for m in members),
                         'manifests': manifest_results, 'nested_zips': nested})

prepared = EVIDENCE / 'prepared-inspector'
prepared_files = {str(p.relative_to(prepared)): p.read_bytes() for p in sorted(prepared.rglob('*')) if p.is_file()}
assert all(not p.is_symlink() for p in prepared.rglob('*'))
prepared_manifest = manifests(prepared_files, 'prepared-inspector')
assert len(prepared_manifest) == 1
for name, data in prepared_files.items():
    scan_file('prepared-inspector/' + name, data)
for readme in sorted(EVIDENCE.glob('*/README.md')):
    scan_file(str(readme.relative_to(ROOT)), readme.read_bytes())

historical = []
assert subprocess.check_output(['git', 'rev-parse', '--show-object-format'], cwd=ROOT, text=True).strip() == 'sha1'
tree = subprocess.check_output(['git', 'ls-tree', '-r', '-z', BASELINE, '--', 'evidence'], cwd=ROOT)
for entry in tree.split(b'\0'):
    if not entry:
        continue
    meta, raw_name = entry.split(b'\t', 1)
    mode, kind, object_id = meta.decode().split()
    name = raw_name.decode()
    path = ROOT / name
    if kind != 'blob' or not (path.exists() or path.is_symlink()):
        problems.append('historical evidence absent or unsupported: ' + name)
        continue
    data = os.readlink(path).encode() if mode == '120000' else path.read_bytes()
    actual = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    if actual != object_id:
        problems.append('historical evidence changed: ' + name)
    actual_mode = '120000' if path.is_symlink() else '100755' if path.stat().st_mode & 0o111 else '100644'
    if mode != actual_mode:
        problems.append('historical evidence mode changed: ' + name)
    historical.append({'path': name, 'sha256': sha(data), 'git_blob': object_id, 'mode': mode, 'bytes': len(data)})
historical_manifest = ''.join(f"{r['sha256']}  {r['path']}\n" for r in historical).encode()
(OUT / 'historical-evidence.sha256').write_bytes(historical_manifest)
after = {str(p): sha(p.read_bytes()) for p in archive_paths}
if before != after:
    problems.append('one or more archives changed during review')
if findings:
    problems.append('sensitive-text candidate findings require classification')
receipt = {
    'schema': 'psc-consumer-selector-evidence-review-v1',
    'reviewed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    'reviewer_script_sha256': sha(Path(__file__).read_bytes()),
    'status': 'passed' if not problems else 'needs_review', 'problems': problems,
    'archives': archives, 'archive_bytes_unchanged_during_review': before == after,
    'prepared_inspector': {'regular_files': len(prepared_files), 'manifest': prepared_manifest},
    'historical_evidence': {'baseline_commit': BASELINE, 'tracked_files_checked': len(historical),
        'bytes_checked': sum(r['bytes'] for r in historical), 'manifest_sha256': sha(historical_manifest),
        'all_content_and_modes_unchanged': not any('historical evidence' in p for p in problems)},
    'sensitive_text': {'text_payloads_scanned': text_count, 'utf8_bytes_scanned': text_bytes,
        'binary_payloads_skipped': binary_count, 'decoded_json_strings_and_base64_source_content_scanned': True,
        'patterns': sorted(patterns), 'signed_url_keys': sorted(signed_keys),
        'url_host_counts': dict(sorted(url_hosts.items())), 'url_query_key_counts': dict(sorted(query_keys.items())),
        'candidate_findings': findings,
        'limitation': 'Pattern and URL-structure audit of UTF-8 text, not a general secret-detection proof; binary executable/object contents are not audited as text.'},
    'executed_packet_code': False, 'lean_or_native_runs': False,
    'review_scope_excludes_pending_parent_readme_and_parent_manifest': True,
}
(OUT / 'verification-receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
summary = {k: receipt[k] for k in ('status', 'problems', 'archive_bytes_unchanged_during_review', 'prepared_inspector', 'historical_evidence')}
summary['sensitive_text_counts'] = {'text_payloads': text_count, 'utf8_bytes': text_bytes, 'binary_payloads_skipped': binary_count, 'candidate_findings': findings}
print(json.dumps(summary, indent=2, sort_keys=True))
raise SystemExit(0 if not problems else 1)
