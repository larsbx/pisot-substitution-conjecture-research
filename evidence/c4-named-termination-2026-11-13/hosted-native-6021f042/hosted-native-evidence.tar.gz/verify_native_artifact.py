from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/91efcf4b7b58/psc')
ARTIFACT = OUT / 'native-artifact'
SOURCE = '6021f042056d3cb0f9717d2488144339721c2071'
MERGE = '1ce54efeff586ecda2ec1bd11a2f9c6617b2fb87'
TREE = '3355716258114a4f5353b10233fa1fa79bb34bbd'
sha = lambda data: hashlib.sha256(data).hexdigest()


def hashes(path):
    entries = {}
    for line in path.read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert re.fullmatch('[0-9a-f]{64}', digest)
        assert name not in entries and '\n' not in name and '\x00' not in name
        entries[name] = digest
    return entries


run = json.loads((OUT / 'native-run-raw.provider.json').read_text())
jobs = json.loads((OUT / 'native-jobs-raw.provider.json').read_text())
metadata = json.loads((OUT / 'native-artifacts-raw.provider.json').read_text())
assert run['id'] == 43435276378 and run['run_attempt'] == 1
assert run['head_sha'] == SOURCE and run['status'] == 'completed' and run['conclusion'] == 'success'
assert jobs['total_count'] == 1 and len(jobs['jobs']) == 1
job = jobs['jobs'][0]
assert job['id'] == 131918634454 and job['run_attempt'] == 1 and job['head_sha'] == SOURCE
assert job['status'] == 'completed' and job['conclusion'] == 'success'
assert all(step['status'] == 'completed' and step['conclusion'] == 'success' for step in job['steps'])
assert metadata['total_count'] == 1 and len(metadata['artifacts']) == 1
archive_metadata = metadata['artifacts'][0]
assert archive_metadata['id'] == 14047853947 and archive_metadata['workflow_run']['head_sha'] == SOURCE
assert archive_metadata['workflow_run']['id'] == run['id'] and not archive_metadata['expired']
archive = OUT / 'native-43435276378-6021f042.zip'
assert 'sha256:' + sha(archive.read_bytes()) == archive_metadata['digest']
assert archive.stat().st_size == archive_metadata['size_in_bytes']

manifest = hashes(ARTIFACT / 'SHA256SUMS')
for name, digest in manifest.items():
    path = Path(name)
    assert not path.is_absolute() and '..' not in path.parts
    assert sha((ARTIFACT / path).read_bytes()) == digest, name
assert {p.relative_to(ARTIFACT).as_posix() for p in ARTIFACT.rglob('*') if p.is_file()} == set(manifest) | {'SHA256SUMS'}

sources = hashes(ARTIFACT / 'SOURCES.sha256')
assert len(sources) == 763
cat = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
try:
    for name, digest in sources.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        cat.stdin.write((SOURCE + ':' + name + '\n').encode())
        cat.stdin.flush()
        header = cat.stdout.readline().decode().strip().split()
        assert len(header) == 3 and header[1] == 'blob', (name, header)
        content = cat.stdout.read(int(header[2]))
        assert cat.stdout.read(1) == b'\n'
        assert sha(content) == digest, name
finally:
    cat.stdin.close()
    assert cat.wait() == 0
for revision in (SOURCE, MERGE):
    assert subprocess.check_output(['git', 'rev-parse', revision + '^{tree}'], cwd=ROOT, text=True).strip() == TREE

receipt = json.loads((ARTIFACT / 'replay-receipt.json').read_text())
assert receipt['status'] == 'passed' and receipt['exit_code'] == 0
assert receipt['revision'] == {'commit': SOURCE, 'tree': TREE}
assert receipt['build_mode'] == 'pixi-locked-build' and receipt['binaries_built_by_this_gate']
assert receipt['source_bytes_unchanged_during_replay']
assert receipt['archived_packets_reproduced_byte_for_byte'] and receipt['lean_sources_reproduced_byte_for_byte']
assert receipt['lean_kernel_acceptance'] is False and receipt['productivity_claimed'] is False
assert receipt['infinitude_claimed_from_caps'] is False
assert receipt['compiler']['installed_package_metadata_matches_lock'] is True
assert receipt['compiler']['lock_sha256'] == sources['kernel/pixi.lock']
assert receipt['compiler']['binary_sha256'] == '0d5f0b700b0543223a10c47e818bc4f43f3228166c34ab13d52ab7f2ad02ffcd'
for phase in ('before', 'after'):
    assert (ARTIFACT / f'revision-{phase}.stdout.log').read_text().splitlines() == [SOURCE, TREE]
    assert (ARTIFACT / f'worktree-{phase}.stdout.log').read_bytes() == b''
binary_hashes = hashes(ARTIFACT / 'BINARIES.sha256')
for binary in receipt['binaries'].values():
    assert binary_hashes[binary['path']] == binary['sha256']
    assert sha((ARTIFACT / Path(binary['path']).name).read_bytes()) == binary['sha256']
for index in (0, 1):
    assert sha((ARTIFACT / f'fixture{index}.json').read_bytes()) == sources[f'evidence/c4-forward-carrier-2026-11-12/fixture{index}.json']
    for kind in ('Words', 'Data'):
        name = f'NamedForwardCarrier{kind}{index}.lean'
        assert sha((ARTIFACT / name).read_bytes()) == sources[f'proof/PscVerif/PscVerif/{name}']
assert receipt['lean_source_files'] == [f'NamedForwardCarrier{kind}{i}.lean' for i in (0, 1) for kind in ('Words', 'Data')]
for command in receipt['commands']:
    if command['name'] in ('fixture0-length-cap-refusal', 'fixture0-state-cap-refusal'):
        assert command['exit_code'] != 0 and (ARTIFACT / command['stdout']).read_bytes() == b''
    else:
        assert command['exit_code'] == 0, command['name']
for refusal in receipt['budget_refusals']:
    assert refusal['stdout_empty'] and refusal['exit_code'] != 0
    command = next(row for row in receipt['commands'] if row['name'] == refusal['command'])
    assert f"budget exhausted (kind={refusal['expected_exhaustion_kind']})" in (ARTIFACT / command['stderr']).read_text()
assert len(receipt['budget_refusals']) == 2
assert '258 passed in 32.56s' in (ARTIFACT / 'oracle-tests.stdout.log').read_text()

oracle = ROOT / 'oracles/python/check_forward_carrier.py'
assert sha(oracle.read_bytes()) == sources['oracles/python/check_forward_carrier.py']
command = [sys.executable, '-B', '-O', str(oracle), str(ARTIFACT / 'fixture0.json'), str(ARTIFACT / 'fixture1.json')]
started = time.monotonic()
replay = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=True, timeout=120)
elapsed = time.monotonic() - started
assert not replay.stderr
(OUT / 'independent-oracle-recheck.json').write_text(replay.stdout)
fresh = json.loads(replay.stdout)
original = json.loads((ARTIFACT / 'oracle-receipt.json').read_text())
for candidate in (fresh, original):
    for packet in candidate['packets']:
        packet.pop('source_path')
assert fresh == original
result = {
    'schema': 'psc-hosted-native-artifact-review-v1',
    'status': 'passed', 'observed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    'source_commit': SOURCE, 'source_tree': TREE, 'merge_commit_with_same_tree': MERGE,
    'hosted_execution_is_on_source_commit_not_merge': True,
    'run_id': run['id'], 'job_id': job['id'], 'run_attempt': run['run_attempt'],
    'artifact_id': archive_metadata['id'], 'zip_sha256': sha(archive.read_bytes()),
    'manifest_file_count': len(manifest), 'source_blobs_verified_against_commit': len(sources),
    'all_four_generated_modules_match_source': True,
    'both_original_packets_match_source': True,
    'locked_build_recorded': True, 'native_test_count': 258,
    'hosted_gate_elapsed_seconds': receipt['elapsed_seconds'],
    'hosted_receipt_sha256': sha((ARTIFACT / 'replay-receipt.json').read_bytes()),
    'hosted_sources_sha256': sha((ARTIFACT / 'SOURCES.sha256').read_bytes()),
    'hosted_artifact_manifest_sha256': sha((ARTIFACT / 'SHA256SUMS').read_bytes()),
    'independent_oracle_recheck': {'command': command, 'elapsed_seconds': elapsed,
        'exit_code': replay.returncode, 'receipt_sha256': sha(replay.stdout.encode()),
        'matches_hosted_receipt_except_local_input_paths': True},
    'lean_kernel_acceptance': False, 'termination_claimed': False,
}
(OUT / 'native-verification.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
