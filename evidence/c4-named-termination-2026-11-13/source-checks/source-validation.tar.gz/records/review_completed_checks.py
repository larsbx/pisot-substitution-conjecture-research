"""Verify the actual double-quiet pytest output without rewriting the original receipt."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / 'psc'


def sha(data):
    return hashlib.sha256(data).hexdigest()


original = json.loads((OUT / 'terminal.json').read_text())
start = json.loads((OUT / 'start.json').read_text())
assert original['status'] == 'failed'
assert original['source_files_unchanged'] and not original['changed_source_paths']
assert original['source_file_count'] == len(start['source_files']) == 1960
assert original['source_manifest_sha256'] == sha((OUT / 'SOURCES.sha256').read_bytes())
assert original['runner_sha256'] == sha((OUT / 'run.py').read_bytes())
expected = {'claim-governance', 'ledger-check', 'proof-bank-check', 'proof-bank-tests',
            'vendored-pins', 'whitespace-index', 'whitespace-working-tree'}
assert {item['name'] for item in original['results']} == expected
for item in original['results']:
    assert item['returncode'] == 0
    assert item['log_sha256'] == sha((OUT / (item['name'] + '.log')).read_bytes())
    if item['name'] != 'proof-bank-tests':
        assert item['status'] == 'passed'
test = next(item for item in original['results'] if item['name'] == 'proof-bank-tests')
assert test['status'] == 'failed'
assert test['protocol_error'] == 'Expected all 57 existing proof-bank tests to pass'
log = (OUT / 'proof-bank-tests.log').read_text()
progress = re.fullmatch(r'(\.+)\s+\[100%\]', log.splitlines()[0])
assert progress and len(progress.group(1)) == 57
assert 'addopts = "-q"' in (ROOT / 'pyproject.toml').read_text()
assert '-q' in test['argv'] and '-k' not in test['argv'] and '-m' in test['argv']
for name, metadata in start['source_files'].items():
    assert sha((ROOT / name).read_bytes()) == metadata['sha256'], name
assert (OUT / 'proof-bank-check.log').read_text() == (
    'Proof bank: 126 claims, 3597 named Lean proofs, 411 source openings\n')
assert (OUT / 'ledger-check.log').read_text() == 'OK: 32 generated surfaces are current.\n'
assert 'passed [terminology, claims, coverage, promotion, numerics, consistency]' in (
    OUT / 'claim-governance.log').read_text()
review = {
    'schema': 'psc-consumer-selector-source-validation-log-review-v1',
    'reviewed_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'passed',
    'all_seven_requested_commands_returned_zero': True,
    'proof_bank_tests_passed': 57,
    'test_count_evidence': '57 pytest pass symbols followed by [100%], process exit0; project -q and CLI -q intentionally suppress the numeric summary',
    'original_wrapper_status': original['status'],
    'original_wrapper_protocol_error': test['protocol_error'],
    'original_receipts_and_logs_rewritten': False,
    'original_terminal_sha256': sha((OUT / 'terminal.json').read_bytes()),
    'original_start_sha256': sha((OUT / 'start.json').read_bytes()),
    'original_manifest_sha256': sha((OUT / 'SHA256SUMS').read_bytes()),
    'test_log_sha256': test['log_sha256'],
    'source_manifest_sha256': original['source_manifest_sha256'],
    'source_file_count': original['source_file_count'],
    'source_files_unchanged_during_checks_and_at_review': True,
    'consumer_sha256': start['source_files']['proof/PscVerif/PscVerif/NamedForwardCarrier.lean']['sha256'],
    'review_code_sha256': sha(Path(__file__).read_bytes()),
    'lean_invoked': False, 'native_gate_invoked': False,
}
with (OUT / 'review.json').open('x') as stream:
    json.dump(review, stream, indent=2, sort_keys=True)
    stream.write('\n')
(OUT / 'REVIEW.sha256').write_text(''.join(
    f'{sha((OUT / name).read_bytes())}  {name}\n'
    for name in ['review.json', 'review_completed_checks.py', 'SHA256SUMS']))
print(json.dumps(review, indent=2, sort_keys=True))
