"""Run requested source/governance checks without invoking Lean or native compilation."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / 'psc'


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def source_paths():
    names = subprocess.check_output(
        ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT
    ).decode().split('\0')
    prefixes = ('proof/', 'tools/', 'kernel/', 'reference/', 'oracles/',
                '.github/workflows/', 'docs/')
    explicit = {'tests/test_proof_bank.py', 'tests/conftest.py'}
    return sorted({name for name in names if name and (ROOT / name).is_file() and (
        name.startswith(prefixes) or name in explicit or (
            '/' not in name and Path(name).suffix in {'.toml', '.md', '.json', '.yaml', '.yml'}
        ))})


def snapshot():
    return {name: {'sha256': sha((ROOT / name).read_bytes()),
                   'bytes': (ROOT / name).stat().st_size} for name in source_paths()}


assert not (OUT / 'start.json').exists() and not (OUT / 'terminal.json').exists()
before = snapshot()
(OUT / 'SOURCES.sha256').write_text(''.join(
    f"{record['sha256']}  {name}\n" for name, record in before.items()))
(OUT / 'candidate.patch').write_bytes(subprocess.check_output(
    ['git', 'diff', '--binary', 'HEAD', '--', 'proof', 'tools', 'kernel', 'reference',
     'oracles', 'docs', '.github/workflows', 'tests/test_proof_bank.py'], cwd=ROOT))
python = sys.executable
jobs = [
    ('proof-bank-tests', [python, '-B', '-m', 'pytest', '--assert=plain', '-q', '-p', 'no:cacheprovider',
                          'tests/test_proof_bank.py'], {}),
    ('proof-bank-check', [python, '-B', 'tools/make_proof_bank.py', '--check'], {}),
    ('vendored-pins', [python, '-B', 'tools/vendoring/check_vendored_sync.py'], {}),
    ('ledger-check', [python, '-B', 'tools/make_ledger.py', '--check'], {}),
    ('claim-governance', [python, '-B', '-m', 'claim_governance.cli', '--root', '.'],
                         {'PYTHONPATH': 'tools'}),
    ('whitespace-working-tree', ['git', 'diff', '--check'], {}),
    ('whitespace-index', ['git', 'diff', '--cached', '--check'], {}),
]
start = {
    'schema': 'psc-consumer-selector-source-validation-v1',
    'started_utc': now(), 'cwd': str(ROOT),
    'head_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_hash_scope': 'all present tracked or unignored proof/tools/kernel/reference/oracles/workflow/docs files, selected test source and root text/config files; historical evidence archives are outside this source inventory',
    'source_files': before, 'source_manifest_sha256': sha((OUT / 'SOURCES.sha256').read_bytes()),
    'runner_sha256': sha(Path(__file__).read_bytes()),
    'candidate_patch_sha256': sha((OUT / 'candidate.patch').read_bytes()),
    'python_version': sys.version, 'lean_invoked': False, 'native_gate_invoked': False,
    'commands': [{'name': name, 'argv': command, 'environment_overrides': overrides}
                 for name, command, overrides in jobs],
}
write_json(OUT / 'start.json', start)


def run(job):
    name, command, overrides = job
    record = {'name': name, 'argv': command, 'cwd': str(ROOT), 'started_utc': now(),
              'environment_overrides': {'PYTHONDONTWRITEBYTECODE': '1', **overrides}}
    write_json(OUT / (name + '.start.json'), record)
    env = dict(os.environ)
    env.update(record['environment_overrides'])
    began = time.monotonic()
    with (OUT / (name + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    record.update({'terminal_utc': now(), 'elapsed_seconds': round(time.monotonic() - began, 6),
                   'returncode': result.returncode,
                   'log_sha256': sha((OUT / (name + '.log')).read_bytes()),
                   'status': 'passed' if result.returncode == 0 else 'failed'})
    if name == 'proof-bank-tests':
        match = re.search(r'(\d+) passed\b', (OUT / (name + '.log')).read_text())
        record['tests_passed'] = int(match.group(1)) if match else None
        if record['tests_passed'] != 57:
            record['status'] = 'failed'
            record['protocol_error'] = 'Expected all 57 existing proof-bank tests to pass'
    write_json(OUT / (name + '.terminal.json'), record)
    return record


began = time.monotonic()
results = []
with ThreadPoolExecutor(max_workers=len(jobs)) as pool:
    for future in as_completed([pool.submit(run, job) for job in jobs]):
        result = future.result()
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
after = snapshot()
changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
terminal = {
    'schema': start['schema'], 'started_utc': start['started_utc'], 'terminal_utc': now(),
    'elapsed_seconds': round(time.monotonic() - began, 6),
    'status': 'passed' if not changed and all(result['status'] == 'passed' for result in results) else 'failed',
    'results': sorted(results, key=lambda result: result['name']),
    'source_files_unchanged': not changed, 'changed_source_paths': changed,
    'source_file_count': len(before), 'source_manifest_sha256': start['source_manifest_sha256'],
    'runner_sha256': start['runner_sha256'],
    'lean_invoked': False, 'native_gate_invoked': False,
}
write_json(OUT / 'terminal.json', terminal)
(OUT / 'SHA256SUMS').write_text(''.join(
    f'{sha(path.read_bytes())}  {path.name}\n'
    for path in sorted(OUT.iterdir()) if path.is_file() and path.name != 'SHA256SUMS'))
print(json.dumps(terminal, indent=2, sort_keys=True), flush=True)
raise SystemExit(0 if terminal['status'] == 'passed' else 1)
