"""Preserve every original source-check record with a separate complete outer manifest."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import tarfile

WORK = Path('/workspace/scratch/91efcf4b7b58')
REPO = WORK / 'psc'
RECORDS = WORK / 'checks/consumer-selector-validation'
OUTPUT = REPO / 'evidence/c4-named-termination-2026-11-13/source-checks'
ARCHIVE = OUTPUT / 'source-validation.tar.gz'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def manifest_entries(data):
    rows = []
    seen = set()
    for line in data.decode().splitlines():
        digest, separator, name = line.partition('  ')
        assert separator and re.fullmatch(r'[0-9a-f]{64}', digest)
        path = PurePosixPath(name)
        assert name and not path.is_absolute() and '..' not in path.parts
        assert name not in seen
        seen.add(name)
        rows.append((digest, name))
    return rows


original = {}
for path in sorted(RECORDS.iterdir()):
    assert path.is_file() and not path.is_symlink(), path
    original[path.name] = path.read_bytes()
assert len(original) == 30
for name in ['SHA256SUMS', 'REVIEW.sha256']:
    for expected, member in manifest_entries(original[name]):
        assert member in original and sha(original[member]) == expected
source_manifest = manifest_entries(original['SOURCES.sha256'])
assert len(source_manifest) == 1960
for expected, name in source_manifest:
    assert sha((REPO / name).read_bytes()) == expected, name
start = json.loads(original['start.json'])
terminal = json.loads(original['terminal.json'])
review = json.loads(original['review.json'])
assert terminal['status'] == 'failed' and review['status'] == 'passed'
assert terminal['source_files_unchanged'] and not terminal['changed_source_paths']
assert review['source_files_unchanged_during_checks_and_at_review']
assert review['original_receipts_and_logs_rewritten'] is False
assert len(terminal['results']) == 7
assert all(result['returncode'] == 0 for result in terminal['results'])
assert review['original_terminal_sha256'] == sha(original['terminal.json'])
assert review['original_start_sha256'] == sha(original['start.json'])
assert review['original_manifest_sha256'] == sha(original['SHA256SUMS'])
assert review['test_log_sha256'] == sha(original['proof-bank-tests.log'])
assert review['source_manifest_sha256'] == sha(original['SOURCES.sha256'])
progress = original['proof-bank-tests.log'].decode().splitlines()[0]
match = re.fullmatch(r'(\.+)\s+\[100%\]', progress)
assert match and len(match.group(1)) == review['proof_bank_tests_passed'] == 57
assert not terminal['lean_invoked'] and not terminal['native_gate_invoked']

readme = """# Consumer selector repair: source-validation records

This unpublished packet preserves the source and governance checks for the
selector-only repair in NamedForwardCarrier.check_checkedStates. The checks
ran against a working tree based on commit
1ce54efeff586ecda2ec1bd11a2f9c6617b2fb87. The repaired consumer source is bound
by SHA-256 c825c41da424572c4014ecf2e1f6a80457f9265409c4fde6daf7f3cccd5137e7.
The candidate patch and complete recorded source hashes are retained.

## Results

All seven actual validation commands exited 0:

| Check | Observed result |
| --- | --- |
| Proof-bank tests | 57 passing test symbols, completed at 100%, exit 0; 85.192 seconds |
| Proof-bank consistency | 126 claims, 3,597 named Lean proofs, 411 source openings |
| Vendored package pins | All checked packages match their recorded pins |
| Generated ledger | All 32 generated surfaces are current |
| Claim governance | Terminology, claims, coverage, promotion, numerics, consistency all pass |
| Working-tree whitespace | Exit 0, empty diagnostic log |
| Staged whitespace | Exit 0, empty diagnostic log |

The exact argument vectors, Python interpreter, environment overrides, UTC
start/terminal times, return codes and log hashes are recorded in the original
per-command JSON records. Commands were:

    python -B -m pytest --assert=plain -q -p no:cacheprovider tests/test_proof_bank.py
    python -B tools/make_proof_bank.py --check
    python -B tools/vendoring/check_vendored_sync.py
    python -B tools/make_ledger.py --check
    PYTHONPATH=tools python -B -m claim_governance.cli --root .
    git diff --check
    git diff --cached --check

All 1,960 recorded source, documentation and configuration files stayed
unchanged during the checks and the subsequent strict log review. Packaging
also checked their recorded hashes against the available repository bytes.
SOURCES.sha256 is an input-hash inventory; it does not embed those source files.

## Preserved wrapper failure and separate result review

The initial wrapper marked its aggregate status as failed because its parser
expected a numeric "57 passed" summary line. The repository config sets
addopts="-q", and the command also supplies -q. This double-quiet output omitted
that summary while retaining exactly 57 pass dots followed by [100%]. Pytest
itself exited 0.

The initial failed aggregate receipt, runner and logs are preserved byte for
byte. They were not rewritten to show success. A separate executed
review_completed_checks.py verified the exact 57-dot completion line, process
exit 0, the six other successful command records, all recorded source hashes,
and the original receipt/log digests. Its review.json records the passing
source-validation result and the original wrapper parser failure explicitly.
No test was rerun for this review or packaging step.

## Archive layout and integrity

The archive root contains this README, a complete SHA256SUMS for every other
regular-file member, and the packaging verification code and receipt.
The records/ directory contains all 30 original files, including the original
records/SHA256SUMS, records/REVIEW.sha256, records/SOURCES.sha256, initial
failed terminal.json, separate passing review.json, every command log and
start/terminal record, and both executed validation/review scripts.

The separate directory preserves the original manifest bytes and their
relative-name semantics. Both original integrity manifests were verified
against the original records and again against the archived bytes. The source
input manifest was verified against the repository files; its own exact bytes
are covered by the original and outer integrity manifests.

The tar contains only safe, unique regular-file paths, with fixed permissions,
zero timestamps and fixed owner fields. The gzip header has a zero timestamp
and empty filename. Every archived original record was compared byte for byte
with its retained original. The enclosing archive digest is recorded in the
parent evidence inventory and publication report.

## Scope

These are source, test and governance checks. No Lean compiler or native gate
was invoked. This packet does not establish compiled acceptance of the repaired
consumer, the full isolated Lean build, original-packet proof imports, a
nine-endpoint compiled axiom audit, or termination acceptance. Those gates
retain their separate receipts and status.
"""
verification = {
    'schema': 'psc-consumer-selector-source-record-preservation-v1',
    'original_record_count': len(original),
    'all_original_records_preserved_byte_for_byte': True,
    'original_record_sha256': {name: sha(data) for name, data in original.items()},
    'original_integrity_manifests': {
        name: {'sha256': sha(original[name]), 'entries': len(manifest_entries(original[name])),
               'all_entries_verified': True}
        for name in ['SHA256SUMS', 'REVIEW.sha256']
    },
    'source_input_manifest': {
        'sha256': sha(original['SOURCES.sha256']),
        'entries': len(source_manifest),
        'verified_against_current_repository_bytes': True,
        'source_bytes_embedded_by_packaging': False,
    },
    'all_seven_validation_commands_exit_zero': True,
    'proof_bank_pass_symbols': len(match.group(1)),
    'original_wrapper_aggregate_status': terminal['status'],
    'separate_completed_log_review_status': review['status'],
    'tests_rerun_during_packaging': False,
    'lean_invoked': False, 'native_gate_invoked': False,
}
members = {'records/' + name: data for name, data in original.items()}
members['README.md'] = readme.encode()
members['packaging/package_consumer_selector_validation.py'] = Path(__file__).read_bytes()
members['packaging/verification.json'] = (json.dumps(verification, indent=2, sort_keys=True) + '\n').encode()
members['SHA256SUMS'] = ''.join(
    f'{sha(data)}  {name}\n' for name, data in sorted(members.items())).encode()
OUTPUT.mkdir(exist_ok=False)
(OUTPUT / 'README.md').write_bytes(members['README.md'])
with ARCHIVE.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            tar.addfile(info, io.BytesIO(data))
extracted = {}
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    for info in archive.getmembers():
        path = PurePosixPath(info.name)
        assert info.isfile() and not path.is_absolute() and '..' not in path.parts
        assert info.name not in extracted and info.mode == 0o644
        assert info.mtime == info.uid == info.gid == 0
        assert info.uname == info.gname == ''
        extracted[info.name] = archive.extractfile(info).read()
assert extracted == members
outer = manifest_entries(extracted['SHA256SUMS'])
assert {name for _, name in outer} == set(extracted) - {'SHA256SUMS'}
for expected, name in outer:
    assert sha(extracted[name]) == expected
for name in ['SHA256SUMS', 'REVIEW.sha256']:
    for expected, member in manifest_entries(extracted['records/' + name]):
        assert sha(extracted['records/' + member]) == expected
for name, data in original.items():
    assert extracted['records/' + name] == data == (RECORDS / name).read_bytes()
for expected, name in source_manifest:
    assert sha((REPO / name).read_bytes()) == expected, name
receipt = {
    'archive': str(ARCHIVE), 'archive_sha256': sha(ARCHIVE.read_bytes()),
    'archive_bytes': ARCHIVE.stat().st_size,
    'regular_file_members': len(extracted),
    'outer_manifest_entries': len(outer),
    'outer_manifest_sha256': sha(extracted['SHA256SUMS']),
    'original_records_preserved': len(original),
    'all_inner_and_outer_integrity_manifests_verified': True,
    'all_source_input_manifest_entries_verified': len(source_manifest),
    'readme_sha256': sha(members['README.md']),
}
with (WORK / 'checks/source-validation-package-receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(receipt, indent=2, sort_keys=True))
