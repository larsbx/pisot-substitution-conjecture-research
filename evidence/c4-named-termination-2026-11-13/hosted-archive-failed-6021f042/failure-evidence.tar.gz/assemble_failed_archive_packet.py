"""Preserve the failed exact-source hosted run without upgrading its scope."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile
import zipfile

BASE = Path(__file__).resolve().parent
REPO = BASE.parent / 'psc'
OUT = BASE.parent / 'hosted-archive-failed-6021f042'
TAR = OUT.with_suffix('.tar.gz')
SOURCE = '6021f042056d3cb0f9717d2488144339721c2071'
TREE = '3355716258114a4f5353b10233fa1fa79bb34bbd'
RUN = 43435276766
JOB = 131918635881
ARTIFACT = 14053265231


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(name):
    return json.loads((BASE / name).read_text())


def git_blob(path):
    return subprocess.check_output(['git', 'show', SOURCE + ':' + path], cwd=REPO)


run = read_json('archive-run-poll-03.provider.json')
jobs = read_json('archive-jobs-poll-03.provider.json')['jobs']
metadata = read_json('archive-terminal-artifacts.provider.json')['artifacts']
assert run['id'] == RUN and run['head_sha'] == SOURCE and run['run_attempt'] == 1
assert run['status'] == 'completed' and run['conclusion'] == 'failure'
assert len(jobs) == 1 and jobs[0]['id'] == JOB
job = jobs[0]
assert job['head_sha'] == SOURCE and job['run_attempt'] == 1
assert job['status'] == 'completed' and job['conclusion'] == 'failure'
failed_steps = [step for step in job['steps'] if step['conclusion'] == 'failure']
assert len(failed_steps) == 1
assert failed_steps[0]['name'] == 'Isolated full build and both concrete geometric imports'
assert len(metadata) == 1 and metadata[0]['id'] == ARTIFACT
artifact = metadata[0]
assert artifact['workflow_run']['id'] == RUN
assert artifact['workflow_run']['head_sha'] == SOURCE
zip_path = BASE / 'archive-43435276766-6021f042.zip'
zip_data = zip_path.read_bytes()
assert artifact['digest'] == 'sha256:' + sha(zip_data)
assert artifact['size_in_bytes'] == len(zip_data)
root = BASE / 'archive-failed-artifact'
with zipfile.ZipFile(io.BytesIO(zip_data)) as archive:
    names = [item.filename for item in archive.infolist() if not item.is_dir()]
    assert len(names) == 7 and len(set(names)) == 7
    assert set(names) == {
        'archive-sha256.txt', 'lean-audit.log', 'native-oracle-receipt.json',
        'native-packet.txt', 'native-tests.log', 'oracle-tests.log', 'revision.txt'}
    for name in names:
        assert archive.read(name) == (root / name).read_bytes()
assert (root / 'revision.txt').read_text().splitlines() == [SOURCE, TREE]
bound_archive = 'evidence/c4-pair-overlap-graph-2026-11-05/receipt.json'
assert (root / 'archive-sha256.txt').read_text() == sha(git_blob(bound_archive)) + '  ' + bound_archive + '\n'
native = json.loads((root / 'native-oracle-receipt.json').read_text())
assert native['payload_sha256'] == sha((root / 'native-packet.txt').read_bytes())
assert native['payload_bytes'] == (root / 'native-packet.txt').stat().st_size
assert native['all_two_original_fixtures_verified']
assert native['kernel_acceptance_supplied_by_this_oracle'] is False
error = 'error: PscVerif/NamedForwardCarrier.lean:77:4: maximum recursion depth has been reached'
lean_log = (root / 'lean-audit.log').read_text()
job_log = (BASE / 'archive-terminal-job.log').read_text()
for marker in [
    'Built PscVerif.NamedForwardCarrierData1 (684s)',
    'Built PscVerif.NamedForwardCarrierData0 (1100s)',
    error,
]:
    assert marker in lean_log and marker in job_log
assert 'Process completed with exit code 1.' in job_log
source_consumer = git_blob('proof/PscVerif/PscVerif/NamedForwardCarrier.lean')
assert source_consumer.decode().splitlines()[76] == '  · change Psc.ForwardCarrier.check'
commit = subprocess.check_output(['git', 'cat-file', 'commit', SOURCE], cwd=REPO)
assert hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest() == SOURCE
assert commit.splitlines()[0] == ('tree ' + TREE).encode()

OUT.mkdir(exist_ok=False)
(OUT / 'artifact').mkdir()
for path in root.iterdir():
    shutil.copyfile(path, OUT / 'artifact' / path.name)
shutil.copyfile(zip_path, OUT / zip_path.name)
(OUT / 'rest').mkdir()
for name in [
    'archive-run-poll-03.provider.json',
    'archive-jobs-poll-03.provider.json',
    'archive-terminal-artifacts.provider.json',
]:
    shutil.copyfile(BASE / name, OUT / 'rest' / name)
acquisition = {}
for name in ['archive-run-poll-03.json', 'archive-jobs-poll-03.json', 'archive-terminal-artifacts.json']:
    wrapper = read_json(name)
    acquisition[name] = {key: wrapper[key] for key in ('retrieved_at_utc', 'url')}
(OUT / 'rest/acquisition.json').write_text(json.dumps(acquisition, indent=2, sort_keys=True) + '\n')
shutil.copyfile(BASE / 'archive-terminal-job.log', OUT / 'job.log')
shutil.copyfile(BASE / 'archive-terminal-job-log.json', OUT / 'job-provider-response.json')
source_files = [
    'proof/PscVerif/PscVerif/NamedForwardCarrier.lean',
    '.github/workflows/c4-archived-payload-lean.yml',
    'tools/check_lean.sh',
    'tools/replay_archived_payload_lean.py',
]
for name in source_files:
    path = OUT / 'source' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(git_blob(name))
(OUT / 'source/commit.raw').write_bytes(commit)
shutil.copyfile(Path(__file__), OUT / 'assemble_failed_archive_packet.py')
receipt = {
    'schema': 'psc-hosted-failed-archive-preservation-v1',
    'run_id': RUN, 'run_attempt': 1, 'job_id': JOB, 'artifact_id': ARTIFACT,
    'source_commit': SOURCE, 'source_tree': TREE,
    'workflow_conclusion': 'failure', 'overall_formal_acceptance': False,
    'compiled_axiom_audit_completed': False, 'termination_claimed': False,
    'zip_sha256': sha(zip_data), 'zip_bytes': len(zip_data),
    'all_seven_extracted_files_match_original_zip': True,
    'artifact_revision_matches_raw_provider_run_job_and_artifact': True,
    'bound_original_archive_sha256_matches_immutable_source': True,
    'native_payload_matches_its_hosted_oracle_receipt': True,
    'artifact_has_complete_source_hash_inventory': False,
    'compiler_objects_retained_in_artifact': False,
    'reported_successful_modules': [
        {'module': 'PscVerif.NamedForwardCarrierData1', 'reported_seconds': 684},
        {'module': 'PscVerif.NamedForwardCarrierData0', 'reported_seconds': 1100},
    ],
    'observed_failure': error,
    'failed_step': failed_steps[0],
    'failure_classification': 'compiler recursion-depth error in consumer elaboration, followed by build exit1',
    'same_run_did_not_report_timeout_or_cancellation': True,
    'local_lean_invocations_in_this_review': 0,
    'source_files': {name: sha(git_blob(name)) for name in source_files},
    'artifact_files': {name: sha((root / name).read_bytes()) for name in sorted(names)},
}
(OUT / 'review.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
(OUT / 'README.md').write_text("""# Failed hosted original-archive gate at 6021f042

This packet preserves the original failed GitHub Actions run 43435276766,
attempt 1, job 131918635881, for exact source commit
6021f042056d3cb0f9717d2488144339721c2071 and tree
3355716258114a4f5353b10233fa1fa79bb34bbd.

The isolated build reported successful compilation of
NamedForwardCarrierData1 (684 seconds) and NamedForwardCarrierData0
(1100 seconds). It then failed while elaborating the second change
in NamedForwardCarrier.check_checkedStates, at line 77, with
"maximum recursion depth has been reached". The job ended with build exit 1.
The observed failure is a compiler diagnostic, not a workflow timeout.

The original ZIP, all seven files, raw REST run/job/artifact records, complete
job log, exact consumer/workflow/gate source blobs, commit identity, and review
code are retained. The ZIP digest and byte size match the provider metadata.
Each extracted file matches the ZIP; the revision matches the raw run/job/
artifact identity. The original archive binding matches the immutable source,
and the native packet matches its hosted oracle receipt.

The archived artifact contains neither the compiled objects nor a complete
source-hash inventory. Its build messages establish reported module compilation;
they do not substitute for the missing whole-run compiled axiom audit or the
later original-packet proof imports. This failed run supplies no complete
isolated formal acceptance, no nine-endpoint compiled audit, and no termination
acceptance. No local Lean compiler was run during this preservation review.
The separate successful native-carrier packet retains its own independent scope.

review.json records the verified facts. SHA256SUMS covers all retained files
other than itself. The enclosing tar has sorted entries, zero timestamps and
fixed owner/mode fields. Earlier failed or accepted evidence is unchanged.
""")
files = sorted(path for path in OUT.rglob('*') if path.is_file())
(OUT / 'SHA256SUMS').write_text(''.join(
    f'{sha(path.read_bytes())}  {path.relative_to(OUT).as_posix()}\n' for path in files))
with TAR.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for path in sorted(path for path in OUT.rglob('*') if path.is_file()):
            data = path.read_bytes()
            info = tarfile.TarInfo(path.relative_to(OUT).as_posix())
            info.size = len(data)
            info.mode = 0o644
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            tar.addfile(info, io.BytesIO(data))
with tarfile.open(TAR, 'r:gz') as archive:
    for member in archive.getmembers():
        assert archive.extractfile(member).read() == (OUT / member.name).read_bytes()
assembly = {
    'packet_directory': str(OUT), 'tar_path': str(TAR),
    'tar_sha256': sha(TAR.read_bytes()), 'tar_bytes': TAR.stat().st_size,
    'manifest_sha256': sha((OUT / 'SHA256SUMS').read_bytes()),
    'manifest_entries': len(files),
    'archive_all_members_verified': True,
}
(BASE / 'failed-archive-packet-assembly.json').write_text(json.dumps(assembly, indent=2, sort_keys=True) + '\n')
print(json.dumps(assembly, indent=2, sort_keys=True))
