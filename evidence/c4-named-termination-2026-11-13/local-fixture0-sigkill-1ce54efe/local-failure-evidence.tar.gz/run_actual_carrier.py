import argparse, hashlib, json, os, pathlib, signal, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument("fixture", type=int, choices=[0, 1])
parser.add_argument("label")
parser.add_argument("--kind", choices=["Data", "Words"], default="Data")
parser.add_argument("--threads", type=int, default=2)
parser.add_argument("--seconds", type=float, default=3600)
parser.add_argument("--rss-bytes", type=int, default=4000000000)
parser.add_argument("--trace-kernel", action="store_true")
args = parser.parse_args()
root = pathlib.Path("/workspace/scratch/91efcf4b7b58/psc/proof/PscVerif")
out = pathlib.Path("/workspace/scratch/91efcf4b7b58/carrier-diagnostics")
source = root / f"PscVerif/NamedForwardCarrier{args.kind}{args.fixture}.lean"
obj = root / f".lake/build/lib/lean/PscVerif/NamedForwardCarrier{args.kind}{args.fixture}.olean"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
stamp = lambda: time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
assert not obj.exists(), f"Refusing to overwrite pre-existing evidence object: {obj}"
assert not (out / f"{args.label}-start.json").exists(), "Diagnostic label already used"
env = os.environ.copy()
paths = [root / ".lake/build/lib/lean"]
paths += sorted(p / ".lake/build/lib/lean" for p in (root / ".lake/packages").iterdir() if p.is_dir())
env["LEAN_PATH"] = ":".join(str(p) for p in paths)
env["LEAN_NUM_THREADS"] = str(args.threads)
command = ["/tmp/psc-lean/bin/lean", "--profile", "-j", str(args.threads), "-DElab.async=false", "-o", str(obj), str(source)]
if args.trace_kernel:
    command = ["stdbuf", "-oL", "-eL", *command[:5], "-Dtrace.Kernel=true", *command[5:]]
dependencies = [{"module": "Init", "object_sha256": sha(pathlib.Path("/tmp/psc-lean/lib/lean/Init.olean"))}]
scope = "actual generated Init-data module compilation"
if args.kind == "Data":
    dependencies.append({"module": "PscVerif.FastForwardCarrier", "source_sha256": sha(root / "PscVerif/FastForwardCarrier.lean"), "object_sha256": sha(root / ".lake/build/lib/lean/PscVerif/FastForwardCarrier.olean")})
    dependencies.append({"module": f"PscVerif.NamedForwardCarrierWords{args.fixture}", "source_sha256": sha(root / f"PscVerif/NamedForwardCarrierWords{args.fixture}.lean"), "object_sha256": sha(root / f".lake/build/lib/lean/PscVerif/NamedForwardCarrierWords{args.fixture}.olean")})
    scope = "focused cached-dependency development compilation"
start_record = {"command": command, "source_sha256": sha(source), "compiler_sha256": sha(pathlib.Path("/tmp/psc-lean/bin/lean")), "dependencies": dependencies, "started_utc": stamp(), "scope": scope, "time_guard_seconds": args.seconds, "rss_guard_bytes": args.rss_bytes}
(out / f"{args.label}-start.json").write_text(json.dumps(start_record, indent=2) + "\n")
print(json.dumps(start_record), flush=True)
start = time.monotonic()
stop_reason = None
max_rss = 0
log_path = out / f"{args.label}.log"
with log_path.open("wb") as log, (out / f"{args.label}.resources.jsonl").open("w") as resource:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    while process.poll() is None:
        elapsed = time.monotonic() - start
        try:
            stat = pathlib.Path(f"/proc/{process.pid}/stat").read_text().split()
            rss = int(pathlib.Path(f"/proc/{process.pid}/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
            record = {"elapsed_seconds": elapsed, "rss_bytes": rss, "cpu_ticks": int(stat[13]) + int(stat[14]), "state": stat[2], "log_bytes": log_path.stat().st_size}
            max_rss = max(max_rss, rss)
            resource.write(json.dumps(record) + "\n"); resource.flush()
        except (FileNotFoundError, ProcessLookupError):
            rss = 0
        if (out / f"stop-{args.label}").exists():
            stop_reason = "requested_stop"
        elif elapsed >= args.seconds:
            stop_reason = "time_guard"
        elif rss > args.rss_bytes:
            stop_reason = "rss_guard"
        if stop_reason:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
            break
        time.sleep(5)
    returncode = process.wait()
terminal = {"status": "passed" if returncode == 0 and obj.exists() else ("controlled_stop" if stop_reason else "failed"), "elapsed_seconds": time.monotonic() - start, "compiler_returncode": returncode, "stop_reason": stop_reason, "source_sha256": sha(source), "source_unchanged": sha(source) == start_record["source_sha256"], "object_exists": obj.exists(), "object_sha256": sha(obj) if obj.exists() else None, "maximum_sampled_rss_bytes": max_rss, "log_sha256": sha(log_path), "ended_utc": stamp()}
(out / f"{args.label}-terminal.json").write_text(json.dumps(terminal, indent=2) + "\n")
print(json.dumps(terminal, indent=2), flush=True)
raise SystemExit(0 if terminal["status"] == "passed" and terminal["source_unchanged"] else 1)
