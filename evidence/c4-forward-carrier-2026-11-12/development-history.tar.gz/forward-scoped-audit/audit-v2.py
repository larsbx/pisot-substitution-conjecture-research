#!/usr/bin/env python3
"""Prepare or replay one scoped, development-only compiled Lean axiom audit.

Preparation never invokes Lean. Execution is a separate command for the
coordinating agent after the concrete compiler has terminated.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time


BASE = Path(__file__).resolve().parent
WORK = BASE.parent
REPO = WORK / "psc"
PROJECT = REPO / "proof/PscVerif"
UNION = WORK / "focused-lean"
FRESH = Path("/workspace/scratch/5535bb23ca85/isolated-v4/tmp/tmp.HhzCKAuxBY/proof/PscVerif")
BASE_RECEIPTS = {
    "PscVerif.ForwardCarrier": WORK / "forward-carrier-dev/attempt01",
    "PscVerif.FastForwardCarrier": WORK / "fast-forward-carrier-dev/attempt03",
    "PscVerif.FastForwardCarrierControls": WORK / "named-forward-carrier-dev/controls-attempt01",
}
DATA_MODULES = {f"PscVerif.NamedForwardCarrierData{i}" for i in range(2)}
STANDARD = {"propext", "Classical.choice", "Quot.sound"}
SCOPE = "selected compiled modules only; cached dependency inputs; not complete isolated acceptance"


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def load_bank():
    path = REPO / "tools/make_proof_bank.py"
    spec = importlib.util.spec_from_file_location("scoped_proof_bank", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.STANDARD_AXIOMS != STANDARD:
        raise ValueError("repository axiom allowlist differs from requested policy")
    return module


def successful_receipt(directory: Path, expected: str | None = None) -> dict:
    directory = directory.resolve()
    start_path, terminal_path = directory / "start.json", directory / "terminal.json"
    start = json.loads(start_path.read_text())
    terminal = json.loads(terminal_path.read_text())
    source = Path(start["source_path"])
    module = ".".join(source.relative_to(PROJECT).with_suffix("").parts)
    if expected is not None and module != expected:
        raise ValueError(f"wrong module in receipt: {module}, expected {expected}")
    if expected is None and module not in DATA_MODULES:
        raise ValueError("extra receipts may select only the two generated Data modules")
    output = Path(start["output_path"])
    if output != UNION / Path(*module.split(".")).with_suffix(".olean"):
        raise ValueError(f"object is outside the owned module slot: {output}")
    if (terminal.get("outcome") != "passed" or terminal.get("compiler_returncode") != 0
            or terminal.get("source_unchanged") is not True
            or terminal.get("output_exists") is not True):
        raise ValueError(f"receipt has no successful terminal compilation: {directory}")
    if not (digest(source) == start["source_sha256"] == terminal["source_sha256"]):
        raise ValueError(f"source does not match successful receipt: {source}")
    if digest(output) != terminal["output_sha256"]:
        raise ValueError(f"compiled object does not match successful receipt: {output}")
    log = directory / "compile.log"
    if digest(log) != terminal["log_sha256"]:
        raise ValueError(f"compile log does not match terminal receipt: {directory}")
    return {
        "module": module, "source": str(source), "source_sha256": digest(source),
        "object": str(output), "object_sha256": digest(output),
        "compile_receipt": str(terminal_path), "compile_receipt_sha256": digest(terminal_path),
        "compile_start": str(start_path), "compile_start_sha256": digest(start_path),
        "compiler": start["command"][0], "compiler_sha256": start["compiler_sha256"],
    }


def audit_source(modules: list[str]) -> str:
    template = (PROJECT / "ProofBankAudit.lean").read_text()
    template = template[template.index("import PscVerif\n"):]
    template = template.replace("import PscVerif\n", "".join(f"import {m}\n" for m in modules), 1)
    selector = "  let selected := #[" + ", ".join("`" + m for m in modules) + "]\n"
    selector += "  for mod in selected do\n"
    selector += '    if (env.getModuleIdx? mod).isNone then throwError "Missing selected audit module: {mod}"\n'
    marker = "  let env ← getEnv\n"
    owner_filter = "    if mod.getRoot != `PscVerif then continue\n"
    if template.count(marker) != 1 or template.count(owner_filter) != 1:
        raise ValueError("repository audit template changed; review the scoped adaptation")
    template = template.replace(marker, marker + selector)
    template = template.replace(owner_filter, "    if !selected.contains mod then continue\n")
    return "/- Scoped development replay derived from the repository audit.\n" \
        "Every owned constant in the selected modules is visited.\n" \
        "This is not the complete isolated project gate. -/\n" + template


def prepare(args) -> None:
    plan = args.plan.resolve()
    if not plan.is_relative_to(BASE):
        raise ValueError("plan directory must remain under this scratch audit directory")
    if plan.exists() and any(plan.iterdir()):
        raise ValueError("refuse to overwrite a previous plan or audit receipt")
    selected = [successful_receipt(path, module) for module, path in BASE_RECEIPTS.items()]
    selected += [successful_receipt(path) for path in args.data_receipt]
    modules = [item["module"] for item in selected]
    if len(set(modules)) != len(modules):
        raise ValueError("duplicate selected module")
    controls_start = json.loads((BASE_RECEIPTS[modules[2]] / "start.json").read_text())
    lean_path = controls_start["lean_path"]
    if lean_path.split(os.pathsep)[0] != str(UNION):
        raise ValueError("owned development union is not first in LEAN_PATH")
    compiler = Path(selected[0]["compiler"])
    if any(item["compiler"] != str(compiler) or item["compiler_sha256"] != digest(compiler)
           for item in selected):
        raise ValueError("successful modules used different compiler bytes")
    for item in selected:
        relative = Path(*item["module"].split(".")).with_suffix(".olean")
        resolved = next((Path(root) / relative for root in lean_path.split(os.pathsep)
                         if (Path(root) / relative).is_file()), None)
        if resolved != Path(item["object"]):
            raise ValueError(f"unexpected imported object resolution for {item['module']}")
    bank = load_bank()
    inventory = [d for d in bank.lean_declarations(REPO) if d["module"] in modules]
    if {d["module"] for d in inventory} != set(modules):
        raise ValueError("a selected module has no expected source theorem inventory")
    inputs = {str(REPO / "tools/make_proof_bank.py"): digest(REPO / "tools/make_proof_bank.py"),
              str(PROJECT / "ProofBankAudit.lean"): digest(PROJECT / "ProofBankAudit.lean"),
              str(compiler): digest(compiler)}
    for name in ("lean-toolchain", "lake-manifest.json"):
        if digest(PROJECT / name) != digest(FRESH / name):
            raise ValueError(f"fresh dependency pin mismatch: {name}")
        inputs[str(PROJECT / name)] = digest(PROJECT / name)
        inputs[str(FRESH / name)] = digest(FRESH / name)
    plan.mkdir(parents=True, exist_ok=True)
    for item in selected:
        target = plan / "sources" / Path(*item["module"].split(".")).with_suffix(".lean")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(item["source"], target)
    (plan / "ForwardScopedAudit.lean").write_text(audit_source(modules))
    write_json(plan / "expected-declarations.json", inventory)
    manifest = {
        "schema": "psc-forward-scoped-axiom-audit-plan-v1", "prepared_at_utc": utc(),
        "scope": SCOPE, "compiler_executed": False, "compiled_axiom_audit_performed": False,
        "selected": selected, "modules": modules, "lean_path": lean_path,
        "compiler": str(compiler), "pinned_input_sha256": inputs,
        "expected_proofs_by_module": dict(Counter(d["module"] for d in inventory)),
        "expected_private_proofs": [d for d in inventory if d["private"]],
        "expected_inventory_sha256": digest(plan / "expected-declarations.json"),
        "audit_source_sha256": digest(plan / "ForwardScopedAudit.lean"),
        "allowed_axioms": sorted(STANDARD),
        "unselected_data_modules": sorted(DATA_MODULES - set(modules)),
    }
    write_json(plan / "plan.json", manifest)
    print(json.dumps({"prepared": str(plan), "modules": modules,
                      "expected_proofs": len(inventory), "compiler_executed": False}))


def verify_plan(plan: Path, manifest: dict) -> None:
    for path, expected in manifest["pinned_input_sha256"].items():
        if digest(Path(path)) != expected:
            raise ValueError(f"pinned audit input changed: {path}")
    for name, field in (("ForwardScopedAudit.lean", "audit_source_sha256"),
                        ("expected-declarations.json", "expected_inventory_sha256")):
        if digest(plan / name) != manifest[field]:
            raise ValueError(f"prepared audit artifact changed: {name}")
    for item in manifest["selected"]:
        for path_field, sha_field in (("source", "source_sha256"), ("object", "object_sha256"),
                                     ("compile_receipt", "compile_receipt_sha256"),
                                     ("compile_start", "compile_start_sha256")):
            if digest(Path(item[path_field])) != item[sha_field]:
                raise ValueError(f"selected module input changed: {item[path_field]}")


def run(args) -> None:
    plan = args.plan.resolve()
    manifest = json.loads((plan / "plan.json").read_text())
    verify_plan(plan, manifest)
    inventory = json.loads((plan / "expected-declarations.json").read_text())
    bank = load_bank()
    expected = {(d["module"], d["name"]) for d in inventory}
    output = args.output.resolve()
    if not output.is_relative_to(BASE) or (output.exists() and any(output.iterdir())):
        raise ValueError("use a new output directory under this scratch audit directory")
    output.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(__file__, output / "runner.py")
    shutil.copyfile(plan / "ForwardScopedAudit.lean", output / "ForwardScopedAudit.lean")
    shutil.copyfile(plan / "expected-declarations.json", output / "expected-declarations.json")
    command = [manifest["compiler"], "-j", "1", "-DautoImplicit=false",
               "--root=" + str(output), str(output / "ForwardScopedAudit.lean")]
    start = {"started_at_utc": utc(), "scope": SCOPE, "command": command,
             "plan": str(plan), "plan_sha256": digest(plan / "plan.json"),
             "lean_path": manifest["lean_path"], "cwd": str(PROJECT),
             "timeout_seconds": args.timeout_seconds,
             "runner_sha256": digest(output / "runner.py")}
    write_json(output / "start.json", start)
    started = time.monotonic()
    reason = None
    with (output / "audit.log").open("w") as log:
        child = subprocess.Popen(command, cwd=PROJECT,
                                 env={**os.environ, "LEAN_PATH": manifest["lean_path"]},
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        write_json(output / "process.json", {"pid": child.pid, "pgid": child.pid})
        while child.poll() is None:
            if (output / "STOP").exists():
                reason = "owned stop marker"
            elif time.monotonic() - started > args.timeout_seconds:
                reason = "audit timeout"
            if reason:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                break
            time.sleep(0.25)
    errors, counts = [], None
    if reason:
        errors.append(reason)
    if child.returncode != 0:
        errors.append(f"audit compiler exit {child.returncode}")
    try:
        verify_plan(plan, manifest)
        if digest(plan / "plan.json") != start["plan_sha256"]:
            raise ValueError("plan changed during audit")
        text = (output / "audit.log").read_text()
        counts = bank.check_audit(text, expected)
        observed = {line.split("\t")[2] for line in text.splitlines()
                    if line.startswith("PSC_AXIOMS\t")}
        if observed != set(manifest["modules"]):
            raise ValueError("observed audit modules differ from selected modules")
    except (OSError, ValueError, KeyError) as exc:
        errors.append(str(exc))
    terminal = {
        "ended_at_utc": utc(), "elapsed_seconds": round(time.monotonic() - started, 3),
        "scope": SCOPE, "compiler_returncode": child.returncode,
        "outcome": "passed" if not errors else "incomplete-or-failed", "errors": errors,
        "compiled_axiom_audit_performed": not errors,
        "isolated_acceptance_claimed": False, "named_termination_acceptance_claimed": False,
        "selected_modules": manifest["modules"], "expected_source_proofs": len(expected),
        "declarations": counts[0] if counts else None,
        "theorem_declarations": counts[1] if counts else None,
        "allowed_axioms": sorted(STANDARD),
        "audit_log_sha256": digest(output / "audit.log"),
    }
    write_json(output / "terminal.json", terminal)
    print(json.dumps(terminal))
    if errors:
        raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prep = commands.add_parser("prepare", help="write audit source/inventory; never invoke Lean")
    prep.add_argument("--plan", type=Path, required=True)
    prep.add_argument("--data-receipt", type=Path, action="append", default=[])
    replay = commands.add_parser("run", help="execute one combined import/audit after coordination")
    replay.add_argument("--plan", type=Path, required=True)
    replay.add_argument("--output", type=Path, required=True)
    replay.add_argument("--timeout-seconds", type=float, default=240)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare(args)
    else:
        run(args)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as exc:
        print(f"Scoped audit refused: {exc}", file=sys.stderr)
        raise SystemExit(1)
