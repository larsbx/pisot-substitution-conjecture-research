/- Scoped development replay derived from the repository audit.
Every owned constant in the selected modules is visited.
This is not the complete isolated project gate. -/
import PscVerif.ForwardCarrier
import PscVerif.FastForwardCarrier
import PscVerif.FastForwardCarrierControls
import Lean.Util.CollectAxioms

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let selected := #[`PscVerif.ForwardCarrier, `PscVerif.FastForwardCarrier, `PscVerif.FastForwardCarrierControls]
  for mod in selected do
    if (env.getModuleIdx? mod).isNone then throwError "Missing selected audit module: {mod}"
  let mut count := 0
  let mut theorems := 0
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  for index in [:env.header.moduleNames.size] do
    let mod := env.header.moduleNames[index]!
    if !selected.contains mod then continue
    let data := env.header.moduleData[index]!
    for info in data.constants do
      let name := info.name
      let some owner := env.getModuleIdxFor? name | continue
      if owner.toNat != index then continue
      if info.isAxiom then
        throwError "Local axiom in the proof bank: {name}"
      let axioms ← collectAxioms name
      for ax in axioms do
        if !allowed.contains ax then
          throwError "Nonstandard axiom in {name}: {ax}"
      count := count + 1
      if info.isTheorem then theorems := theorems + 1
      let kind := if info.isTheorem then "theorem" else "declaration"
      let userName := privateToUserName name
      let names := String.intercalate "," (axioms.toList.map toString)
      liftIO <| IO.println s!"PSC_AXIOMS\t{kind}\t{mod}\t{name}\t{userName}\t{names}"
  if theorems == 0 then throwError "The proof bank contains no theorems"
  liftIO <| IO.println s!"PSC_AUDIT_COMPLETE\t{count}\t{theorems}"
