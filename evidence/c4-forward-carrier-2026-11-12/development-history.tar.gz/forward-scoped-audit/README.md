# Prepared scoped compiled-axiom audit

This scratch preparation is for the three successful new generic modules
and any successfully compiled generated Data modules. It does not import
the root aggregate or the heavy named geometry chain.

Preparation does not invoke Lean. Root separately authorized the completed
generic-only `run01` after the active concrete compiler terminated; its
actual outcome is recorded below. Further execution remains coordinated
with root; do not run overlapping imports.

## Contract

The source is derived from the repository's current `ProofBankAudit.lean`.
The only semantic adaptation is an explicit selected-module filter instead
of every imported `PscVerif` module. All owned constants are visited,
including definitions, generated helpers and private declarations.
`collectAxioms` uses the exported, shared transitive dependency cache.

The runner reuses `lean_declarations` and `check_audit` directly from the
repaired `tools/make_proof_bank.py`. Expected proof inventory includes
private proofs by their `privateToUserName` identities. Duplicate records,
missing source proofs, invalid completion counts, local axioms and any
transitive axiom outside `propext`, `Classical.choice`, `Quot.sound` refuse
success. Every selected module must appear in the observed output.

Successful terminal compile receipts, current source hashes and owned
`.olean` hashes are checked before module inclusion and again around the
audit. A stopped or pending compile cannot be selected as successful.
The explicit pinned compiler and the same owned union/fresh package paths
as the successful control compile are retained. No dependency cache is
duplicated and no dependency is rebuilt.

## Prepare the final combined plan

`prepared-generic` records only the three generic modules presently known
to have successful terminal compile receipts. It is preparation, not a
request to execute a premature separate audit.

After concrete compilation ends, prepare one new plan including each
successful current Data receipt; omit only Data modules without a
successful current receipt. For example, if both concrete modules pass:

```sh
python /workspace/scratch/d9728856ff24/forward-scoped-audit/audit.py prepare \
  --plan /workspace/scratch/d9728856ff24/forward-scoped-audit/prepared-combined \
  --data-receipt /workspace/scratch/d9728856ff24/named-forward-carrier-dev/data1-attempt02 \
  --data-receipt /workspace/scratch/d9728856ff24/named-forward-carrier-dev/data0-attempt01
```

Use actual successful receipt directories if the attempt names change.
An unsuccessful or source-mismatched receipt is refused. The plan contains
the generated audit source, full expected proof inventory, source
snapshots, selected source/object hashes and receipt bindings.

## Root-controlled execution

Only after root chooses to execute, run the single combined audit:

```sh
python /workspace/scratch/d9728856ff24/forward-scoped-audit/audit.py run \
  --plan /workspace/scratch/d9728856ff24/forward-scoped-audit/prepared-combined \
  --output /workspace/scratch/d9728856ff24/forward-scoped-audit/run01
```

This imports the selected compiled modules once and records the raw log,
start/process metadata and terminal result. The default hard timeout is
240 seconds. A `STOP` file in that run's output directory stops only the
owned audit process group. Failed and incomplete logs are retained.

A pass concerns only the selected compiled modules and their transitive
axiom sets. Cached dependency inputs remain explicit. It is not a fresh
isolated source build, full aggregate acceptance, concrete named binding
acceptance or a promotion of G1 or termination status.

## Actual generic-only audit

`run01` ended at `2026-11-13T04:11:54.437895+00:00`, exit zero in
10.287 seconds. It audited the three generic modules in
`prepared-generic/plan.json`: 172 owned compiled declarations, of which
96 are theorem declarations, including generated helpers. All 50 expected
source proofs were reached, including the private `int_count_cons` proof.
No local axiom or transitive axiom outside the three-name allowlist was
found. Every selected source/object and audit-input hash matched before
and after the run.

The raw audit source, full output, exact expected inventory, runner
snapshot, and terminal receipt are in `run01/`; source snapshots and
hash-bound compile receipts are in `prepared-generic/`. Audit log SHA-256:
`00f80f809000865d9b313caae30da94681567fcd4f0026857e11d3630668a3e6`.

Neither generated Data module was selected. The second fixture-1 compile
ended with signal 9 and no object, while fixture 0 had not started. This
scoped pass gives no concrete carrier, named termination or complete-gate
acceptance. The read-only parent-gate file observation is retained in
`parent-gate-observation.json`; it supplies no terminal success receipt.

## Refreshed audit after EOF cleanup

Root removed exactly one final blank line from `FastForwardCarrier.lean`.
The successful focused recompile is `fast-forward-carrier-dev/attempt03`;
the definitions, proof content and declaration locations did not change.
The original runner, `prepared-generic` and `run01` are retained unchanged.

`audit-v2.py` changes only the Fast compile-receipt selection to attempt 3.
Its new `prepared02` plan binds the cleaned Fast source SHA-256
`fba7b08223e333d9380ff1e090ad85cad6aadbe8eadd1a2dde8d6b92bfcf0689`
and owned object SHA-256
`07456349145d4f5bf37663ee3b6ca37ad18fbc472f6338672c9bbc148df68a69`.
ForwardCarrier and Controls retain their original successful receipt
bindings.

The single combined `run02` audit passed at
`2026-11-13T04:24:02.909864+00:00`, exit zero in 2.255 seconds. It again
visited 172 compiled declarations and 96 compiled theorem declarations,
reached all 50 source proofs including the private helper, and admitted
only the same three standard axioms. Every selected hash matched before
and after the replay. Its raw log SHA-256 is
`4144a941ac1c01a7755b64e7cbe232b7a409c870e4891f197c8cf099f4e7d538`.

The preserved historical run01 binds its earlier bytes; run02 is the
receipt for the cleaned current generic sources. Neither audit includes
the unfinished generated Data modules or the full named chain, and
neither supplies complete isolated-gate acceptance.
