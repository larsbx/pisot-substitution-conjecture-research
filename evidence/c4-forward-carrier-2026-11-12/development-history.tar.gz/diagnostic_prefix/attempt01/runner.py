#!/usr/bin/env python3
"""Bound one owned Lean development compile; never control another run."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


ROOT = Path('/workspace/scratch/d9728856ff24/psc')
PROJECT = Path('/workspace/scratch/d9728856ff24/diagnostic_prefix')
COMPILER = Path('/workspace/scratch/84c835820757/toolchains/elan/toolchains/leanprover--lean4---v4.34.0-rc2/bin/lean')
UNION = Path('/workspace/scratch/d9728856ff24/focused-lean')
PACKAGES = Path('/workspace/scratch/5535bb23ca85/isolated-v4/tmp/tmp.HhzCKAuxBY/proof/PscVerif/.lake/packages')


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def group_snapshot(group):
    rows = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry / 'stat').read_text().rsplit(') ', 1)[1].split()
            if int(fields[2]) != group:
                continue
            rows.append({'pid': int(entry.name), 'ppid': int(fields[1]),
                         'pgrp': int(fields[2]), 'session': int(fields[3]),
                         'state': fields[0], 'starttime': int(fields[19]),
                         'rss_bytes': int(fields[21]) * os.sysconf('SC_PAGE_SIZE'),
                         'user_ticks': int(fields[11]), 'system_ticks': int(fields[12]),
                         'threads': int(fields[17]), 'major_faults': int(fields[9]),
                         'minor_faults': int(fields[7])})
        except (FileNotFoundError, ProcessLookupError):
            continue
    return rows


def memory_snapshot():
    return {line.split(':')[0]: int(line.split()[1]) * 1024
            for line in Path('/proc/meminfo').read_text().splitlines()
            if line.split(':')[0] in {'MemTotal', 'MemAvailable', 'MemFree', 'SwapFree'}}


def stop_owned(process, reason):
    # The child was created in its own session. Only its still-live process
    # group is controlled, and its identity is captured in the start receipt.
    if process.poll() is not None:
        return []
    actions = []
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(process.pid, sig)
            actions.append({'at_utc': now(), 'signal': sig.name, 'reason': reason})
        except ProcessLookupError:
            break
        try:
            process.wait(timeout=5)
            break
        except subprocess.TimeoutExpired:
            continue
    return actions


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--label', required=True)
    ap.add_argument('--module', default='Data1Definitions')
    ap.add_argument('--timeout', type=float, default=180)
    args = ap.parse_args()
    if not args.label.replace('-', '').isalnum() or not args.module.isidentifier():
        raise ValueError('Unsafe label or module')
    run = Path(__file__).resolve().parent / args.label
    run.mkdir(exist_ok=False)
    source = PROJECT / (args.module + '.lean')
    output = run / (args.module + '.olean')
    if output.exists():
        raise ValueError(f'Refusing to overwrite {output}')
    stop_marker = run / 'STOP'
    log_path = run / 'compile.log'
    source_bytes = source.read_bytes()
    (run / source.name).write_bytes(source_bytes)
    env = {k: v for k, v in os.environ.items()
           if not (k.startswith('LEAN_') or k.startswith('LAKE_'))}
    import_roots = [UNION] + sorted(PACKAGES.glob('*/.lake/build/lib/lean'))
    env['LEAN_PATH'] = ':'.join(map(str, import_roots))
    command = [str(COMPILER), '-j', '1', '--profile', '-DautoImplicit=false',
               '-DElab.async=false', '-o', str(output), str(source.relative_to(PROJECT))]
    source_hash = hashlib.sha256(source_bytes).hexdigest()
    start = {'started_at_utc': now(), 'command': command, 'cwd': str(PROJECT),
             'source_path': str(source), 'source_sha256': source_hash,
             'compiler_sha256': digest(COMPILER), 'runner_sha256': digest(__file__),
             'lean_path': env['LEAN_PATH'], 'timeout_seconds': args.timeout,
             'environment_difference': 'Fresh isolated-v4 package paths replace old 0c41 package paths; owned focused-lean union is still first. Same pinned toolchain and manifests.',
             'preflight_sha256': digest(Path(__file__).resolve().parent / 'preflight.json'),
             'resource_limits': {'maximum_rss_bytes': 2_000_000_000,
                                 'minimum_host_available_bytes': 2_147_483_648,
                                 'poll_interval_seconds': 1},
             'stop_marker': str(stop_marker), 'output_path': str(output),
             'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
             'scope': 'scratch definitions-only diagnostic; no concrete theorem acceptance; no isolated acceptance'}
    (run / 'runner.py').write_bytes(Path(__file__).read_bytes())
    (run / 'preflight.json').write_bytes((Path(__file__).resolve().parent / 'preflight.json').read_bytes())
    record(run / 'start.json', start)
    print(json.dumps({'start': start}), flush=True)
    signals = []
    old = {sig: signal.signal(sig, lambda s, frame: signals.append(s))
           for sig in (signal.SIGINT, signal.SIGTERM)}
    proc = None
    errors = []
    actions = []
    reason = None
    begun = time.monotonic()
    samples = []
    resources = []
    try:
        with log_path.open('xb') as log:
            proc = subprocess.Popen(command, cwd=PROJECT, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, start_new_session=True)
            record(run / 'process.json', {'pid': proc.pid, 'session': proc.pid,
                                         'at_utc': now(), 'processes': group_snapshot(proc.pid)})
            next_sample = 0.0
            next_resource = 0.0
            while proc.poll() is None:
                elapsed = time.monotonic() - begun
                if elapsed >= next_sample:
                    sample = {'at_utc': now(), 'elapsed_seconds': round(elapsed, 3),
                              'processes': group_snapshot(proc.pid), 'log_bytes': log_path.stat().st_size}
                    samples.append(sample)
                    with (run / 'samples.jsonl').open('a') as stream:
                        stream.write(json.dumps(sample, sort_keys=True) + '\n')
                    print(json.dumps({'sample': sample}), flush=True)
                    next_sample = elapsed + 15
                if signals or stop_marker.exists() or elapsed >= args.timeout:
                    reason = 'signal' if signals else 'stop_marker' if stop_marker.exists() else 'timeout'
                    actions += stop_owned(proc, reason)
                    break
                if elapsed >= next_resource:
                    resource = {'at_utc': now(), 'elapsed_seconds': round(elapsed, 3),
                                'rss_bytes': sum(p['rss_bytes'] for p in group_snapshot(proc.pid)),
                                'memory': memory_snapshot()}
                    resources.append(resource)
                    with (run / 'resources.jsonl').open('a') as stream:
                        stream.write(json.dumps(resource, sort_keys=True) + '\n')
                    next_resource = elapsed + 1
                    if (resource['rss_bytes'] > start['resource_limits']['maximum_rss_bytes'] or
                        resource['memory']['MemAvailable'] < start['resource_limits']['minimum_host_available_bytes']):
                        reason = 'resource_refusal'
                        refusal = {'at_utc': now(), 'outcome': reason, 'observation': resource,
                                   'limits': start['resource_limits'],
                                   'scope': 'stop only this owned compiler process group'}
                        record(run / 'resource-refusal.json', refusal)
                        print(json.dumps({'resource_refusal': refusal}), flush=True)
                        actions += stop_owned(proc, reason)
                        break
                time.sleep(0.2)
            proc.wait(timeout=5)
    except Exception as exc:
        errors.append(repr(exc))
    finally:
        if proc is not None and proc.poll() is None:
            actions += stop_owned(proc, 'runner_cleanup')
        for sig, handler in old.items():
            signal.signal(sig, handler)
    unchanged = digest(source) == source_hash
    if not unchanged:
        errors.append('Source changed during compile')
    result = {'ended_at_utc': now(), 'elapsed_seconds': round(time.monotonic()-begun, 3),
              'compiler_returncode': proc.returncode if proc else None,
              'outcome': reason or ('passed' if proc and proc.returncode == 0 and not errors else 'failed'),
              'errors': errors, 'signals_received': signals, 'control_actions': actions,
              'source_sha256': source_hash, 'source_unchanged': unchanged,
              'log_bytes': log_path.stat().st_size if log_path.exists() else None,
              'log_sha256': digest(log_path) if log_path.exists() else None,
              'output_exists': output.exists(),
              'output_sha256': digest(output) if output.exists() else None,
              'maximum_sampled_rss_bytes': max(
                  [sum(p['rss_bytes'] for p in s['processes']) for s in samples] +
                  [r['rss_bytes'] for r in resources], default=0),
              'minimum_sampled_host_available_bytes': min(
                  (r['memory']['MemAvailable'] for r in resources), default=None),
              'compiled_axiom_audit_performed': False,
              'isolated_acceptance_claimed': False}
    record(run / 'terminal.json', result)
    print(json.dumps({'terminal': result}), flush=True)
    return 0 if result['outcome'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
