import PscVerif.ArchivedGraphRefinement
import Mathlib.Tactic.FinCases

/-!
Exact theorem extracted from parent PR #564 at
16dd825648d1a1bcdba9038e079463a9bebbaf3d, with the proposed three reversed-
intersection tactic replacements. Uses the actual project overlap and
archivedRoot definitions. No axioms or substitute definitions are introduced.
Prepared for a focused compile; no compile outcome is asserted here.
-/

open Set

namespace Psc.NamedStrictExclusion

open Psc.OccurrencePiece Psc.ArchivedGraphRefinement

theorem intersection_eq_archivedRoot {G : Type*} [AddCommGroup G]
    (star : (Fin 3 → ℤ) →+ G) (K : Fin 3 → Set G)
    (a b : Fin 3) (hab : a ≠ b) :
    ∃ k : Fin 3, K a ∩ K b = overlap star K (archivedRoot k) := by
  fin_cases a <;> fin_cases b
  · exact (hab rfl).elim
  · exact ⟨0, by ext x; simp [overlap, archivedRoot]⟩
  · exact ⟨1, by ext x; simp [overlap, archivedRoot]⟩
  · exact ⟨0, by rw [Set.inter_comm]; ext x; simp [overlap, archivedRoot]⟩
  · exact (hab rfl).elim
  · exact ⟨2, by ext x; simp [overlap, archivedRoot]⟩
  · exact ⟨1, by rw [Set.inter_comm]; ext x; simp [overlap, archivedRoot]⟩
  · exact ⟨2, by rw [Set.inter_comm]; ext x; simp [overlap, archivedRoot]⟩
  · exact (hab rfl).elim

end Psc.NamedStrictExclusion
