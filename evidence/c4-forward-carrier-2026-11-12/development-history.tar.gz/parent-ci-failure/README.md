# Parent #564 CI failure: exact source diagnosis

The C4 overlap Lean verification run **43345576693** failed at parent head
`16dd825648d1a1bcdba9038e079463a9bebbaf3d`. The concrete blocker is a proof
elaboration failure in `NamedStrictExclusion.intersection_eq_archivedRoot`,
at source line 42, column 14. Toolchain provisioning succeeded. This failure
is neither a timeout nor a failed dependency download.

[GitHub run](https://github.com/larsbx/pisot-substitution-conjecture-research/actions/runs/43345576693)

## Observed diagnostic

```text
error: PscVerif/NamedStrictExclusion.lean:42:14: unsolved goals
⊢ x ∈ K 1 ∧ x ∈ K 0 ↔ x ∈ K 0 ∧ x ∈ K 1
```

The same diagnostic reports that `and_comm` in the simplifier list was
unused. Lake names `PscVerif.NamedStrictExclusion` as its failed target,
and the workflow step exits 1. The complete fetched job log and downloaded
audit artifact both contain this diagnostic.

## Minimal repair and its focused validation

In the three reversed-letter branches, replace:

```lean
by ext x; simp [overlap, archivedRoot, and_comm]
```

with:

```lean
by rw [Set.inter_comm]; ext x; simp [overlap, archivedRoot]
```

`Set.inter_comm` first changes the left intersection to the archived
zero-offset root's order. Extensional simplification then performs the
same computation that succeeds in each corresponding forward branch.
The theorem statement, hypotheses, root definitions, and scope are unchanged.
The unapplied exact diff is `NamedStrictExclusion-proposed.diff`.

`NamedStrictExclusion-intersection-probe.lean` extracts the actual repaired
theorem and imports `PscVerif.ArchivedGraphRefinement` plus
`Mathlib.Tactic.FinCases`. It uses the actual project `overlap` and
`archivedRoot`, with no stand-in definition or new axiom.

The authorized focused compiler run used pinned Lean v4.34.0-rc2 and the
coordinated actual project object plus fresh package cache. **It exited 0
in 2.620683 seconds**, at `2026-11-13T04:17:28.322444+00:00`, with empty
stdout and stderr. Selected source/object hashes were unchanged. The
90-second bound was not reached. Exact command, dependency paths, hashes,
logs and compiled object are under `probe-run02`.

The preceding `probe-run01` is retained: it stopped after 0.064328 seconds
because the input was outside the chosen working root. It did not elaborate
the theorem. Only cwd was corrected for `probe-run02`; the probe source was
unchanged.

## Scope and preserved material

This establishes a focused repair for the exact failing theorem fragment.
It does not establish acceptance of the full named module, the full named
chain, or its transitive-axiom audit. The original parent CI run remains a
failed receipt. At the separately saved workflow snapshot, original payload
run `43345576753` was still in progress; no later outcome is inferred here.

This investigation made no tracked source edit, parent-branch change,
remote write, or workflow rerun. Root separately coordinates any integration
of the repair into its new forward-carrier branch.

The directory retains the raw fetched connector responses, exact-head
workflow and source, full decoded job log, a compact diagnostic excerpt,
the original artifact ZIP and extracted audit log, the proposed diff,
probe source, and both probe attempt receipts. The downloaded ZIP's
SHA256 `c9ee81c9cd6c781526bbfed77e10368ec5bcb261326344d623d512a248bae93c`
matches GitHub's artifact metadata. `summary.json` provides identifiers,
hashes and explicit scope flags. `SHA256SUMS` covers every retained file
other than itself.
