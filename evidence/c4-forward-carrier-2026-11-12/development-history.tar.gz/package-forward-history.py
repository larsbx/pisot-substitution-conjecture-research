from pathlib import Path
import gzip, hashlib, io, json, tarfile

base = Path(__file__).resolve().parent
out = base / "psc/evidence/c4-forward-carrier-2026-11-12"
directories = [
    "forward-native", "forward-carrier-dev", "fast-forward-carrier-dev",
    "named-forward-carrier-dev", "forward-scoped-audit", "diagnostic_prefix",
    "forward-replay-01", "forward-replay-02", "forward-source-validation",
    "forward-final-validation", "parent-ci-failure", "parent-productivity-dev",
    "parent-payload-final", "forward-publication-checks",
]
files = [Path(__file__)]
for directory in directories:
    root = base / directory
    if not root.is_dir():
        raise SystemExit(f"Missing completed evidence directory: {root}")
    files.extend(p for p in root.rglob("*") if p.is_file()
                 and "__pycache__" not in p.parts and ".git" not in p.parts)
files = sorted(files, key=lambda p: p.relative_to(base).as_posix())
index = []
tar_buffer = io.BytesIO()
with tarfile.open(fileobj=tar_buffer, mode="w", format=tarfile.PAX_FORMAT) as archive:
    for path in files:
        before = path.stat()
        raw = path.read_bytes()
        after = path.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise SystemExit(f"Refusing moving evidence: {path}")
        relative = path.relative_to(base).as_posix()
        info = tarfile.TarInfo(relative)
        info.size = len(raw)
        info.mode = 0o755 if before.st_mode & 0o111 else 0o644
        info.mtime = 0
        info.uid = info.gid = 0
        archive.addfile(info, io.BytesIO(raw))
        index.append({"path": relative, "bytes": len(raw),
                      "sha256": hashlib.sha256(raw).hexdigest()})
compressed = io.BytesIO()
with gzip.GzipFile(filename="", mode="wb", fileobj=compressed, mtime=0) as stream:
    stream.write(tar_buffer.getvalue())
archive_path = out / "development-history.tar.gz"
archive_path.write_bytes(compressed.getvalue())
receipt = {
    "format": "tar with deterministic gzip container; original member bytes unchanged",
    "scope": "all regular retained files in listed scratch evidence directories; __pycache__ excluded",
    "directories": directories,
    "archive": archive_path.name,
    "archive_sha256": hashlib.sha256(compressed.getvalue()).hexdigest(),
    "archive_bytes": len(compressed.getvalue()),
    "uncompressed_tar_sha256": hashlib.sha256(tar_buffer.getvalue()).hexdigest(),
    "member_count": len(index),
    "members": index,
}
(out / "history-index.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
with tarfile.open(archive_path, "r:gz") as check:
    actual = {m.name: hashlib.sha256(check.extractfile(m).read()).hexdigest()
              for m in check.getmembers() if m.isfile()}
assert actual == {r["path"]: r["sha256"] for r in index}
print(json.dumps({k: receipt[k] for k in ("member_count", "archive_bytes", "archive_sha256")}))
