#!/usr/bin/env python3
"""Watch host memory and compiler samples; stop only the named owned attempt."""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import time


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


ap = argparse.ArgumentParser()
ap.add_argument('--attempt', required=True)
args = ap.parse_args()
if not args.attempt.replace('-', '').isalnum():
    raise ValueError('Unsafe attempt label')
run = Path(__file__).resolve().parent / args.attempt
if not (run / 'start.json').exists():
    raise ValueError('Attempt has not started')
rss_limit = 5_000_000_000
available_floor = 1_073_741_824
start = {'at_utc': now(), 'rss_limit_bytes': rss_limit,
         'available_floor_bytes': available_floor,
         'rss_observation': 'latest actual sample recorded by compiler runner; up to 15 seconds old',
         'host_memory_poll_seconds': 1,
         'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(run / 'resource-watch-start.json').write_text(json.dumps(start, indent=2) + '\n')
print(json.dumps({'watch_start': start}), flush=True)
begun = time.monotonic()
trigger = None
observations = 0
while not (run / 'terminal.json').exists() and time.monotonic() - begun < 650:
    memory = {line.split(':')[0]: int(line.split()[1]) * 1024
              for line in Path('/proc/meminfo').read_text().splitlines()
              if line.split(':')[0] in {'MemTotal', 'MemAvailable', 'MemFree', 'SwapFree'}}
    lines = (run / 'samples.jsonl').read_text().splitlines()
    # The runner writes one JSON line atomically; an in-flight tail is skipped.
    try:
        sample = json.loads(lines[-1])
    except (IndexError, json.JSONDecodeError):
        time.sleep(1)
        continue
    rss = sum(p['rss_bytes'] for p in sample['processes'])
    observation = {'at_utc': now(), 'memory': memory, 'sample_at_utc': sample['at_utc'],
                   'sample_elapsed_seconds': sample['elapsed_seconds'],
                   'sample_rss_bytes': rss}
    with (run / 'resource-watch-samples.jsonl').open('a') as stream:
        stream.write(json.dumps(observation, sort_keys=True) + '\n')
    observations += 1
    if rss > rss_limit or memory['MemAvailable'] < available_floor:
        trigger = {'outcome': 'resource_refusal_requested', 'observation': observation,
                   'reason': 'sampled_rss_limit' if rss > rss_limit else 'host_available_memory_floor',
                   'action': 'write only this owned attempt STOP marker; runner controls its own compiler process group'}
        (run / 'resource-refusal.json').write_text(json.dumps(trigger, indent=2) + '\n')
        (run / 'STOP').write_text(json.dumps(trigger) + '\n')
        print(json.dumps(trigger), flush=True)
        break
    time.sleep(1)
result = {'ended_at_utc': now(), 'elapsed_seconds': round(time.monotonic() - begun, 3),
          'observations': observations, 'trigger': trigger,
          'compiler_terminal_present': (run / 'terminal.json').exists()}
(run / 'resource-watch-terminal.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'watch_terminal': result}), flush=True)
