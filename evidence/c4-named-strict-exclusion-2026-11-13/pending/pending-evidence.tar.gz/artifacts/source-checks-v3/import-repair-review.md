# Source-only review of the negative-control import repair

Reviewed commit `16dd825648d1a1bcdba9038e079463a9bebbaf3d`, tree `ae73f53be5b43879d92c8995597960909afef684`. No Lean/compiler process was invoked.

The previous bad fixture imported only `PscVerif.ArchivedPayloadConsumer`. Its 50-module project closure did not contain `PscVerif.StrictSystem`; adding the full auditor's `ArchivedPayloadEmit` import gave 51 modules and still omitted the definition.

The corrected fixture explicitly imports `PscVerif.StrictSystem`. Its 76-module project closure now contains the definition of `Psc.StrictSystem.StrictSystem`, together with the already available named substitution and word-pair type. The actual generated payload already imports `NamedStrictExclusion`; its 89-module closure contains the required definition.

The only changes since the reviewed previous head are the fixture import and its documentation/side-ledger record. The traversed project dependency modules are unchanged. Exact closures and fixture hashes are in `import-repair-review.json`.

This source review confirms the missing definition is imported. It does not claim that Lean has yet rejected the wrong theorem with the intended type-mismatch diagnostic; that remains a compiled-gate obligation.
