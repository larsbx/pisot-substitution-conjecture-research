# Source-equality carry-forward provenance

Revalidated at `2026-11-13T01:34:03.117242+00:00` by `/root/c4_main_audit`.

The original static review was performed on commit `137d1e980418f34f9eb5e92142d5bbc53b4368e6`, tree `0c15c2ebf0de0354f8d0592e3b3c958cb12c3aea`. Its original artifacts remain unchanged in `/workspace/scratch/5535bb23ca85/static-review-v2`. This package carries that review forward to published commit `16dd825648d1a1bcdba9038e079463a9bebbaf3d`, tree `ae73f53be5b43879d92c8995597960909afef684`, by exact source equality. It does not represent a new kernel check, an additional independent-agent review, or a human review, and it does not claim an outcome for the running full gate.

## Verified source identity

- The entire `proof` subtree has the same Git tree ID at both revisions: `3de81494bdebbd491330ba452100e95c5c5a74a5`. It contains 234 tracked files, including 159 Lean sources.
- All 23 repository sources individually inventoried by the original review have identical bytes at both commits and in the current working tree. This includes both new modules, their inventoried proof dependencies, the proof bank, and the existing audit tools.
- The original declaration inventory is unchanged: eight consumer/support theorems, two control theorems, and two definitions. The ten named theorems retain proof-bank coverage.
- The pinned Lean and Mathlib identities are unchanged. Primary Mathlib source citations and hashes are retained from the original review.

## Exact change outside the proof tree

Git reports only these changed paths between the two commits:

- `docs/c4-named-strict-exclusion.md`
- `docs/side-notes-ledger.md`
- `tests/fixtures/c4_archived_bad_binding.lean`

The fixture change adds exactly `import PscVerif.StrictSystem` after its existing `ArchivedPayloadConsumer` import. Its definitions and deliberately incorrect theorem types are unchanged. This note verifies the source change only; acceptance and rejection behavior must come from the new gate.

The current fixture has Git blob `d852ed855f96c15c38d193d6da3be4ba1e416d8d` and SHA-256 `9adbb304ce94013457bc3fdde4cebd640361344f0dc334d8a8f3d60202ca3c7c`. Old and new hashes for all three changed paths are recorded in `source-metadata.json`.

## Artifact provenance

`source-metadata.json` now names the new subject commit and tree, while its `original_review` and `source_equality_revalidation` records preserve the exact prior subject, date, reviewers, and artifact hashes. The original review involved the author agent and a separate independent agent; that distinction carries forward without claiming that either is a human reviewer.

The v3 static review and audit guidance should be read with this provenance note. No repository source was changed, no Lean job was run, and no new tests were performed during this carry-forward operation.
