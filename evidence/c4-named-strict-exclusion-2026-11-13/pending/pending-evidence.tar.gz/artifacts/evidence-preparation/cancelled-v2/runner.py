from pathlib import Path
import datetime, hashlib, json, os, subprocess, time
root = Path("/workspace/scratch/5535bb23ca85/psc")
work = root.parent / "isolated-v2"
work.mkdir(exist_ok=False)
(work / "tmp").mkdir()
expected = "137d1e980418f34f9eb5e92142d5bbc53b4368e6"
def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()
assert git("rev-parse", "HEAD") == expected
assert not git("status", "--porcelain")
exporter = root.parent / "c4-archived-export"
command = ["./tools/check_lean.sh", "--archived-packets", str(exporter), str(work / "replay")]
env = dict(os.environ)
env.update(ELAN_HOME="/workspace/scratch/84c835820757/toolchains/elan", PATH="/workspace/scratch/84c835820757/toolchains/elan/bin:/usr/local/bin:/usr/bin:/bin", TMPDIR=str(work / "tmp"))
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
started = time.monotonic()
receipt = {"schema": "c4-named-strict-exclusion-gate-start-v1", "started_at_utc": now(), "source_commit": expected, "source_tree": git("rev-parse", "HEAD^{tree}"), "source_status": git("status", "--porcelain"), "cwd": str(root), "command": command, "environment_overrides": {k:env[k] for k in ["ELAN_HOME", "PATH", "TMPDIR"]}, "checker_sha256": hashlib.sha256((root / "tools/check_lean.sh").read_bytes()).hexdigest(), "exporter_sha256": hashlib.sha256(exporter.read_bytes()).hexdigest(), "lean_toolchain": (root / "proof/PscVerif/lean-toolchain").read_text().strip(), "memory_before": subprocess.check_output(["free", "-b"], text=True), "prior_attempt_exit_code": 137}
(work / "start.json").write_text(json.dumps(receipt, indent=2)+"\n")
print(json.dumps({"started_at_utc": receipt["started_at_utc"], "commit": expected, "tree": receipt["source_tree"], "command": command}), flush=True)
with (work / "full.log").open("wb") as log:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    (work / "process.json").write_text(json.dumps({"pid": process.pid, "launched_at_utc": now()}, indent=2)+"\n")
    result = process.wait()
terminal = {"ended_at_utc": now(), "exit_code": result, "elapsed_seconds": round(time.monotonic()-started,3), "source_commit": expected, "source_tree": receipt["source_tree"], "raw_log_bytes": (work / "full.log").stat().st_size, "raw_log_sha256": hashlib.sha256((work / "full.log").read_bytes()).hexdigest(), "final_checkout_commit": git("rev-parse", "HEAD"), "final_checkout_status": git("status", "--porcelain")}
(work / "terminal.json").write_text(json.dumps(terminal, indent=2)+"\n")
print(json.dumps(terminal), flush=True)
raise SystemExit(result if result >= 0 else 128-result)
