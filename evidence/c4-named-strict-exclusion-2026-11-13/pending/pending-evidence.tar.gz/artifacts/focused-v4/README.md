# Focused v4 development compilation

The first requested development build, `PscVerif.NamedPositiveOverlap`, reached its 1200-second time limit and was terminated through the controller-owned pidfd. No later development module or independent archive branch was started. This is incomplete development evidence; it supplies no successful compilation, source/type-error finding, or isolated acceptance result.

| Field | Observed value |
| --- | --- |
| Source commit | `16dd825648d1a1bcdba9038e079463a9bebbaf3d` |
| Source tree | `ae73f53be5b43879d92c8995597960909afef684` |
| Attempt start | `2026-11-13T03:07:19.439490+00:00` |
| Attempt end | `2026-11-13T03:27:19.884363+00:00` |
| Elapsed | `1200.369` seconds |
| Result | `timeout_1200s` |
| Actual compiler return code | `-15` (SIGTERM) |
| Observed controller exit code | `1` |
| Minimum MemAvailable | `2957926400` bytes (2.755 GiB) |
| Diagnostic log | `0` bytes |
| Produced object/companions | None |
| Source and tracked invocation artifacts unchanged | `True` |

The 1 GiB memory stop was never triggered. The unchanged `lean-dev.sh` invokes the pinned `leanprover/lean4:v4.34.0-rc2` executable with `-j 1 -DautoImplicit=false`. The complete argument array, original source SHA-256, compiler/wrapper/controller hashes, direct prerequisite object hashes, process identity, memory samples, and terminal result are retained in the JSON files.

Before launch, the source-match check verified all 84 entries in `focused-cache-sources.json`. The fresh-object v3 provenance also matched all 31 module source hashes and all 66 recorded artifact sizes and hashes. An independent agent verified the recursive local-import closure: exactly seven requested target objects were missing, with no additional missing prerequisites.

The source worktree remains clean. No Lean source, compiler, checker, pinned dependency, or isolated workspace was edited. The full isolated V4 gate was not signaled or otherwise changed. The failed attempt and empty raw compiler log are preserved without modification.

## Evidence index

- `run-start.json`: original source/invocation hashes, source inventory, plan and resource limits.
- `dependency-verification.json`: source-match and fresh-object provenance verification.
- `01-NamedPositiveOverlap.start.json`: exact per-module command and prerequisite identities.
- `01-NamedPositiveOverlap.process.json`: launched development process identity.
- `01-NamedPositiveOverlap.log`: original combined compiler stdout/stderr, empty.
- `01-NamedPositiveOverlap.terminal.json`: actual return code, elapsed time, output inventory and memory samples.
- `run-terminal.json`: stopped development sequence and terminal source identity.
- `controller-exit.json`: observed enclosing controller exit code and confirmation that no later branch started.
- `run_development.py`: exact development controller used.
- `SHA256SUMS`: artifact hashes, excluding this checksum manifest itself.
