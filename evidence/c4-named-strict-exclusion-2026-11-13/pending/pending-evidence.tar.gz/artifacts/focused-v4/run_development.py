#!/usr/bin/env python3
"""Sequential development builds only; never isolated acceptance."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

BASE = Path('/workspace/scratch/5535bb23ca85')
REPO = BASE / 'psc'
PROJECT = REPO / 'proof/PscVerif'
OUT = BASE / 'focused-v4'
WRAPPER = BASE / 'lean-dev.sh'
COMPILER = Path('/workspace/scratch/84c835820757/toolchains/elan/toolchains/leanprover--lean4---v4.34.0-rc2/bin/lean')
COMMIT = '16dd825648d1a1bcdba9038e079463a9bebbaf3d'
TREE = 'ae73f53be5b43879d92c8995597960909afef684'
LIMIT = 1200
MIN_MEMORY = 1024 ** 3
MODULES = ['NamedPositiveOverlap', 'NamedPositiveOverlapControls', 'NamedArchivedDigits', 'ArchivedPayload', 'ArchivedPayloadConsumer', 'NamedStrictExclusion', 'NamedStrictExclusionControls']
CANCEL = []

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def source_state():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1', '--untracked-files=all')}

def memory():
    return int(next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')).split()[1]) * 1024

def stop_owned(process, fd):
    if process.poll() is None:
        try:
            signal.pidfd_send_signal(fd, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            signal.pidfd_send_signal(fd, signal.SIGKILL)
            process.wait(timeout=5)

def on_signal(sig, frame):
    CANCEL.append(sig)

for sig in (signal.SIGINT, signal.SIGTERM):
    signal.signal(sig, on_signal)

initial = source_state()
assert initial == {'commit': COMMIT, 'tree': TREE, 'status': ''}, initial
assert '-j 1' in WRAPPER.read_text()
assert (PROJECT / 'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.34.0-rc2'
manifest_paths = [BASE / 'focused-build-order.json', BASE / 'focused-cache-sources.json', BASE / 'development-fresh-objects-v2.json', BASE / 'development-fresh-objects-v3.json']
cache_manifest = json.loads((BASE / 'focused-cache-sources.json').read_text())
for entry in cache_manifest:
    assert digest(PROJECT / entry['module']) == entry['source_sha256'], entry['module']
source_files = {str(p.relative_to(REPO)): digest(p) for p in sorted((PROJECT / 'PscVerif').glob('*.lean'))}
initial_hashes = {'wrapper': digest(WRAPPER), 'compiler': digest(COMPILER), 'controller': digest(__file__)}
start = {'scope': 'Sequential development compilation, not isolated acceptance.', 'at_utc': now(), 'source': initial, 'source_sha256': source_files, 'artifact_sha256': initial_hashes, 'manifests': [{'path': str(p), 'sha256': digest(p)} for p in manifest_paths], 'modules': MODULES, 'timeout_per_module_seconds': LIMIT, 'minimum_available_memory_bytes': MIN_MEMORY, 'one_compiler_at_a_time': True, 'output_directory': str(PROJECT / '.lake/build/lib/lean/PscVerif')}
write(OUT / 'run-start.json', start)
print(json.dumps({'event': 'development_start', 'at_utc': now(), 'modules': MODULES, 'available_memory_bytes': memory()}), flush=True)
results = []
for index, name in enumerate(MODULES, 1):
    source = PROJECT / 'PscVerif' / (name + '.lean')
    output = PROJECT / '.lake/build/lib/lean/PscVerif' / (name + '.olean')
    ilean = output.with_suffix('.ilean')
    prefix = OUT / f'{index:02d}-{name}'
    state = source_state()
    assert state == initial, state
    assert digest(source) == source_files[str(source.relative_to(REPO))]
    assert not output.exists(), f'Output already exists before requested missing build: {output}'
    deps = re.findall(r'^import\s+(PscVerif\.[A-Za-z0-9_.]+)', source.read_text(), re.M)
    prerequisites = []
    for dep in deps:
        dep_source = PROJECT / (dep.replace('.', '/') + '.lean')
        dep_object = PROJECT / '.lake/build/lib/lean' / (dep.replace('.', '/') + '.olean')
        assert dep_object.is_file(), f'Missing prerequisite: {dep}'
        prerequisites.append({'module': dep, 'source_sha256': digest(dep_source), 'object_sha256': digest(dep_object), 'object_bytes': dep_object.stat().st_size})
    command = [str(WRAPPER), '-o', str(output), '-i', str(ilean), str(source)]
    attempt_start = {'scope': 'Development only', 'at_utc': now(), 'module': 'PscVerif.' + name, 'source': state, 'source_path': str(source), 'source_sha256': digest(source), 'command': command, 'cwd': str(PROJECT), 'prerequisites': prerequisites, 'timeout_seconds': LIMIT, 'available_memory_bytes': memory(), 'artifact_sha256': initial_hashes}
    write(str(prefix) + '.start.json', attempt_start)
    if memory() < MIN_MEMORY or CANCEL:
        reason = 'memory_below_threshold_before_launch' if not CANCEL else 'cancelled_before_launch'
        result = {'module': 'PscVerif.' + name, 'outcome': reason, 'started': False, 'at_utc': now()}
        write(str(prefix) + '.terminal.json', result)
        results.append(result)
        break
    process = None
    fd = None
    reason = None
    error = None
    started = time.monotonic()
    min_mem = memory()
    samples = []
    with open(str(prefix) + '.log', 'xb') as log:
        try:
            process = subprocess.Popen(command, cwd=PROJECT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            fd = os.pidfd_open(process.pid, 0)
            write(str(prefix) + '.process.json', {'pid': process.pid, 'controller_pid': os.getpid(), 'launched_at_utc': now(), 'command': command})
            print(json.dumps({'event': 'module_start', 'module': name, 'pid': process.pid, 'at_utc': now()}), flush=True)
            heartbeat = 0.0
            while process.poll() is None:
                elapsed = time.monotonic() - started
                available = memory()
                min_mem = min(min_mem, available)
                if elapsed >= heartbeat:
                    sample = {'at_utc': now(), 'elapsed_seconds': round(elapsed, 3), 'available_memory_bytes': available}
                    samples.append(sample)
                    print(json.dumps({'event': 'module_heartbeat', 'module': name, **sample}), flush=True)
                    heartbeat = elapsed + 30
                if available < MIN_MEMORY:
                    reason = 'memory_below_1GiB'
                    break
                if elapsed >= LIMIT:
                    reason = 'timeout_1200s'
                    break
                if CANCEL:
                    reason = 'controller_cancelled'
                    break
                time.sleep(0.5)
        except Exception as exc:
            error = repr(exc)
            reason = 'controller_error'
        finally:
            if process is not None and process.poll() is None:
                if fd is not None:
                    stop_owned(process, fd)
                else:
                    process.terminate()
                    process.wait(timeout=5)
            if fd is not None:
                os.close(fd)
    elapsed = time.monotonic() - started
    exit_code = process.returncode if process is not None else None
    log_path = Path(str(prefix) + '.log')
    outputs = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(output.parent.glob(name + '.*')) if p.is_file()]
    unchanged = source_state() == initial and digest(source) == attempt_start['source_sha256'] and digest(WRAPPER) == initial_hashes['wrapper'] and digest(COMPILER) == initial_hashes['compiler']
    outcome = reason or ('compiled' if exit_code == 0 and output.exists() and unchanged else 'compiler_or_identity_failure')
    result = {'scope': 'Development only; not isolated acceptance', 'module': 'PscVerif.' + name, 'started': process is not None, 'started_at_utc': attempt_start['at_utc'], 'ended_at_utc': now(), 'elapsed_seconds': round(elapsed, 3), 'gate_or_global_acceptance_claimed': False, 'compiler_returncode': exit_code, 'outcome': outcome, 'controller_error': error, 'minimum_available_memory_bytes': min_mem, 'source_and_artifacts_unchanged': unchanged, 'source_sha256': attempt_start['source_sha256'], 'command': command, 'log_path': str(log_path), 'log_bytes': log_path.stat().st_size, 'log_sha256': digest(log_path), 'outputs': outputs, 'samples': samples}
    write(str(prefix) + '.terminal.json', result)
    results.append(result)
    write(OUT / 'progress.json', {'at_utc': now(), 'results': results})
    print(json.dumps({'event': 'module_end', 'module': name, 'outcome': outcome, 'compiler_returncode': exit_code, 'elapsed_seconds': round(elapsed, 3), 'log_path': str(log_path)}), flush=True)
    if outcome != 'compiled':
        break
terminal = {'scope': 'Development results only; full isolated gate remains the acceptance authority.', 'at_utc': now(), 'source': source_state(), 'results': results, 'all_requested_modules_compiled': len(results) == len(MODULES) and all(r['outcome'] == 'compiled' for r in results), 'cancelled_signals': CANCEL}
write(OUT / 'run-terminal.json', terminal)
print(json.dumps({'event': 'development_end', 'all_requested_modules_compiled': terminal['all_requested_modules_compiled'], 'results': len(results)}), flush=True)
raise SystemExit(0 if terminal['all_requested_modules_compiled'] else 1)
