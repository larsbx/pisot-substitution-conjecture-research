# Extracting the new compiled declarations after gate success

This note is a postprocessing recipe. It does not assert that the running gate has completed. Preserve the actual enclosing process receipt, exit code, source/tree identity, and complete unmodified raw log first. A successful partial module build or a source inventory is not the complete acceptance result.

## Reuse the existing checker

At the pinned subject revision, the unchanged `ProofBankAudit.lean` emits one tab-separated row per compiled local constant:

```text
PSC_AXIOMS<TAB>kind<TAB>owner_module<TAB>compiled_name<TAB>user_name<TAB>axiom_csv
PSC_AUDIT_COMPLETE<TAB>constant_count<TAB>theorem_count
```

`tools/make_proof_bank.py` already checks record shape, duplicate compiled names, completion counts, owner scope, the standard axiom allowlist, ordering, and presence of every inventoried named theorem. The published proof bank already includes all ten new named theorems. After successful completion, its existing read-only check can consume the complete raw gate log; the parser ignores the separately prefixed archived-payload rows:

```sh
python3 -B tools/make_proof_bank.py --check --audit-log /absolute/path/to/complete-raw-gate.log
```

This reruns no Lean compilation. Run it against the recorded subject source, or separately verify that every relevant source byte still matches that subject. No new repository test is needed for the coverage already enforced by this existing checker.

## Exact local extraction

For the concise new-module evidence supplement, parse the same full raw log and select rows whose owner field is exactly:

- `PscVerif.NamedStrictExclusion`
- `PscVerif.NamedStrictExclusionControls`

Use the complete expected inventory from `source-metadata.json`, rather than deriving a namespace from the owning module. For each of its twelve explicit declarations, require exactly one row with the recorded owner and complete user name, the expected compiled kind, and—because every new declaration is public—the same compiled name as user name. All ten proofs must have kind `theorem`; `diagonalTiles` and `omittedRootTiles` must have kind `declaration`.

The consumer module contains two namespaces: the four `Psc.NamedStrictExclusion.*` proofs and four `Psc.ArchivedPayload.Packet.*` proofs. They all belong to owner `PscVerif.NamedStrictExclusion`. These distinctions are material to matching the records.

Extract **all** rows owned by the two new modules, including any compiler-generated helpers. Report their actual constant/theorem totals separately from the fixed source totals of ten theorem declarations and two definitions; do not assume the compiled totals are exactly twelve. Check the axiom allowlist `propext`, `Classical.choice`, `Quot.sound` on the complete audit, not just the extracted rows.

Record the raw log SHA-256, extracted rows SHA-256, source-metadata SHA-256, subject commit/tree, global completion counts, and the post-audit acknowledgement:

```text
Lean axiom audit: N declarations, M theorems; all named proofs reached
```

The enclosing gate's actual exit status and both concrete payload receipts remain separate evidence. A declaration-extraction report cannot attest them by itself.

## What to reuse from the #560 inspector

The existing reference is `evidence/c4-finite-cut-count-2026-11-12/gate/inspect-count-audit.py`, bound in `source-metadata.json`. It provides the right checks for unique `PSC_AUDIT_COMPLETE`, exact counts, expected declaration identities/kinds, standard axioms, and hashes of the complete input and extracted output.

Do **not** run that inspector unchanged for the new modules:

1. Its `EXPECTED` table and count assertions are for twelve older theorems and three older definitions.
2. It assumes one `Psc.<module>` namespace and a short declaration name without dots. The new consumer also contains the explicitly qualified `Packet.no_*` declarations inside `Psc.ArchivedPayload`.
3. It requires the final nonempty raw-log line to be a proof-bank summary. The combined `check_lean.sh --archived-packets` run continues after that summary with two generated payload builds, exact-type/axiom audits, independent packet replay, and a JSON receipt. Retain the genuine full log; validate the main audit acknowledgement at its proper position and the separate final combined-gate receipt, rather than trimming away the payload phase to satisfy the older predicate.

A small postprocessor can reuse `make_proof_bank.check_audit` for the global check and use the already-written explicit source metadata for the twelve exact matches. That is an evidence extraction step, not a new mathematical test or a substitute for the combined gate.
