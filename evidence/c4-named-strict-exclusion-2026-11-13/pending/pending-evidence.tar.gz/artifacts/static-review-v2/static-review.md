# Named strict exclusion: static source review

**Result:** no additional concrete likely elaboration or type defect was identified in the two new modules. This is an agent source review, not a Lean acceptance result or independent human review.

The review is bound to published commit `137d1e980418f34f9eb5e92142d5bbc53b4368e6`, tree `0c15c2ebf0de0354f8d0592e3b3c958cb12c3aea`, in `larsbx/pisot-substitution-conjecture-research`. The selected working source bytes were compared directly with that commit. The pinned compiler is `leanprover/lean4:v4.34.0-rc2`; the inspected primary Mathlib sources are at `4edb0dbaa3b3cf729d86d1e2f035474d5ae2ac09`.

The author agent `/root/c4_main_audit` performed a follow-up static review. A separate agent, `/root/c4_main_audit/haar_static_check`, independently read the source and pinned Mathlib definitions without writing the code, changing files, or running Lean. Neither review certifies compiled declarations, their transitive axioms, the running gate's exit status, or the concrete generated payloads. Earlier resource failures receive no acceptance credit here.

## Reviewed scope

The source contains **eight consumer/support theorems, two counterexample theorems, and two definitions**. All ten named theorems occur in the published `proof/proof-bank.json`; the aggregate imports both modules. The metadata records every declaration's complete name, owner module, source line, expected compiled kind, and visibility.

| Owning module | Reviewed declarations |
| --- | --- |
| `PscVerif.NamedStrictExclusion` | `Psc.NamedStrictExclusion.intersection_eq_archivedRoot`, `carrierOverlap_subset_archivedRoots`, `no_strictSystem_of_roots_null`, `exists_probabilityHaar` |
| `PscVerif.NamedStrictExclusion` | `Psc.ArchivedPayload.Packet.no_strictSystem_of_measure`, `no_strictSystem`, `no_strictComponent`, `no_bpaStrictComponent` |
| `PscVerif.NamedStrictExclusionControls` | Theorems `dropping_distinct_labels_counterexample` and `omitting_root_counterexample`; definitions `diagonalTiles` and `omittedRootTiles`, all in `Psc.NamedStrictExclusionControls` |

The final packet theorem discharges normalized Haar existence internally. It excludes finite strict systems of arbitrary finite size for the packet's authenticated literal fixture. Its substitution parameter is still `Fin 2`: `1/021/001` and `1/012/001`. It adds no universal C4, G1, BH, pure discrete spectrum, or PSC conclusion.

## Checked interfaces and primary sources

1. **Compact original carrier.** `NamedFundamentalCell.M f` and `NamedProductHaar.M (substitution f)` reduce to `OccurrenceResidue.incidenceLinear (substitution f)`. The named `integral_injective` proof and `NamedPrefixCompact.incidence_eq` supply exactly the premise of `MadicResidue.carrier_compactSpace`. The carrier is the compatible-sequence submodule of the product of discrete residue groups; its additive zero supplies nonemptiness. Sources: `proof/PscVerif/PscVerif/{NamedFundamentalCell,NamedProductHaar,NamedPrefixCompact,OccurrenceResidue,MadicResidue}.lean` at the subject commit.

2. **Normalized Haar construction.** Pinned [Mathlib/MeasureTheory/Measure/Haar/Basic.lean](https://github.com/leanprover-community/mathlib4/blob/4edb0dbaa3b3cf729d86d1e2f035474d5ae2ac09/Mathlib/MeasureTheory/Measure/Haar/Basic.lean#L515) supplies the additive factory, self-normalization theorem, and additive Haar instance through `to_additive`. Pinned [Mathlib/Topology/Sets/Compacts.lean](https://github.com/leanprover-community/mathlib4/blob/4edb0dbaa3b3cf729d86d1e2f035474d5ae2ac09/Mathlib/Topology/Sets/Compacts.lean#L700) supplies the top positive compact set; its coercion to `Set.univ` is definitionally equal. `MadicHaar.lean` supplies the carrier's measurable and Borel instances.

3. **Probability witness.** Pinned [Mathlib/MeasureTheory/Measure/Typeclasses/Probability.lean](https://github.com/leanprover-community/mathlib4/blob/4edb0dbaa3b3cf729d86d1e2f035474d5ae2ac09/Mathlib/MeasureTheory/Measure/Typeclasses/Probability.lean#L64) defines `IsProbabilityMeasure` with the one field `measure_univ`. The same construction—`addHaarMeasure` on the top positive compact set, followed by `IsProbabilityMeasure.mk addHaarMeasure_self`—appears in pinned [Mathlib/Analysis/Fourier/AddCircle.lean](https://github.com/leanprover-community/mathlib4/blob/4edb0dbaa3b3cf729d86d1e2f035474d5ae2ac09/Mathlib/Analysis/Fourier/AddCircle.lean#L84). This supports the exact normalization pattern used here; actual elaboration remains to be checked.

4. **Actual root coverage.** `NamedCutNeighborhood.carrierOverlap` is the three nested unions unpacked by the proof. `StrictSystem.StrictSystem.cutPair_ne` supplies unequal labels. `ArchivedGraphRefinement.archivedRoot` lists `01`, `02`, and `12`, each with zero displacement. `OccurrencePiece.overlap` therefore reduces to the corresponding intersection. The six off-diagonal cases are covered; reversed order uses intersection commutativity only at zero displacement.

5. **Same product measure.** `NamedFundamentalCell.internalMeasure f ν` reduces to `(volume : Measure Stable).prod ν`, which is precisely the measure in `ArchivedPayload.Packet.roots_null`. The existing contradiction is `PscVerif.OverlapContraction.no_positive_subset_of_null`. No archive-to-all-`strictPackets` identification, odd-ancestry extension, Jacobian normalization, or additional frequency hypothesis is required.

6. **Unconditional consumer and controls.** `Packet.no_strictSystem` installs both class witnesses returned by `exists_probabilityHaar` before invoking its measure-parameter helper. The component corollaries use existing projections to the same strict system. The two independent toy controls use a unit point mass on `ℤ`; pinned [Mathlib/MeasureTheory/Measure/Dirac/Def.lean](https://github.com/leanprover-community/mathlib4/blob/4edb0dbaa3b3cf729d86d1e2f035474d5ae2ac09/Mathlib/MeasureTheory/Measure/Dirac/Def.lean#L60) and `Mathlib/MeasureTheory/MeasurableSpace/Instances.lean` provide their simplification and measurable-singleton interfaces.

The merged Urysohn repair leaves the signature of `NamedPositiveOverlap.carrierOverlap_measure_pos` unchanged. The source checks identified no new downstream adaptation. The earlier namespace corrections are present: `PscVerif.OverlapContraction` and `Psc.NamedPrefixCompact.substitution`.

## Exact source identity

| Source | SHA-256 |
| --- | --- |
| `proof/PscVerif/PscVerif/NamedStrictExclusion.lean` | `78abbc8f6a853abf39358daf842370686989c96d1f6f6297aecab33ee540b627` |
| `proof/PscVerif/PscVerif/NamedStrictExclusionControls.lean` | `e5e5c2a1fbfb87f256ae71a645f9d863ad03da63b6cadaed2e4a5da15265d1d7` |

`source-metadata.json` records Git blob IDs, byte counts, hashes, full declaration inventory, the primary pinned source hashes, and the supporting repository-source hashes. `compiled-audit-guidance.md` explains reuse of the existing audit after the running gate completes. No repository source was changed while creating this report, and no new tests or Lean jobs were run.
