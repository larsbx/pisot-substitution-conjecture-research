#!/usr/bin/env python3
"""Run the unchanged isolated Lean gate with at most N admitted compiler trees.

Only the pinned Lean ELF in the new gate session is eligible for SIGSTOP/CONT.
Discovery is polled: this is an admission limit, not an instantaneous fork limit.
Nested Lean descendants inherit their outer compiler's slot to avoid deadlock.
No checker, environment reset, compiler argument, or proof result is replaced.
SIGINT/TERM and ordinary errors resume stopped children before terminating the
owned gate group. SIGKILL of this controller cannot provide that guarantee.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time


ELAN_HOME = Path("/workspace/scratch/84c835820757/toolchains/elan")
RUN_PATH = f"{ELAN_HOME}/bin:/usr/local/bin:/usr/bin:/bin"
POLL_SECONDS = 0.10


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def proc_info(pid):
    try:
        raw = Path(f"/proc/{pid}/stat").read_text()
    except (FileNotFoundError, ProcessLookupError):
        return None
    fields = raw.rsplit(") ", 1)[1].split()
    return {"pid": pid, "state": fields[0], "ppid": int(fields[1]),
            "pgrp": int(fields[2]), "session": int(fields[3]),
            "starttime": int(fields[19])}


def proc_snapshot():
    result = {}
    for entry in os.scandir("/proc"):
        if entry.name.isdigit():
            info = proc_info(int(entry.name))
            if info is not None:
                result[info["pid"]] = info
    return result


def identity(info):
    return info["pid"], info["starttime"]


def check_controls():
    if not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        raise RuntimeError("Linux pidfd_open and pidfd_send_signal are required")
    fd = os.pidfd_open(os.getpid(), 0)
    try:
        signal.pidfd_send_signal(fd, 0)
    finally:
        os.close(fd)


class Scheduler:
    """PID-reuse-safe FIFO scheduler, also used by the harmless preflight."""

    def __init__(self, gate, executable, maximum, event_path):
        check_controls()
        self.gate = gate
        self.gate_info = proc_info(gate.pid)
        if self.gate_info is None or self.gate_info["session"] != gate.pid:
            raise RuntimeError("Gate must be alive in its own new session")
        self.executable = Path(executable).resolve(strict=True)
        st = self.executable.stat()
        self.elf_identity = (st.st_dev, st.st_ino)
        self.maximum = maximum
        self.jobs = {}
        self.admitted = set()
        self.sequence = 0
        self.started = time.monotonic()
        self.events = Path(event_path).open("x", buffering=1)
        self.closed = False
        self.emit("scheduler_start", gate_pid=gate.pid,
                  gate_starttime=self.gate_info["starttime"],
                  executable=str(self.executable), maximum_compiler_trees=maximum,
                  poll_seconds=POLL_SECONDS)

    def emit(self, event, **fields):
        self.events.write(json.dumps({"at_utc": now(),
            "elapsed_seconds": round(time.monotonic() - self.started, 6),
            "event": event, **fields}, sort_keys=True) + "\n")

    def exited(self, job):
        return bool(select.select([job["fd"]], [], [], 0)[0])

    def send(self, job, sig, reason):
        if sig == signal.SIGSTOP:
            # Revalidate executable and ownership before each new stop. pidfds
            # protect against PID reuse; they do not prevent a live exec().
            info = proc_info(job["pid"])
            if info is None or identity(info) != identity(job):
                return False
            try:
                st = os.stat(f"/proc/{job['pid']}/exe")
            except (FileNotFoundError, ProcessLookupError):
                return False
            if info["session"] != self.gate.pid or (st.st_dev, st.st_ino) != self.elf_identity:
                raise RuntimeError(f"Compiler identity changed before stop: {identity(job)}")
        try:
            signal.pidfd_send_signal(job["fd"], sig)
        except ProcessLookupError:
            self.emit("signal_exit_race", pid=job["pid"],
                      starttime=job["starttime"], signal=sig.name, reason=reason)
            return False
        # Record successful control BEFORE logging, which can itself fail.
        # Cleanup must still resume a child if the STOP event cannot be written.
        if sig == signal.SIGSTOP:
            job["paused"] = True
        elif sig == signal.SIGCONT:
            job["paused"] = False
        # All other process-control errors propagate; never silently leave a
        # stopped job or claim a cap after an unsuccessful control operation.
        self.emit("signal", pid=job["pid"], starttime=job["starttime"],
                  signal=sig.name, reason=reason)
        return True

    def update_roots(self, snapshot):
        by_pid = {job["pid"]: key for key, job in self.jobs.items()}
        for key, job in self.jobs.items():
            # PPID reparenting must not erase a previously proven dependency.
            # Drop ancestry only when the ancestor's pidfd reports its exit.
            job["ancestors"].intersection_update(self.jobs)
            ancestor = snapshot.get(job["pid"], job)["ppid"]
            visited = {job["pid"]}
            while ancestor in snapshot and ancestor not in visited:
                visited.add(ancestor)
                if ancestor in by_pid:
                    job["ancestors"].add(by_pid[ancestor])
                ancestor = snapshot[ancestor]["ppid"]
        changed = True
        while changed:
            changed = False
            for key, job in self.jobs.items():
                before = len(job["ancestors"])
                for ancestor in list(job["ancestors"]):
                    job["ancestors"].update(self.jobs[ancestor]["ancestors"])
                if key in job["ancestors"]:
                    raise RuntimeError("Unexpected cycle in proven compiler ancestry")
                changed |= len(job["ancestors"]) != before
        for key, job in self.jobs.items():
            candidates = job["ancestors"] | {key}
            outermost = {k for k in candidates if not (self.jobs[k]["ancestors"] & candidates)}
            root = job["root"] if job["root"] in outermost else min(outermost, key=lambda k: self.jobs[k]["sequence"])
            if job["root"] != root:
                self.emit("nested_membership", pid=job["pid"],
                          root_pid=root[0], root_starttime=root[1])
            job["root"] = root

    def tick(self):
        snapshot = proc_snapshot()
        for key, job in list(self.jobs.items()):
            if self.exited(job):
                self.emit("exit_observed", pid=job["pid"],
                          starttime=job["starttime"], paused=job["paused"])
                os.close(job["fd"])
                del self.jobs[key]

        # A session created by setsid can only acquire members by descent.
        # This retains proven ownership after an intermediate parent exits.
        # The gate itself is excluded, including in the Python-only preflight.
        members = [i for i in snapshot.values()
                   if i["session"] == self.gate.pid and i["pid"] != self.gate.pid
                   and i["state"] not in ("Z", "X")]
        for info in sorted(members, key=lambda i: (i["starttime"], i["pid"])):
            key = identity(info)
            if key in self.jobs:
                continue
            try:
                st = os.stat(f"/proc/{info['pid']}/exe")
            except (FileNotFoundError, ProcessLookupError):
                continue
            if (st.st_dev, st.st_ino) != self.elf_identity:
                continue
            try:
                fd = os.pidfd_open(info["pid"], 0)
            except ProcessLookupError:
                continue
            verified = proc_info(info["pid"])
            if verified is None or identity(verified) != key or verified["session"] != self.gate.pid:
                os.close(fd)
                continue
            try:
                verified_exe = os.stat(f"/proc/{info['pid']}/exe")
            except (FileNotFoundError, ProcessLookupError):
                os.close(fd)
                continue
            if (verified_exe.st_dev, verified_exe.st_ino) != self.elf_identity:
                os.close(fd)
                continue
            if verified["state"] in ("T", "t"):
                os.close(fd)
                raise RuntimeError(f"Compiler {key} was stopped by an external actor")
            self.sequence += 1
            job = {**verified, "fd": fd, "sequence": self.sequence,
                   "paused": False, "root": key, "ancestors": set()}
            self.jobs[key] = job
            self.emit("discovered", pid=info["pid"], starttime=info["starttime"],
                      ppid=verified["ppid"], sequence=self.sequence)

        self.update_roots(snapshot)
        roots = {job["root"] for job in self.jobs.values()}
        self.admitted.intersection_update(roots)
        queue = sorted(roots - self.admitted, key=lambda k: self.jobs[k]["sequence"])
        for key in queue[:max(0, self.maximum - len(self.admitted))]:
            self.admitted.add(key)
            self.emit("admitted", pid=key[0], starttime=key[1],
                      sequence=self.jobs[key]["sequence"])

        # Stop excess jobs before resuming the next eligible FIFO roots.
        for job in self.jobs.values():
            if job["root"] not in self.admitted and not job["paused"]:
                self.send(job, signal.SIGSTOP, "queued")
        for job in self.jobs.values():
            if job["root"] in self.admitted and job["paused"]:
                self.send(job, signal.SIGCONT, "admitted")
        return {"admitted_compiler_trees": len(self.admitted),
                "queued_compiler_trees": len(roots - self.admitted),
                "identified_compilers": len(self.jobs),
                "paused_compilers": sum(j["paused"] for j in self.jobs.values())}

    def resume_all(self, reason="cleanup"):
        failures = []
        for job in self.jobs.values():
            if job["paused"]:
                try:
                    self.send(job, signal.SIGCONT, reason)
                    job["paused"] = False
                except Exception as exc:
                    failures.append(f"pid {job['pid']}: {exc!r}")
        if failures:
            raise RuntimeError("Could not resume owned jobs: " + "; ".join(failures))

    def close(self):
        if not self.closed:
            for job in self.jobs.values():
                os.close(job["fd"])
            self.jobs.clear()
            self.events.close()
            self.closed = True


def terminate_gate(process, sig):
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, sig)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=15)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--exporter", required=True, type=Path)
    parser.add_argument("--expected-commit", required=True)
    parser.add_argument("--max-compilers", type=int, default=2)
    args = parser.parse_args()
    if args.max_compilers < 1:
        parser.error("--max-compilers must be positive")
    check_controls()
    root = args.root.resolve(strict=True)
    work = args.run_dir.resolve()
    exporter = args.exporter.resolve(strict=True)
    runner = Path(__file__).resolve(strict=True)
    if work == root or root in work.parents:
        parser.error("--run-dir must be outside the source repository")

    def git(*parts):
        return subprocess.check_output(["git", *parts], cwd=root, text=True).strip()

    source = {"commit": git("rev-parse", "HEAD"),
              "tree": git("rev-parse", "HEAD^{tree}"),
              "status": git("status", "--porcelain=v1", "--untracked-files=all")}
    if source["commit"] != args.expected_commit or source["status"]:
        raise RuntimeError(f"Expected clean source {args.expected_commit}; observed {source}")
    pin = (root / "proof/PscVerif/lean-toolchain").read_text().strip()
    if pin != "leanprover/lean4:v4.34.0-rc2":
        raise RuntimeError(f"Unreviewed Lean toolchain: {pin}")
    compiler = (ELAN_HOME / "toolchains" / pin.replace("/", "--").replace(":", "---") / "bin/lean").resolve(strict=True)
    with compiler.open("rb") as stream:
        if stream.read(4) != b"\x7fELF":
            raise RuntimeError("Pinned Lean is not a native ELF executable")
    work.mkdir(parents=True, exist_ok=False)
    (work / "tmp").mkdir()
    command = ["./tools/check_lean.sh", "--archived-packets", str(exporter), str(work / "replay")]
    env = dict(os.environ)
    overrides = {"ELAN_HOME": str(ELAN_HOME), "PATH": RUN_PATH, "TMPDIR": str(work / "tmp")}
    env.update(overrides)
    tracked_files = {"checker": root / "tools/check_lean.sh", "compiler": compiler,
                     "exporter": exporter, "runner": runner}
    hashes = {name: sha256(path) for name, path in tracked_files.items()}
    started = time.monotonic()
    receipt = {"schema": "c4-scheduled-isolated-gate-start-v1", "started_at_utc": now(),
               "source_commit": source["commit"], "source_tree": source["tree"],
               "source_status": source["status"], "cwd": str(root), "command": command,
               "environment_overrides": overrides, "lean_toolchain": pin,
               "artifact_paths": {k: str(v) for k, v in tracked_files.items()},
               "artifact_sha256": hashes, "max_admitted_compiler_trees": args.max_compilers,
               "poll_seconds": POLL_SECONDS, "nested_compilers_share_ancestor_slot": True,
               "sigkill_controller_cleanup_guaranteed": False,
               "memory_before": subprocess.check_output(["free", "-b"], text=True)}
    write_json(work / "start.json", receipt)
    print(json.dumps(receipt), flush=True)
    cancelled = []

    def on_signal(sig, _frame):
        if not cancelled:
            cancelled.append(sig)

    old_handlers = {sig: signal.signal(sig, on_signal) for sig in (signal.SIGINT, signal.SIGTERM)}
    process = None
    scheduler = None
    errors = []
    with (work / "full.log").open("xb") as output:
        try:
            process = subprocess.Popen(command, cwd=root, env=env, stdout=output,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            write_json(work / "process.json", {"pid": process.pid, "session": process.pid,
                       "launched_at_utc": now(), "controller_pid": os.getpid()})
            scheduler = Scheduler(process, compiler, args.max_compilers, work / "scheduler.jsonl")
            heartbeat = time.monotonic() + 30
            while process.poll() is None and not cancelled:
                counts = scheduler.tick()
                if time.monotonic() >= heartbeat:
                    print(json.dumps({"at_utc": now(), "heartbeat": counts}), flush=True)
                    heartbeat = time.monotonic() + 30
                time.sleep(POLL_SECONDS)
        except Exception as exc:
            errors.append(repr(exc))
        finally:
            if scheduler is not None:
                try:
                    scheduler.resume_all()
                except Exception as exc:
                    errors.append(repr(exc))
            if process is not None and process.poll() is None:
                try:
                    terminate_gate(process, cancelled[0] if cancelled else signal.SIGTERM)
                except Exception as exc:
                    errors.append(repr(exc))
            if scheduler is not None:
                try:
                    scheduler.emit("scheduler_end", errors=errors, cancelled=cancelled,
                                   gate_returncode=process.returncode if process else None)
                except Exception as exc:
                    errors.append(f"Terminal scheduler logging failed: {exc!r}")
                try:
                    scheduler.close()
                except Exception as exc:
                    errors.append(f"Scheduler close failed: {exc!r}")
            for sig, handler in old_handlers.items():
                signal.signal(sig, handler)

    result = process.returncode if process else None
    try:
        final_source = {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
                        "status": git("status", "--porcelain=v1", "--untracked-files=all")}
        final_hashes = {name: sha256(path) for name, path in tracked_files.items()}
    except Exception as exc:
        errors.append(f"Could not verify terminal identities: {exc!r}")
        final_source, final_hashes = None, None
    unchanged = final_source == source and final_hashes == hashes
    if not unchanged:
        errors.append("Source or tracked artifact identity changed during the run")
    accepted = result == 0 and not cancelled and not errors
    exit_code = result if result is not None and result >= 0 else (128 - result if result is not None else 70)
    if exit_code == 0 and not accepted:
        exit_code = 128 + cancelled[0] if cancelled else 70
    terminal = {"schema": "c4-scheduled-isolated-gate-terminal-v1", "ended_at_utc": now(),
                "elapsed_seconds": round(time.monotonic() - started, 3),
                "gate_returncode": result, "runner_exit_code": exit_code,
                "outcome": "accepted" if accepted else ("cancelled" if cancelled else "failed"),
                "errors": errors, "cancelled_signals": cancelled,
                "initial_source": source, "final_source": final_source,
                "initial_artifact_sha256": hashes, "final_artifact_sha256": final_hashes,
                "identities_unchanged": unchanged, "raw_log_bytes": (work / "full.log").stat().st_size,
                "raw_log_sha256": sha256(work / "full.log"),
                "scheduler_log_sha256": sha256(work / "scheduler.jsonl") if scheduler else None}
    write_json(work / "terminal.json", terminal)
    print(json.dumps(terminal), flush=True)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
