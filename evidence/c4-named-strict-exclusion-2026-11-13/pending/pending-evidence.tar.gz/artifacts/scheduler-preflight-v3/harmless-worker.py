from pathlib import Path
import os, subprocess, sys, time
role, directory, name = sys.argv[1:]
directory = Path(directory)
if role == "gate":
    children = []
    for i in range(4):
        children.append(subprocess.Popen([sys.executable, __file__, "worker", str(directory), str(i)]))
        time.sleep(0.04)
    results = [p.wait() for p in children]
    raise SystemExit(0 if results == [0, 0, 0, 0] else 1)
else:
    (directory / (name + ".pid")).write_text(str(os.getpid()))
    if role == "worker" and name == "0":
        time.sleep(0.25)
        nested = subprocess.Popen([sys.executable, __file__, "nested", str(directory), "nested"])
        if nested.wait() != 0:
            raise SystemExit(2)
    for i in range(35 if role != "outside" else 250):
        (directory / (name + ".progress")).write_text(str(i))
        time.sleep(0.025)
    (directory / (name + ".done")).write_text("done")
