#!/usr/bin/env python3
"""Harmless process-control checks; invokes no Lean, Lake, or project gate."""
from pathlib import Path
import importlib.util
import json
import os
import signal
import subprocess
import sys
import time


RUNNER = Path(__file__).with_name("run-isolated-scheduled.py")
spec = importlib.util.spec_from_file_location("isolated_scheduler", RUNNER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
WORKER = '''from pathlib import Path
import os, subprocess, sys, time
role, directory, name = sys.argv[1:]
directory = Path(directory)
if role == "gate":
    children = []
    for i in range(4):
        children.append(subprocess.Popen([sys.executable, __file__, "worker", str(directory), str(i)]))
        time.sleep(0.04)
    results = [p.wait() for p in children]
    raise SystemExit(0 if results == [0, 0, 0, 0] else 1)
else:
    (directory / (name + ".pid")).write_text(str(os.getpid()))
    if role == "worker" and name == "0":
        time.sleep(0.25)
        nested = subprocess.Popen([sys.executable, __file__, "nested", str(directory), "nested"])
        if nested.wait() != 0:
            raise SystemExit(2)
    for i in range(35 if role != "outside" else 250):
        (directory / (name + ".progress")).write_text(str(i))
        time.sleep(0.025)
    (directory / (name + ".done")).write_text("done")
'''


def run(destination):
    work = Path(destination).resolve()
    work.mkdir(parents=True, exist_ok=False)
    helper = work / "harmless-worker.py"
    helper.write_text(WORKER)
    module.check_controls()
    checks = {}
    # Source-level counterexample from independent review: A -> non-Lean shell
    # -> B is observed, then the shell exits and B is reparented while A waits.
    # Historical compiler membership must survive that reparenting.
    probe = object.__new__(module.Scheduler)
    a, b, c = (101, 10), (103, 12), (99, 8)
    probe.jobs = {
        a: {"pid": 101, "ppid": 1, "starttime": 10, "sequence": 1, "root": a, "ancestors": set()},
        b: {"pid": 103, "ppid": 102, "starttime": 12, "sequence": 2, "root": b, "ancestors": set()},
    }
    probe.emit = lambda *_args, **_kwargs: None
    tree = {101: probe.jobs[a], 102: {"pid": 102, "ppid": 101}, 103: probe.jobs[b]}
    probe.update_roots(tree)
    assert probe.jobs[b]["root"] == a
    tree = {101: probe.jobs[a], 103: {**probe.jobs[b], "ppid": 1}}
    probe.update_roots(tree)
    checks["nested_root_survives_intermediate_reparenting"] = probe.jobs[b]["root"] == a
    probe.jobs[c] = {"pid": 99, "ppid": 1, "starttime": 8, "sequence": 3, "root": c, "ancestors": set()}
    tree[99] = probe.jobs[c]
    tree[101] = {**probe.jobs[a], "ppid": 99}
    probe.update_roots(tree)
    checks["newly_proven_outer_ancestor_inherits_group"] = probe.jobs[b]["root"] == c and probe.jobs[a]["root"] == c
    del probe.jobs[a], probe.jobs[c]
    probe.update_roots({103: {**probe.jobs[b], "ppid": 1}})
    checks["exited_ancestors_release_shared_slot"] = probe.jobs[b]["root"] == b and not probe.jobs[b]["ancestors"]
    before_hash = module.sha256(RUNNER)
    started = time.monotonic()
    python = Path(sys.executable).resolve()
    outsider = subprocess.Popen([str(python), str(helper), "outside", str(work), "outside"], start_new_session=True)
    gate = None
    scheduler = None
    snapshots = []
    try:
        gate = subprocess.Popen([str(python), str(helper), "gate", str(work), "gate"], start_new_session=True)
        scheduler = module.Scheduler(gate, python, 2, work / "scheduler.jsonl")
        deadline = time.monotonic() + 12
        observed_paused = set()
        while gate.poll() is None:
            if time.monotonic() >= deadline:
                raise RuntimeError("Harmless FIFO/nesting preflight timed out")
            counts = scheduler.tick()
            assert counts["admitted_compiler_trees"] <= 2, counts
            outside_info = module.proc_info(outsider.pid)
            assert outside_info is not None and outside_info["state"] not in ("T", "t")
            assert all(j["pid"] not in (outsider.pid, os.getpid(), gate.pid)
                       for j in scheduler.jobs.values())
            for job in scheduler.jobs.values():
                info = module.proc_info(job["pid"])
                if job["paused"] and info and info["state"] == "T":
                    observed_paused.add(job["pid"])
            snapshots.append(counts)
            time.sleep(0.025)
        checks["fake_gate_exit_zero"] = gate.returncode == 0
        checks["real_stopped_state_observed"] = bool(observed_paused)
        checks["outside_sibling_progressed"] = int((work / "outside.progress").read_text()) > 10
        checks["outside_and_controller_never_targeted"] = True
        checks["max_two_admitted_roots"] = max(s["admitted_compiler_trees"] for s in snapshots) == 2
        scheduler.resume_all("preflight_normal_cleanup")
        scheduler.close()
        scheduler = None
        events = [json.loads(line) for line in (work / "scheduler.jsonl").read_text().splitlines()]
        checks["nested_child_inherits_slot"] = any(e["event"] == "nested_membership" for e in events)
        admissions = [e["sequence"] for e in events if e["event"] == "admitted"]
        checks["fifo_root_admission"] = admissions == sorted(admissions) and len(admissions) == 4
        checks["queued_jobs_resumed"] = any(e["event"] == "signal" and e["signal"] == "SIGCONT" and e["reason"] == "admitted" for e in events)
        checks["all_fake_workers_completed"] = all((work / (n + ".done")).exists() for n in ["0", "1", "2", "3", "nested"])

        # A separate short run exercises the same cleanup function while there
        # are still paused children, before terminating only this owned group.
        cleanup = work / "cleanup"
        cleanup.mkdir()
        gate = subprocess.Popen([str(python), str(helper), "gate", str(cleanup), "gate"], start_new_session=True)
        scheduler = module.Scheduler(gate, python, 2, work / "cleanup-scheduler.jsonl")
        deadline = time.monotonic() + 5
        paused = []
        while time.monotonic() < deadline:
            scheduler.tick()
            paused = [j for j in scheduler.jobs.values() if j["paused"]]
            if paused and all((module.proc_info(j["pid"]) or {}).get("state") == "T" for j in paused):
                break
            time.sleep(0.025)
        if not paused:
            raise RuntimeError("Cleanup preflight never paused a child")
        scheduler.resume_all("preflight_cleanup")
        time.sleep(0.05)
        checks["cleanup_resumes_stopped_children"] = all((module.proc_info(j["pid"]) or {}).get("state") not in ("T", "t") for j in paused)
        module.terminate_gate(gate, signal.SIGTERM)
        scheduler.close()
        scheduler = None

        # A write failure after a successful STOP must not lose ownership of
        # that stop. Exercise the exact failure path found during review.
        failure = work / "log-failure"
        failure.mkdir()
        gate = subprocess.Popen([str(python), str(helper), "gate", str(failure), "gate"], start_new_session=True)
        scheduler = module.Scheduler(gate, python, 2, work / "log-failure-scheduler.jsonl")
        real_events = scheduler.events

        class FailOneStopLog:
            failed = False

            def write(self, data):
                event = json.loads(data)
                if not self.failed and event.get("signal") == "SIGSTOP":
                    self.failed = True
                    raise OSError("injected STOP event write failure")
                return real_events.write(data)

            def close(self):
                return real_events.close()

        scheduler.events = FailOneStopLog()
        deadline = time.monotonic() + 5
        caught = False
        while time.monotonic() < deadline:
            try:
                scheduler.tick()
            except OSError as exc:
                if str(exc) != "injected STOP event write failure":
                    raise
                caught = True
                break
            time.sleep(0.025)
        paused = [j for j in scheduler.jobs.values() if j["paused"]]
        checks["log_failure_preserves_stop_ownership"] = caught and bool(paused)
        scheduler.resume_all("preflight_log_failure_cleanup")
        time.sleep(0.05)
        checks["log_failure_cleanup_resumes_child"] = bool(paused) and all((module.proc_info(j["pid"]) or {}).get("state") not in ("T", "t") for j in paused)
        module.terminate_gate(gate, signal.SIGTERM)
        scheduler.close()
        scheduler = None
        checks["runner_bytes_unchanged"] = before_hash == module.sha256(RUNNER)
        checks["all_checks_passed"] = all(checks.values())
        receipt = {"schema": "c4-scheduler-harmless-preflight-v1", "at_utc": module.now(),
                   "elapsed_seconds": round(time.monotonic() - started, 3),
                   "runner_sha256": before_hash, "preflight_sha256": module.sha256(__file__),
                   "simulated_compiler_executable": str(python), "simulated_compiler_sha256": module.sha256(python),
                   "no_lean_lake_or_project_gate_invoked": True,
                   "checks": checks, "observed_stopped_pids": sorted(observed_paused),
                   "fifo_admission_sequences": admissions,
                   "scheduler_log_sha256": module.sha256(work / "scheduler.jsonl"),
                   "cleanup_scheduler_log_sha256": module.sha256(work / "cleanup-scheduler.jsonl"),
                   "log_failure_scheduler_log_sha256": module.sha256(work / "log-failure-scheduler.jsonl")}
        module.write_json(work / "preflight.json", receipt)
        print(json.dumps(receipt, indent=2), flush=True)
        return 0 if checks["all_checks_passed"] else 1
    finally:
        if scheduler is not None:
            try:
                scheduler.resume_all("preflight_finally")
            finally:
                scheduler.close()
        if gate is not None:
            module.terminate_gate(gate, signal.SIGTERM)
        if outsider.poll() is None:
            outsider.terminate()
            outsider.wait(timeout=5)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: preflight-isolated-scheduled.py NEW-RUN-DIRECTORY")
    raise SystemExit(run(sys.argv[1]))
