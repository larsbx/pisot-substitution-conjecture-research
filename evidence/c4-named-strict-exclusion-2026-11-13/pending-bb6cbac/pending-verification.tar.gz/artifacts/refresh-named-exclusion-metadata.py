#!/usr/bin/env python3
"""Bind the reviewed root-symmetry repair to an explicitly supplied clean revision.

This helper reads Git objects and source text only. It does not run Lean, tests,
the hosted inspector, or repository Python code. Its output is source provenance,
not acceptance evidence. Run only after the publisher supplies the commit/tree.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

BASE = Path('/workspace/scratch/5535bb23ca85')
REPOSITORY = 'larsbx/pisot-substitution-conjecture-research'
PRIOR_COMMIT = '16dd825648d1a1bcdba9038e079463a9bebbaf3d'
PRIOR_TREE = 'ae73f53be5b43879d92c8995597960909afef684'
PRIOR_METADATA_SHA256 = '402fa095d2b5ce66d8cbb1f010500dbf56dc65019ef2000b70b187eb8c69c886'
REPAIR_PATH = 'proof/PscVerif/PscVerif/NamedStrictExclusion.lean'
REPAIR_SHA256 = '80ddbe716a339bb19705de5ddb0914c5cb4b7fb75dbc3ff812df6685855f551a'
BANK_PATH = 'proof/proof-bank.json'
ALLOWED = ['Classical.choice', 'Quot.sound', 'propext']
EXPECTED = {
    **{('PscVerif.NamedStrictExclusion', 'Psc.NamedStrictExclusion.' + name): 'theorem'
       for name in ('intersection_eq_archivedRoot', 'carrierOverlap_subset_archivedRoots',
                    'no_strictSystem_of_roots_null', 'exists_probabilityHaar')},
    **{('PscVerif.NamedStrictExclusion', 'Psc.ArchivedPayload.Packet.' + name): 'theorem'
       for name in ('no_strictSystem_of_measure', 'no_strictSystem',
                    'no_strictComponent', 'no_bpaStrictComponent')},
    **{('PscVerif.NamedStrictExclusionControls', 'Psc.NamedStrictExclusionControls.' + name): kind
       for name, kind in (('diagonalTiles', 'declaration'), ('omittedRootTiles', 'declaration'),
                          ('dropping_distinct_labels_counterexample', 'theorem'),
                          ('omitting_root_counterexample', 'theorem'))},
}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def git(root, *args):
    return subprocess.check_output(
        ['git', '--no-optional-locks', '--no-replace-objects', *args], cwd=root)


def source_identity(root):
    return {
        'commit': git(root, 'rev-parse', 'HEAD').decode().strip(),
        'tree': git(root, 'rev-parse', 'HEAD^{tree}').decode().strip(),
        'status_porcelain': git(root, 'status', '--porcelain=v1', '--untracked-files=all').decode(),
    }


def safe_file(root, name):
    relative = PurePosixPath(name)
    require(not relative.is_absolute() and '..' not in relative.parts and str(relative) == name,
            f'Unsafe source path: {name}')
    path = root / name
    require(path.is_file() and not path.is_symlink() and root in path.resolve().parents,
            f'Source is not a regular file within the checkout: {name}')
    return path


def make_metadata(args):
    root = args.root.resolve(strict=True)
    prior_path = BASE / 'static-review-v3/source-metadata.json'
    prior_bytes = prior_path.read_bytes()
    require(sha(prior_bytes) == PRIOR_METADATA_SHA256, 'Prior metadata bytes changed')
    prior = json.loads(prior_bytes)
    require((prior['subject_revision'], prior['subject_tree']) == (PRIOR_COMMIT, PRIOR_TREE),
            'Unexpected prior metadata subject')
    identity = source_identity(root)
    require(identity == {'commit': args.expected_commit, 'tree': args.expected_tree,
                         'status_porcelain': ''}, 'Expected the exact clean supplied commit/tree')
    require(args.expected_commit != PRIOR_COMMIT, 'Repair metadata cannot name the failed parent')
    original_commit = prior['original_review']['subject_revision']
    proof_changes = git(root, 'diff', '--name-only', '--no-renames', PRIOR_COMMIT,
                        args.expected_commit, '--', 'proof').decode().splitlines()
    require(set(proof_changes) == {REPAIR_PATH, BANK_PATH},
            'Repair must change only the reviewed Lean module and regenerated proof bank in proof/')
    snapshots = {}

    def refresh(old):
        path = old['path']
        data = safe_file(root, path).read_bytes()
        require(data == git(root, 'show', f'{args.expected_commit}:{path}'),
                f'Working bytes differ from supplied commit: {path}')
        require(sha(git(root, 'show', f'{PRIOR_COMMIT}:{path}')) == old['sha256'],
                f'Prior source record does not match its commit: {path}')
        snapshots[path] = data
        original = git(root, 'show', f'{original_commit}:{path}')
        record = {
            'repository': REPOSITORY, 'revision': args.expected_commit, 'path': path,
            'canonical_url': f'https://github.com/{REPOSITORY}/blob/{args.expected_commit}/{path}',
            'git_blob_sha': git(root, 'rev-parse', f'{args.expected_commit}:{path}').decode().strip(),
            'sha256': sha(data), 'source_bytes': len(data), 'working_bytes_match_commit': True,
            'source_equal_to_previous_review_revision': sha(data) == old['sha256'],
            'source_equal_to_original_review_revision': data == original,
            'previous_review_revision': PRIOR_COMMIT, 'previous_review_sha256': old['sha256'],
            'original_review_revision': original_commit, 'original_review_sha256': sha(original),
        }
        return record

    modules = []
    for old in prior['modules']:
        record = refresh(old)
        for key in ('module', 'explicit_definition_count', 'explicit_theorem_count'):
            record[key] = old[key]
        record['declarations'] = copy.deepcopy(old['declarations'])
        lines = snapshots[old['path']].decode('utf-8').splitlines()
        for declaration in record['declarations']:
            matches = [i for i, line in enumerate(lines, 1) if line == declaration['opening']]
            require(len(matches) == 1, f'Expected one unchanged declaration header: {declaration["name"]}')
            declaration['line'] = matches[0]
        expected_sha = REPAIR_SHA256 if old['path'] == REPAIR_PATH else old['sha256']
        require(record['sha256'] == expected_sha, f'Module differs from the reviewed repair: {old["path"]}')
        modules.append(record)
    dependencies = [refresh(item) for item in prior['reviewed_repository_dependencies_and_audit_sources']]
    nonproof = [refresh(item) for item in prior.get('changed_nonproof_sources', [])]
    for record in dependencies:
        require(record['path'] == BANK_PATH or record['source_equal_to_previous_review_revision'],
                f'Previously reviewed dependency changed outside narrow repair: {record["path"]}')
    inventory = [item for module in modules for item in module['declarations']]
    require(len(inventory) == 12 and
            {(d['owner'], d['name']): d['expected_compiled_kind'] for d in inventory} == EXPECTED,
            'Expected the exact twelve declaration identities/kinds')
    require(all(d['private'] is False for d in inventory), 'Expected public declarations')
    bank = json.loads(snapshots[BANK_PATH])
    for module in modules:
        for declaration in module['declarations']:
            if declaration['expected_compiled_kind'] != 'theorem':
                continue
            matches = [row for row in bank['lean_declarations']
                       if (row['module'], row['name']) == (declaration['owner'], declaration['name'])]
            require(len(matches) == 1, f'Missing or duplicate proof-bank theorem: {declaration["name"]}')
            row = matches[0]
            require(row['source'] == module['path'] and row['line'] == declaration['line']
                    and row['declaration'] == declaration['opening'] and row['private'] is False,
                    f'Proof-bank theorem position/header is stale: {declaration["name"]}')
    pin = safe_file(root, 'proof/PscVerif/lean-toolchain').read_text().strip()
    require(pin == prior['lean_toolchain'] == 'leanprover/lean4:v4.34.0-rc2', 'Lean pin changed')
    manifest = json.loads(snapshots['proof/PscVerif/lake-manifest.json'])
    mathlib = [p for p in manifest['packages'] if p['name'] == 'mathlib']
    require(len(mathlib) == 1 and mathlib[0]['rev'] == prior['mathlib_revision'], 'Mathlib pin changed')
    at = dt.datetime.now(dt.timezone.utc).isoformat()
    metadata = {
        'schema': 'psc-named-strict-exclusion-static-review-v5', 'created_at_utc': at,
        'repository': REPOSITORY, 'subject_revision': args.expected_commit, 'subject_tree': args.expected_tree,
        'review_status': 'narrow_symmetry_repair_source_review_compilation_pending',
        'conclusion': 'The earlier static review missed a real and_comm elaboration error in the reversed root case. '
                      'The three-case explicit commutativity repair has been reviewed as source; this metadata '
                      'binds its exact bytes and inventory. Repaired compilation and full hosted acceptance remain pending.',
        'scope': prior['scope'], 'counts': prior['counts'], 'allowed_axioms_for_later_compiled_audit': ALLOWED,
        'lean_toolchain': pin, 'mathlib_revision': prior['mathlib_revision'],
        'modules': modules, 'reviewed_repository_dependencies_and_audit_sources': dependencies,
        'changed_nonproof_sources': nonproof,
        'primary_pinned_mathlib_sources': prior['primary_pinned_mathlib_sources'],
        'primary_pinned_mathlib_source_provenance': 'Hashes and citations preserved from the original static review; '
                                                    'the unchanged Mathlib pin is rechecked here. No new Mathlib review.',
        'original_review': prior['original_review'],
        'previous_review': {
            'artifact_path': str(prior_path), 'artifact_sha256': PRIOR_METADATA_SHA256,
            'subject_revision': PRIOR_COMMIT, 'subject_tree': PRIOR_TREE,
            'created_at_utc': prior['created_at_utc'], 'review_status': prior['review_status'],
            'reviewer_agents': prior['reviewer_agents'],
            'historical_source_equality_revalidation': prior['source_equality_revalidation'],
            'historical_conclusion': prior['conclusion'],
            'limitation': 'The historical no-defect finding was incomplete: the hosted compiler subsequently '
                          'found the reversed-conjunction elaboration error. It is not acceptance evidence.',
        },
        'repair_source_review': {
            'agent': '/root/c4_main_audit', 'role': 'author of the narrow repair and its source review',
            'source_path': REPAIR_PATH, 'source_sha256': REPAIR_SHA256,
            'ordered_cases': [[1, 0], [2, 0], [2, 1]],
            'change': 'Supply typed and_comm as the proof term in simpa [overlap, archivedRoot] using, '
                      'instead of placing and_comm in the simp rewrite list.',
            'new_independent_proof_review_claimed': False, 'human_review_performed': False,
            'compilation_status': 'pending', 'acceptance_claimed': False,
        },
        'prior_hosted_error': {
            'head_revision': PRIOR_COMMIT, 'run_id': 43345576693, 'job_id': 131624024712,
            'run_url': f'https://github.com/{REPOSITORY}/actions/runs/43345576693',
            'source_location': 'PscVerif/NamedStrictExclusion.lean:42:14',
            'diagnostic': 'unsolved goals: x ∈ K 1 ∧ x ∈ K 0 ↔ x ∈ K 0 ∧ x ∈ K 1; and_comm unused',
            'earlier_static_review_missed_error': True,
        },
        'metadata_refresh': {
            'agent': '/root/c4_main_audit', 'at_utc': at, 'helper_path': str(Path(__file__).resolve()),
            'helper_sha256': sha(Path(__file__).read_bytes()), 'checkout': str(root),
            'exact_clean_source_identity': identity, 'proof_paths_changed_since_previous_review': proof_changes,
            'entire_proof_subtree_identical_to_previous_review': False,
            'repository_source_record_count': len(modules) + len(dependencies) + len(nonproof),
            'publication_provenance': 'Expected commit/tree supplied by the publisher; this helper does not query the remote.',
        },
        'all_ten_named_theorems_present_in_candidate_proof_bank': True,
        'lean_executed_for_this_review': False, 'tests_executed_for_this_review': False,
        'repo_sources_mutated_for_this_review': False, 'human_review_performed': False,
        'compiled_audit_log_inspected_for_this_review': False, 'kernel_acceptance_claimed': False,
        'full_hosted_acceptance_claimed': False,
    }
    require(source_identity(root) == identity, 'Checkout identity changed during refresh')
    for name, data in snapshots.items():
        require(safe_file(root, name).read_bytes() == data, f'Source changed during refresh: {name}')
    require(prior_path.read_bytes() == prior_bytes, 'Prior metadata changed during refresh')
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-commit', required=True)
    parser.add_argument('--expected-tree', required=True)
    parser.add_argument('--root', type=Path, default=BASE / 'psc-symmetry-fix')
    parser.add_argument('--output', type=Path, default=BASE / 'static-review-v5')
    args = parser.parse_args()
    for value in (args.expected_commit, args.expected_tree):
        if re.fullmatch('[0-9a-f]{40}', value) is None:
            parser.error('Expected full lowercase 40-character Git commit/tree identities')
    output = args.output.resolve()
    root = args.root.resolve(strict=True)
    protected = (root, BASE / 'static-review-v2', BASE / 'static-review-v3')
    require(all(output != item and item not in output.parents for item in protected),
            'Output must be outside the checkout and earlier review packages')
    require(not output.exists(), 'Output must be new; earlier review packages are never overwritten')
    metadata = make_metadata(args)
    output.mkdir(parents=True, exist_ok=False)
    data = encoded(metadata)
    (output / 'source-metadata.json').write_bytes(data)
    note = (
        '# Repaired candidate: source provenance only\n\n'
        f"Refreshed at `{metadata['created_at_utc']}` for commit `{args.expected_commit}`, "
        f"tree `{args.expected_tree}`.\n\n"
        'The original author-agent and independent-agent static review at `137d1e980418f34f9eb5e92142d5bbc53b4368e6`, '
        'carried to `16dd825648d1a1bcdba9038e079463a9bebbaf3d` by source equality, missed a real elaboration error. '
        'Hosted run 43345576693 exposed the unreduced reversed-conjunction goal and the unused `and_comm` simp argument. '
        'The earlier review artifacts remain unchanged and are retained as historical provenance.\n\n'
        'The repair supplies explicit typed `and_comm` proof terms in the three reversed cases. '
        'The author agent reviewed this narrow repair; no new independent proof review or human review is claimed. '
        'This refresh verifies the exact clean commit/tree, source bytes, all twelve declaration headers and positions, '
        'and the ten theorem entries in the regenerated proof bank. All inventoried dependencies except the proof bank '
        'are unchanged from v3; their records now refer to the supplied repaired commit. '
        'Pinned Mathlib citations are historical, with the unchanged pin rechecked.\n\n'
        '**Repaired compilation and full hosted acceptance are pending.** '
        'No Lean, tests, hosted inspector, or repository Python code was executed by this helper. '
        'Metadata is an integrity binding for a later actual compiled audit, not an acceptance result.\n'
    ).encode()
    (output / 'provenance-note.md').write_bytes(note)
    (output / 'SHA256SUMS').write_text(
        f'{sha(data)}  source-metadata.json\n{sha(note)}  provenance-note.md\n')
    print(json.dumps({'output': str(output), 'subject_revision': args.expected_commit,
                      'subject_tree': args.expected_tree, 'source_metadata_sha256': sha(data),
                      'explicit_declarations': 12, 'compiled_acceptance_claimed': False}, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print(f'Metadata refresh refused: {exc}', file=sys.stderr)
        raise SystemExit(1)
