# Hosted named-exclusion acceptance inspector

This is a prepared postprocessor, not an acceptance result. It has not been run against a completed hosted artifact. It launches no Lean, Lake, native reconstruction, test suite, or artifact executable.

The script is `/workspace/scratch/5535bb23ca85/inspect-hosted-named-exclusion-audit.py`. It leaves the existing local inspector and candidate source untouched.

## Explicit subject binding

- Repository: `larsbx/pisot-substitution-conjecture-research`.
- Workflow: `.github/workflows/c4-archived-payload-lean.yml`.
- Expected run ID, complete commit SHA and complete tree SHA are mandatory CLI inputs; there are no implicit candidate defaults.
- Supply static source metadata for that exact commit/tree. Its twelve declaration identities, kinds and owners must match the required named-exclusion inventory, and every inventoried repository source must match the clean checkout.

The old `16dd825` candidate has a real hosted compilation failure in the reversed-letter intersection case. Its failed run is not an acceptance input. Supply the repaired candidate, new matching source metadata, and its genuinely completed successful archived workflow when available.

## Inputs and invocation

Wait for the actual GitHub run to reach `completed` / `success`. Preserve the unmodified raw REST workflow-run response and the complete jobs response for the same attempt. For this one-job workflow, the jobs response must have `total_count == len(jobs)`. The inspector requires the relevant job's run ID, attempt and head SHA to match the run response. It accepts the documented optional `@ref` suffix on the workflow path while requiring the exact workflow base path and retaining the raw path in the verdict.

The relevant REST resources are:

```text
GET /repos/larsbx/pisot-substitution-conjecture-research/actions/runs/EXPECTED_RUN_ID
GET /repos/larsbx/pisot-substitution-conjecture-research/actions/runs/EXPECTED_RUN_ID/jobs?filter=latest&per_page=100
```

Download the workflow artifact named `original-c4-payload-EXPECTED_COMMIT`, with the complete expected commit substituted. Pass its extracted content directory, containing `revision.txt`, `archive-sha256.txt`, `lean-audit.log`, `native-oracle-receipt.json`, and the `lean/` directory. Keep the actual artifact-list/download metadata and ZIP digest as separate provenance: the requested run/jobs JSON does not contain the artifact ID or uploaded ZIP digest. The inspector records this limit and hashes every extracted file instead of inventing those identifiers.

After the completed inputs exist, use a fresh output directory outside both the repository and artifact:

```sh
python -B /workspace/scratch/5535bb23ca85/inspect-hosted-named-exclusion-audit.py \
  --artifact-root /absolute/path/to/extracted-workflow-artifact \
  --run-metadata /absolute/path/to/raw-completed-run.json \
  --jobs-metadata /absolute/path/to/raw-completed-jobs.json \
  --metadata /absolute/path/to/repaired-source-metadata.json \
  --root /absolute/path/to/clean-repaired-checkout \
  --expected-commit FULL_REPAIRED_COMMIT_SHA \
  --expected-tree FULL_REPAIRED_TREE_SHA \
  --expected-run-id REPAIRED_ARCHIVED_WORKFLOW_RUN_ID \
  --output /absolute/path/to/fresh-hosted-inspection
```

This command is an inspection recipe; it has not been executed as part of preparation. No activation command is needed.

## Required evidence

The run and relevant job must both have actual completed/success verdicts. The following exact steps must also have completed/success verdicts:

- Bind exact candidate revision and archive.
- Provision pinned Lean and dependency sources.
- Canonical payload construction and import controls.
- Independent payload and original graph replay.
- Isolated full build and both concrete geometric imports.

The exact clean checkout, static metadata, artifact revision/tree, original archive checksum, Lean/Mathlib pins, and all sixteen concrete replay source hashes must agree. The script imports only the hash-verified repository parsers and calls their read-only helpers; it never invokes the replay orchestration function.

For the global audit it reuses `make_proof_bank.check_audit` against the complete published proof-bank inventory and requires the exact acknowledgement in the untrimmed full log. It then matches all twelve explicit declarations from the two new modules: ten theorems and two definitions, with exact owners, full public names and compiled kinds. All compiler-generated helper rows remain included in the extracted module totals and the global axiom check. The only permitted transitive axioms are `propext`, `Classical.choice` and `Quot.sound`.

For each actual fixture it checks all seven semantic proofs, exact generated audit-source bytes, source/log digests and complete audit counts, reuses `extract_packet` to reconstruct emitted bytes from the retained audit transcript, and checks the independent oracle's original archive identities. It requires the separate exclusion-only wrong-type audit source and its intended type-mismatch diagnostic, with no unresolved-name error. It also binds the native packet/oracle bytes, all thirty-two native mutation refusals, and retained native/oracle test acknowledgements. The final JSON in the complete hosted audit log must match the concrete replay receipt.

## Output and refusal

On complete success the output contains:

- `inspection.json`, with actual GitHub run/job/critical-step verdicts, source and artifact identities, proof/audit counts, concrete fixture results and scope.
- `compiled-new-declarations.log`, containing all rows owned by the two new modules, including generated helpers.
- `artifact-manifest.json`, with byte sizes and SHA256 hashes for every extracted artifact file.
- Exact copies of the supplied raw run, jobs and source-metadata JSON.

On incomplete, failed, mismatched or malformed evidence the inspector exits nonzero and writes `refusal.json` rather than an acceptance report. Its own exit code is only a postprocessor result. No local gate return code is synthesized from GitHub conclusions. Input source and artifact identities are checked for change during inspection.

The resulting scope, if verified, remains the two literal substitutions and arbitrary finite carriers for those fixtures. It establishes no general C4/PSC conclusion and does not claim independent human review.

## Quiet pytest transcript compatibility repair

The previously source-reviewed inspector was 29,099 bytes, SHA256 `d09562064b2172db7878ae1dd14a8fc3213434582fe25f9b5b8da2bb041f620d`. It required a textual pytest passed-count summary. The genuine archived artifact from failed run `43345576753`, job `131624030047`, artifact `14009577399`, instead contains an 80-byte `oracle-tests.log`: eight dots, horizontal padding, `[100%]`, and a newline. Its SHA256 is `06955fb47f16312e5d13266c774a2aa4648c46e423cbe6564a92e25b68e39131`; the original ZIP SHA256 is `a3ba4c34e2246aa4a9f077205ec95b57b9f387694106bae2ed6c2ad3eea188b5`.

The raw GitHub record shows that `Independent payload and original graph replay` completed successfully in that job. The later Lean build failed, so the failed run still receives no acceptance credit. These records establish a parser-format compatibility issue without establishing a successful full gate.

The narrow repair accepts either the complete eight-dot `[100%]` quiet transcript or a normal exact eight-passed summary, with optional matching eight-dot progress line. Both forms require the actual bound GitHub oracle step to have completed successfully. The entire nonempty transcript must match one of those forms; skips, xfails, xpasses, errors, failures, deselection and incomplete progress are refused. The enclosing successful run/job/step, source, proof-bank and concrete payload requirements remain unchanged.

For quiet output, the report explicitly records `reported_passed_count: null` and `normal_pass_summary_present: false`, alongside the observed eight dots and successful step verdict. Original stdout is never changed and no textual summary is invented. This repair changes only the external inspector and this guidance; it changes no source workflow or test.
