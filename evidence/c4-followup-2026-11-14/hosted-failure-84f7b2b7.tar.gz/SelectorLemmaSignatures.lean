import Mathlib.Data.Fin.VecNotation

namespace SelectorLemmaSignatures

theorem first {α : Type*} (x y : α) : (![x, y] : Fin 2 → α) 0 = x :=
  Matrix.cons_val_zero x ![y]

theorem second {α : Type*} (x y : α) : (![x, y] : Fin 2 → α) 1 = y :=
  (Matrix.cons_val_one x ![y]).trans (Matrix.cons_val_zero y ![])

#print axioms first
#print axioms second

end SelectorLemmaSignatures
