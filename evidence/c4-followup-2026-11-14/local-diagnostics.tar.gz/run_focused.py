from pathlib import Path
import subprocess,os,time,json,hashlib,sys,resource
root=Path('/workspace/scratch/2880252a6b94/psc')
project=root/'proof/PscVerif'
out=Path('/workspace/scratch/2880252a6b94/psc-run')
module=sys.argv[1]
manifest=json.loads((project/'lake-manifest.json').read_text())
paths=[str((project/'.lake/packages'/p['name']/'.lake/build/lib/lean').resolve()) for p in manifest['packages']]
paths += [str(project/'.lake/build/lib/lean'), '/tmp/psc-lean/lib/lean']
env=os.environ.copy(); env['LEAN_PATH']=':'.join(paths)
source=project/('PscVerif/'+module+'.lean')
obj=project/('.lake/build/lib/lean/PscVerif/'+module+'.olean')
command=['/tmp/psc-lean/bin/lean','-j1','-o',str(obj),str(source.relative_to(project))]
before=hashlib.sha256(source.read_bytes()).hexdigest()
started=time.time()
print(json.dumps({'module':module,'command':command,'source_sha256':before,'started_unix':started}),flush=True)
with (out/(module+'.log')).open('wb') as log:
    result=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'module':module,'command':command,'source_sha256':before,'unchanged_source':hashlib.sha256(source.read_bytes()).hexdigest()==before,'exit_code':result.returncode,'elapsed_seconds':time.time()-started,'max_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'object_exists':obj.exists(),'scope':'focused production module with cached dependencies; not isolated acceptance'}
if obj.exists(): receipt['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest()
(out/(module+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
print((out/(module+'.log')).read_text()[-6000:],flush=True)
sys.exit(result.returncode)
