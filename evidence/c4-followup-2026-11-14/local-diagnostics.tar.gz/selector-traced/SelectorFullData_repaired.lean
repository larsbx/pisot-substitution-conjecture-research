import PscVerif.NamedForwardCarrierData1
import PscVerif.NamedForwardCarrierWords0

#check Psc.GeneratedForwardCarrier.fixture1ForwardCheck
#eval IO.eprintln "PSC_SELECTOR_DIAGNOSTIC imports_complete"

/- Conditional diagnostic only. Both full literal state tables are retained.
   Fixture 0's checker is an explicit hypothesis, never an axiom or sorry.
   No local recursion-depth override is used. -/
namespace Psc.GeneratedForwardCarrier
noncomputable def fixture0Substitution : Fin 3 → List (Fin 3) := ![[1],[0,2,1],[0,0,1]]

#check checkedStates
#eval IO.eprintln "PSC_SELECTOR_DIAGNOSTIC selectors_declared"

noncomputable def fixture0Packet : Psc.FastForwardCarrier.Packet 192 where
  state := fixture0State
  rows := fixture0Rows
  seed := fixture0Seed

#check checkedStates
#eval IO.eprintln "PSC_SELECTOR_DIAGNOSTIC selectors_declared"

noncomputable def fixture0States : List (List (Fin 3) × List (Fin 3)) := List.ofFn fixture0Packet.state
end Psc.GeneratedForwardCarrier

namespace Psc.NamedPrefixCompact
abbrev Word := List (Fin 3)
def sigma0 : Fin 3 → Word := ![[1], [0, 2, 1], [0, 0, 1]]
def sigma1 : Fin 3 → Word := ![[1], [0, 1, 2], [0, 0, 1]]

def substitution (fixture : Fin 2) : Fin 3 → Word := ![sigma0, sigma1] fixture
end Psc.NamedPrefixCompact

namespace Psc.NamedForwardCarrier
open Psc.NamedPrefixCompact
def check (fixture : Fin 2) (states : List (List (Fin 3) × List (Fin 3))) : Bool :=
  Psc.ForwardCarrier.check (substitution fixture) states

theorem fixture0Substitution_eq :
    Psc.GeneratedForwardCarrier.fixture0Substitution = substitution 0 := rfl

theorem fixture1Substitution_eq :
    Psc.GeneratedForwardCarrier.fixture1Substitution = substitution 1 := rfl

noncomputable def checkedStates (fixture : Fin 2) : List (List (Fin 3) × List (Fin 3)) :=
  ![Psc.GeneratedForwardCarrier.fixture0States,
    Psc.GeneratedForwardCarrier.fixture1States] fixture

theorem check_checkedStatesDiagnostic
    (h0 : Psc.ForwardCarrier.check
      Psc.GeneratedForwardCarrier.fixture0Substitution
      Psc.GeneratedForwardCarrier.fixture0States = true)
    (fixture : Fin 2) :
    check fixture (checkedStates fixture) = true := by
  fin_cases fixture
  · have hstates : checkedStates 0 = Psc.GeneratedForwardCarrier.fixture0States := rfl
    exact (congrArg₂ Psc.ForwardCarrier.check fixture0Substitution_eq hstates.symm).symm.trans
      h0
  · have hstates : checkedStates 1 = Psc.GeneratedForwardCarrier.fixture1States := rfl
    exact (congrArg₂ Psc.ForwardCarrier.check fixture1Substitution_eq hstates.symm).symm.trans
      Psc.GeneratedForwardCarrier.fixture1ForwardCheck

end Psc.NamedForwardCarrier

#print axioms Psc.NamedForwardCarrier.check_checkedStatesDiagnostic
#print axioms Psc.GeneratedForwardCarrier.fixture1ForwardCheck
