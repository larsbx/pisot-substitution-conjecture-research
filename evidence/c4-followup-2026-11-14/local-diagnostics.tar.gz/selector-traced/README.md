# Conditional selector diagnostic with both literal carriers

This is a focused diagnostic with cached dependencies. It is **not** a production
module build, an isolated library audit, or acceptance of either termination
consumer.

The source imports the actual `NamedForwardCarrierData1` checker and the actual
`NamedForwardCarrierWords0` payload. It copies fixture 0's substitution, packet,
and state-list definitions verbatim from the production Data0 source. The
fixture-0 checker equality is an explicit theorem parameter. No axiom, `sorry`,
empty fixture slot, changed carrier table, or recursion-limit override supplies
that premise. The named substitutions, selector, checker, and substitution
binding bodies are copied from production sources.

The only proof-body adaptation substitutes that theorem parameter for
`fixture0ForwardCheck`. The fixture-1 proof remains the imported actual proof.
Consequently even a successful diagnostic would prove only the stated
conditional selector lemma, with its recorded cached-dependency trust boundary.

`selector-diagnostic-inputs.json` records complete copied declaration text and
hashes, source file hashes, imported object hashes, the exact runtime hash, and
the dependency path. The runner records the command, source and log hashes,
terminal exit, elapsed time, sampled RSS, object presence, input stability,
and printed axiom records.

The first baseline and repaired attempts in the parent directory each reached
their explicit 180-second cap, received SIGTERM from the owned runner, and
produced no object or diagnostic output. They are inconclusive. Those files and
receipts remain unchanged. They reproduce neither the production recursion
error nor a successful repair.

This separate repaired-only retry has a 600-second cap, `-j1`, and a 1-GiB Lean
memory limit. It adds `#check` commands and immediate stderr markers after imports
and after selector declarations to distinguish a delayed import from proof
elaboration. The immediate markers themselves use `#eval IO.eprintln`, so they
also exercise Lean's interpreter.

## Observed terminal outcome

The retry terminated after 541.311 seconds with exit `-6` (SIGABRT), before the
600-second time guard fired. Lean reported an uncaught `lean::memory_exception`:
`excessive memory consumption detected at 'interpreter'`. The command explicitly
set `-M1024`; sampled peak RSS was 1,173,280 KiB. No object, recursion-depth
diagnostic, axiom record, or progress marker was recorded, and all recorded
inputs remained unchanged.

This is a resource-limited inconclusive diagnostic. Marker evaluation may itself
contribute interpreter overhead; the empty buffered output does not establish
which command was being processed at the abort. It neither validates nor refutes
the repaired theorem. No further Lean retry was launched.

The terminal receipt is authoritative for this retry's outcome. No result here
can replace the full production module build or the complete isolated
nine-endpoint original-archive replay.
