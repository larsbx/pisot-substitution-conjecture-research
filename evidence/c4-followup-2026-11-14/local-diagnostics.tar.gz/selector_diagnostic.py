from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('/workspace/scratch/2880252a6b94/psc')
PROJECT = ROOT / 'proof/PscVerif'
OUT = Path('/workspace/scratch/2880252a6b94/psc-run')
LEAN = Path('/tmp/psc-lean/bin/lean')
SCOPE = ('Conditional focused selector diagnostic using both actual literal state tables, '
         'the exact cached fixture-1 checker and fixture-0 check as an explicit theorem '
         'hypothesis. No production or isolated-acceptance claim.')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def declaration(source, marker):
    start = source.index(marker)
    end = source.find('\n\n', start)
    return source[start:end if end != -1 else len(source)]

data0_path = PROJECT / 'PscVerif/NamedForwardCarrierData0.lean'
prefix_path = PROJECT / 'PscVerif/NamedPrefixCompact.lean'
candidate_path = PROJECT / 'PscVerif/NamedForwardCarrier.lean'
baseline_path = OUT / 'baseline-NamedForwardCarrier.lean'
data0 = data0_path.read_text()
prefix = prefix_path.read_text()
candidate = candidate_path.read_text()
baseline = baseline_path.read_text()

copied = {
    'fixture0Substitution': declaration(data0, 'noncomputable def fixture0Substitution'),
    'fixture0Packet': declaration(data0, 'noncomputable def fixture0Packet'),
    'fixture0States': declaration(data0, 'noncomputable def fixture0States'),
    'sigma0_sigma1': declaration(prefix, 'def sigma0'),
    'substitution': declaration(prefix, 'def substitution'),
    'check': declaration(candidate, 'def check '),
    'fixture0Substitution_eq': declaration(candidate, 'theorem fixture0Substitution_eq'),
    'fixture1Substitution_eq': declaration(candidate, 'theorem fixture1Substitution_eq'),
    'checkedStates': declaration(candidate, 'noncomputable def checkedStates'),
}
# The original alias is copied with the original definition bodies. No theorem
# about named compact geometry is imported or assumed by this diagnostic.
header = '''import PscVerif.NamedForwardCarrierData1
import PscVerif.NamedForwardCarrierWords0

/- Conditional diagnostic only. Both full literal state tables are retained.
   Fixture 0's checker is an explicit hypothesis, never an axiom or sorry.
   No local recursion-depth override is used. -/
namespace Psc.GeneratedForwardCarrier
'''
header += '\n\n'.join(copied[name] for name in ('fixture0Substitution', 'fixture0Packet', 'fixture0States'))
header += '''
end Psc.GeneratedForwardCarrier

namespace Psc.NamedPrefixCompact
abbrev Word := List (Fin 3)
'''
header += '\n\n'.join(copied[name] for name in ('sigma0_sigma1', 'substitution'))
header += '''
end Psc.NamedPrefixCompact

namespace Psc.NamedForwardCarrier
open Psc.NamedPrefixCompact
'''
header += '\n\n'.join(copied[name] for name in ('check', 'fixture0Substitution_eq', 'fixture1Substitution_eq', 'checkedStates'))
header += '\n\n'
footer = '''
end Psc.NamedForwardCarrier

#print axioms Psc.NamedForwardCarrier.check_checkedStatesDiagnostic
#print axioms Psc.GeneratedForwardCarrier.fixture1ForwardCheck
'''

manifest = json.loads((PROJECT / 'lake-manifest.json').read_text())
paths = [str((PROJECT / '.lake/packages' / package['name'] / '.lake/build/lib/lean').resolve())
         for package in manifest['packages']]
paths += [str(PROJECT / '.lake/build/lib/lean'), '/tmp/psc-lean/lib/lean']
env = os.environ.copy()
env['LEAN_PATH'] = ':'.join(paths)

inputs = [data0_path, prefix_path, candidate_path, baseline_path, PROJECT / 'lake-manifest.json', LEAN]
for module in ('NamedForwardCarrierWords0', 'NamedForwardCarrierWords1',
               'NamedForwardCarrierData1', 'FastForwardCarrier', 'ForwardCarrier', 'Descendants'):
    inputs.append(PROJECT / f'PscVerif/{module}.lean')
    inputs.extend(sorted((PROJECT / '.lake/build/lib/lean/PscVerif').glob(module + '.olean*')))
input_hashes = {str(path): digest(path) for path in inputs}
copied_hashes = {name: {'text': body, 'sha256': hashlib.sha256(body.encode()).hexdigest()}
                 for name, body in copied.items()}
(OUT / 'selector-diagnostic-inputs.json').write_text(json.dumps({
    'scope': SCOPE, 'input_sha256': input_hashes,
    'copied_declarations': copied_hashes, 'lean_path': env['LEAN_PATH'],
}, indent=2) + '\n')

results = []
for label, source in [('baseline', baseline), ('repaired', candidate)]:
    theorem = declaration(source, 'theorem check_checkedStates ')
    theorem = theorem.replace('theorem check_checkedStates (fixture : Fin 2)',
        'theorem check_checkedStatesDiagnostic\n'
        '    (h0 : Psc.ForwardCarrier.check\n'
        '      Psc.GeneratedForwardCarrier.fixture0Substitution\n'
        '      Psc.GeneratedForwardCarrier.fixture0States = true)\n'
        '    (fixture : Fin 2)')
    theorem = theorem.replace('Psc.GeneratedForwardCarrier.fixture0ForwardCheck', 'h0')
    path = OUT / f'SelectorFullData_{label}.lean'
    path.write_text(header + theorem + '\n' + footer)
    obj = OUT / f'SelectorFullData_{label}.olean'
    log_path = OUT / f'SelectorFullData_{label}.log'
    command = [str(LEAN), '-j1', '-M1024', '-o', str(obj), str(path)]
    started = time.time()
    peak_rss = 0
    timed_out = False
    print(json.dumps({'starting': label, 'command': command, 'scope': SCOPE}), flush=True)
    with log_path.open('wb') as log:
        process = subprocess.Popen(command, cwd=OUT, env=env, stdout=log, stderr=subprocess.STDOUT)
        while process.poll() is None:
            status = Path(f'/proc/{process.pid}/status')
            if status.exists():
                match = re.search(r'^VmRSS:\s+(\d+) kB$', status.read_text(), re.M)
                if match:
                    peak_rss = max(peak_rss, int(match.group(1)))
            if time.time() - started > 180:
                timed_out = True
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                break
            time.sleep(0.2)
        code = process.wait()
    content = log_path.read_text()
    result = {
        'label': label, 'scope': SCOPE, 'command': command,
        'started_unix': started, 'elapsed_seconds': time.time() - started,
        'exit_code': code, 'timed_out': timed_out, 'sampled_peak_rss_kib': peak_rss,
        'source_sha256': digest(path), 'log_sha256': digest(log_path),
        'object_exists': obj.exists(),
        'object_sha256': digest(obj) if obj.exists() else None,
        'recursion_error_observed': 'maximum recursion depth has been reached' in content,
        'axiom_records': [line for line in content.splitlines() if 'depends on axioms' in line],
        'inputs_unchanged': all(digest(Path(path)) == value for path, value in input_hashes.items()),
    }
    results.append(result)
    (OUT / f'SelectorFullData_{label}-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    print(content, flush=True)

(OUT / 'selector-diagnostic-summary.json').write_text(json.dumps({
    'scope': SCOPE, 'results': results,
    'intended_pair_observed': (results[0]['exit_code'] != 0
        and results[0]['recursion_error_observed'] and results[1]['exit_code'] == 0),
}, indent=2) + '\n')
