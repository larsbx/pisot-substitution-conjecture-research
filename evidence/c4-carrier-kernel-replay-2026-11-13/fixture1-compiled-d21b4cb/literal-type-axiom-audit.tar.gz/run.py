"""Run only after the recorded successful actual fixture-1 checker build."""
from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/91efcf4b7b58/psc')
PROJECT = ROOT / 'proof/PscVerif'
DIAGNOSTICS = OUT.parent
LEAN = Path('/tmp/psc-lean/bin/lean')
SOURCE = OUT / 'FocusedCarrier1Audit.lean'
OBJECT = SOURCE.with_suffix('.olean')
TERMINAL = DIAGNOSTICS / 'carrier1-split-terminal.json'
START = DIAGNOSTICS / 'carrier1-split-start.json'
DATA_SOURCE = PROJECT / 'PscVerif/NamedForwardCarrierData1.lean'
DATA_OBJECT = PROJECT / '.lake/build/lib/lean/PscVerif/NamedForwardCarrierData1.olean'


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


# No compiler invocation or receipt is produced before these terminal checks.
if not TERMINAL.is_file():
    raise SystemExit('Actual Data1 has no terminal receipt; audit not run')
terminal, start = json.loads(TERMINAL.read_text()), json.loads(START.read_text())
if not (terminal['status'] == 'passed' and terminal['compiler_returncode'] == 0
        and terminal['source_unchanged'] and terminal['object_exists']
        and terminal['stop_reason'] is None):
    raise SystemExit('Actual Data1 did not finish successfully; audit not run')
assert digest(DATA_SOURCE) == start['source_sha256'] == terminal['source_sha256']
assert digest(DATA_SOURCE) == 'a49d8fa4146b534cff95259beab31a06903088184676704c239eb11b98cc4c0a'
assert digest(DATA_OBJECT) == terminal['object_sha256']
assert digest(LEAN) == start['compiler_sha256']
assert not OBJECT.exists() and not (OUT / 'receipt.json').exists()
assert re.findall(r'^import (.+)$', SOURCE.read_text(), re.MULTILINE) == [
    'PscVerif.NamedForwardCarrierData1']
for dependency in start['dependencies']:
    if dependency['module'] == 'Init':
        assert digest(LEAN.parent.parent / 'lib/lean/Init.olean') == dependency['object_sha256']
        continue
    relative = Path(*dependency['module'].split('.'))
    assert digest((PROJECT / relative).with_suffix('.lean')) == dependency['source_sha256']
    assert digest((PROJECT / '.lake/build/lib/lean' / relative).with_suffix('.olean')) == dependency['object_sha256']

sys.path.insert(0, str(ROOT / 'tools'))
from make_proof_bank import lean_code

modules, pending = set(), ['PscVerif.NamedForwardCarrierData1']
while pending:
    module = pending.pop()
    if module in modules:
        continue
    modules.add(module)
    source = (PROJECT / Path(*module.split('.'))).with_suffix('.lean')
    pending += re.findall(r'(?m)^\s*(?:public\s+)?import\s+(PscVerif(?:\.\S+)?)\s*$',
                          lean_code(source.read_text()))
assert 'PscVerif.NamedStrictExclusion' not in modules
inputs = {SOURCE, Path(__file__).resolve(), DATA_SOURCE, DATA_OBJECT, LEAN,
          START, TERMINAL, ROOT / 'tools/make_proof_bank.py',
          PROJECT / 'lean-toolchain', PROJECT / 'lakefile.toml', PROJECT / 'lake-manifest.json',
          LEAN.parent.parent / 'lib/lean/Init.olean',
          LEAN.parent.parent / 'lib/lean/Lean/Util/CollectAxioms.olean'}
for module in modules:
    relative = Path(*module.split('.'))
    inputs.add((PROJECT / relative).with_suffix('.lean'))
    obj = (PROJECT / '.lake/build/lib/lean' / relative).with_suffix('.olean')
    inputs.add(obj)
    private = Path(str(obj) + '.private')
    if private.exists():
        inputs.add(private)


def snapshot():
    return {str(path): {'sha256': digest(path), 'bytes': path.stat().st_size}
            for path in sorted(inputs)}


before = snapshot()
(OUT / 'INPUTS.sha256').write_text(''.join(
    f"{record['sha256']}  {path}\n" for path, record in before.items()))
env = {key: value for key, value in os.environ.items() if not key.startswith('LEAN_')}
paths = [PROJECT / '.lake/build/lib/lean']
paths += sorted(path / '.lake/build/lib/lean'
                for path in (PROJECT / '.lake/packages').iterdir() if path.is_dir())
env['LEAN_PATH'] = os.pathsep.join(map(str, paths))
env['LEAN_NUM_THREADS'] = '2'
command = [str(LEAN), '--root=' + str(OUT), '-j', '2', '-DElab.async=false',
           '-o', str(OBJECT), str(SOURCE)]
receipt = {
    'schema': 'psc-focused-carrier-literal-audit-v1',
    'scope': 'focused cached-dependency fixture-1 literal carrier and finite-descendant type/axiom audit',
    'full_isolated_acceptance': False, 'termination_claimed': False,
    'external_dependency_objects_all_hashed': False,
    'input_scope': 'complete local project import-closure source/objects, compiler, selected core inputs and dependency manifest; external cached objects remain an explicit trust input',
    'input_files': before, 'local_import_closure': sorted(modules),
    'data_build_terminal': str(TERMINAL), 'data_build_terminal_sha256': digest(TERMINAL),
    'command': command, 'cwd': str(PROJECT),
    'environment': {key: env[key] for key in ('LEAN_PATH', 'LEAN_NUM_THREADS')},
    'compiler_version': subprocess.check_output([str(LEAN), '--version'], text=True).strip(),
    'wall_guard_seconds': 600, 'rss_guard_bytes': 4000000000,
    'sample_interval_seconds': 0.5, 'maximum_sampled_rss_bytes': 0,
    'stop_reason': None,
}
(OUT / 'start.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
started = time.monotonic()
with (OUT / 'compile.log').open('xb') as log, (OUT / 'resources.jsonl').open('x') as resources:
    process = subprocess.Popen(command, cwd=PROJECT, env=env,
                               stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    while process.poll() is None:
        elapsed = time.monotonic() - started
        try:
            rss = int(Path(f'/proc/{process.pid}/statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
        except (FileNotFoundError, ProcessLookupError):
            rss = 0
        receipt['maximum_sampled_rss_bytes'] = max(receipt['maximum_sampled_rss_bytes'], rss)
        resources.write(json.dumps({'elapsed_seconds': elapsed, 'rss_bytes': rss}) + '\n')
        resources.flush()
        reason = ('rss_guard' if rss >= receipt['rss_guard_bytes'] else
                  'wall_guard' if elapsed >= receipt['wall_guard_seconds'] else None)
        if reason:
            receipt['stop_reason'] = reason
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
            break
        time.sleep(0.5)
    receipt['compiler_returncode'] = process.wait()
receipt['elapsed_seconds'] = round(time.monotonic() - started, 6)
receipt['input_bytes_unchanged'] = snapshot() == before
receipt['object_exists'] = OBJECT.is_file()
receipt['object_sha256'] = digest(OBJECT) if OBJECT.is_file() else None
receipt['compile_log_sha256'] = digest(OUT / 'compile.log')
expected = {
    'Psc.FocusedCarrier1Audit.packetValidLiteral',
    'Psc.FocusedCarrier1Audit.forwardCheckLiteral',
    'Psc.FocusedCarrier1Audit.finiteDescendantsLiteral',
    'Psc.GeneratedForwardCarrier.fixture1Valid',
    'Psc.GeneratedForwardCarrier.fixture1ForwardCheck',
    'Psc.GeneratedForwardCarrier.fixture1Finite',
}
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
audited, completion, protocol_error = {}, False, None
try:
    for line in (OUT / 'compile.log').read_text().splitlines():
        if line.startswith('PSC_FOCUSED_CARRIER1_AXIOMS\t'):
            fields = line.split('\t')
            if completion or len(fields) != 3 or fields[1] in audited or fields[1] not in expected:
                raise ValueError('malformed or unbound axiom record')
            axioms = set(filter(None, fields[2].split(',')))
            if axioms - allowed:
                raise ValueError('nonstandard axiom in audit output')
            audited[fields[1]] = sorted(axioms)
        elif line == 'PSC_FOCUSED_CARRIER1_COMPLETE\t6' and not completion:
            completion = True
        elif line.strip():
            raise ValueError('unexpected compiler/audit output: ' + line[:200])
    if set(audited) != expected or not completion:
        raise ValueError('missing audited theorems or terminal completion')
except ValueError as error:
    protocol_error = str(error)
receipt['audited_theorems'] = audited
receipt['protocol_error'] = protocol_error
receipt['status'] = ('passed' if receipt['compiler_returncode'] == 0
                     and receipt['stop_reason'] is None and receipt['object_exists']
                     and receipt['input_bytes_unchanged'] and protocol_error is None else 'failed')
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
(OUT / 'SHA256SUMS').write_text(''.join(
    f'{digest(path)}  {path.name}\n' for path in sorted(OUT.iterdir())
    if path.is_file() and path.name != 'SHA256SUMS'))
print(json.dumps({key: receipt[key] for key in (
    'status', 'compiler_returncode', 'elapsed_seconds', 'maximum_sampled_rss_bytes',
    'stop_reason', 'object_exists', 'object_sha256', 'input_bytes_unchanged',
    'audited_theorems', 'protocol_error')}, indent=2, sort_keys=True))
raise SystemExit(0 if receipt['status'] == 'passed' else 1)
