import PscVerif.NamedForwardCarrierData1

-- Focused cached-dependency audit; no isolated-build or termination claim.
-- The substitution is literal in each closed conclusion.
namespace Psc.FocusedCarrier1Audit

set_option maxRecDepth 200000
set_option maxHeartbeats 0

theorem packetValidLiteral :
    Psc.GeneratedForwardCarrier.fixture1Packet.Valid
      (![[1], [0, 1, 2], [0, 0, 1]] : Fin 3 → List (Fin 3)) :=
  Psc.GeneratedForwardCarrier.fixture1Valid

theorem forwardCheckLiteral :
    Psc.ForwardCarrier.check
      (![[1], [0, 1, 2], [0, 0, 1]] : Fin 3 → List (Fin 3))
      Psc.GeneratedForwardCarrier.fixture1States = true :=
  Psc.GeneratedForwardCarrier.fixture1ForwardCheck

theorem finiteDescendantsLiteral :
    (Psc.Descendants.bpaStatesNC
      (![[1], [0, 1, 2], [0, 0, 1]] : Fin 3 → List (Fin 3))).Finite :=
  Psc.FastForwardCarrier.Packet.finite_bpaStatesNC
    Psc.GeneratedForwardCarrier.fixture1Packet
    (![[1], [0, 1, 2], [0, 0, 1]] : Fin 3 → List (Fin 3))
    packetValidLiteral

end Psc.FocusedCarrier1Audit

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  if env.header.moduleNames.contains `PscVerif.NamedStrictExclusion then
    throwError "Focused carrier audit unexpectedly imported NamedStrictExclusion"
  let some _ := env.getModuleIdx? `PscVerif.NamedForwardCarrierData1
    | throwError "Missing actual fixture-1 checker module"
  let names := #[
    `Psc.FocusedCarrier1Audit.packetValidLiteral,
    `Psc.FocusedCarrier1Audit.forwardCheckLiteral,
    `Psc.FocusedCarrier1Audit.finiteDescendantsLiteral,
    `Psc.GeneratedForwardCarrier.fixture1Valid,
    `Psc.GeneratedForwardCarrier.fixture1ForwardCheck,
    `Psc.GeneratedForwardCarrier.fixture1Finite]
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  for name in names do
    let some info := env.find? name | throwError "Missing required audit theorem: {name}"
    if !info.isTheorem then throwError "Required audit declaration is not a theorem: {name}"
    let axioms ← collectAxioms name
    for ax in axioms do
      if !allowed.contains ax then
        throwError "Nonstandard transitive axiom in {name}: {ax}"
    let dependencies := String.intercalate "," (axioms.toList.map toString)
    liftIO <| IO.println s!"PSC_FOCUSED_CARRIER1_AXIOMS\t{name}\t{dependencies}"
  liftIO <| IO.println s!"PSC_FOCUSED_CARRIER1_COMPLETE\t{names.size}"
