noncomputable def traceIndex0 : Fin 3 := ⟨0, by decide⟩
noncomputable def traceWord : List (Fin 3) := [traceIndex0, 1, 2]
theorem traceWord_length : traceWord.length = 3 := by decide +kernel
#eval (show IO Unit from do IO.sleep 2000)
