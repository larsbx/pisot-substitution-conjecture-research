namespace Psc.GeneratedForwardCarrier

set_option maxRecDepth 200000
set_option maxHeartbeats 0

noncomputable def fixture1Chunk0 : List (Fin 3) := [0,1]
noncomputable def fixture1Chunk1 : List (Fin 3) := [1,0]
noncomputable def fixture1Chunk2 : List (Fin 3) := [0,2]
noncomputable def fixture1Chunk3 : List (Fin 3) := [2,0]
noncomputable def fixture1Chunk4 : List (Fin 3) := [1,2]
noncomputable def fixture1Chunk5 : List (Fin 3) := [2,1]
noncomputable def fixture1Chunk6 : List (Fin 3) := [0,0,1]
noncomputable def fixture1Chunk7 : List (Fin 3) := [1,0,0]
noncomputable def fixture1Chunk8 : List (Fin 3) := [1]
noncomputable def fixture1Chunk9 : List (Fin 3) := [0]
noncomputable def fixture1Chunk10 : List (Fin 3) := [0,1,0,1,2]
noncomputable def fixture1Chunk11 : List (Fin 3) := [1,2,0,0,1]
noncomputable def fixture1Chunk12 : List (Fin 3) := [0,1,2,1,1]
noncomputable def fixture1Chunk13 : List (Fin 3) := [1,1,0,1,2]
noncomputable def fixture1Chunk14 : List (Fin 3) := [1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk15 : List (Fin 3) := [2,0,0,1,1,1,0,1,2]
noncomputable def fixture1Chunk16 : List (Fin 3) := [1,2,0]
noncomputable def fixture1Chunk17 : List (Fin 3) := [2,0,1]
noncomputable def fixture1Chunk18 : List (Fin 3) := [0,1,0,1,2,0,1,2]
noncomputable def fixture1Chunk19 : List (Fin 3) := [2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk20 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0]
noncomputable def fixture1Chunk21 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk22 : List (Fin 3) := [0,1,1,0,1,2]
noncomputable def fixture1Chunk23 : List (Fin 3) := [1,2,0,0,1,1]
noncomputable def fixture1Chunk24 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk25 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk26 : List (Fin 3) := [0,0,1,1,1,0,1,2]
noncomputable def fixture1Chunk27 : List (Fin 3) := [1,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk28 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk29 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk30 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk31 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2]
noncomputable def fixture1Chunk32 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk33 : List (Fin 3) := [1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk34 : List (Fin 3) := [0,1,2,0,1,2,1,0,1]
noncomputable def fixture1Chunk35 : List (Fin 3) := [1,1,0,1,2,0,1,2,0]
noncomputable def fixture1Chunk36 : List (Fin 3) := [0,1,1,1,0,1,2,0]
noncomputable def fixture1Chunk37 : List (Fin 3) := [1,2,0,0,1,1,0,1]
noncomputable def fixture1Chunk38 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk39 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1]
noncomputable def fixture1Chunk40 : List (Fin 3) := [2]
noncomputable def fixture1Chunk41 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2]
noncomputable def fixture1Chunk42 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk43 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk44 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk45 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk46 : List (Fin 3) := [2,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk47 : List (Fin 3) := [0,1,1,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk48 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk49 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2]
noncomputable def fixture1Chunk50 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk51 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk52 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk53 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk54 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk55 : List (Fin 3) := [1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk56 : List (Fin 3) := [2,0,0,1,0,1,2,1]
noncomputable def fixture1Chunk57 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk58 : List (Fin 3) := [1,1,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk59 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk60 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk61 : List (Fin 3) := [0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk62 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk63 : List (Fin 3) := [0,1,2,1,0,1]
noncomputable def fixture1Chunk64 : List (Fin 3) := [1,1,0,1,2,0]
noncomputable def fixture1Chunk65 : List (Fin 3) := [0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk66 : List (Fin 3) := [1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk67 : List (Fin 3) := [0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk68 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk69 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk70 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk71 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk72 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk73 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk74 : List (Fin 3) := [1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk75 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk76 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk77 : List (Fin 3) := [0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk78 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk79 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk80 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk81 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk82 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk83 : List (Fin 3) := [0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk84 : List (Fin 3) := [1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk85 : List (Fin 3) := [0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk86 : List (Fin 3) := [2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk87 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk88 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk89 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk90 : List (Fin 3) := [1,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk91 : List (Fin 3) := [2,0,0,1,1,0,1,2]
noncomputable def fixture1Chunk92 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk93 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk94 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk95 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk96 : List (Fin 3) := [1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk97 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0]
noncomputable def fixture1Chunk98 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0]
noncomputable def fixture1Chunk99 : List (Fin 3) := [1,2,0,1,2]
noncomputable def fixture1Chunk100 : List (Fin 3) := [0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk101 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk102 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0]
noncomputable def fixture1Chunk103 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk104 : List (Fin 3) := [0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk105 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk106 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk107 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk108 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk109 : List (Fin 3) := [0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk110 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk111 : List (Fin 3) := [1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1]
noncomputable def fixture1Chunk112 : List (Fin 3) := [2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk113 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk114 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk115 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk116 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk117 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0]
noncomputable def fixture1Chunk118 : List (Fin 3) := [1,2,0,0]
noncomputable def fixture1Chunk119 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk120 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk121 : List (Fin 3) := [1,0,1,2]
noncomputable def fixture1Chunk122 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk123 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk124 : List (Fin 3) := [1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0]
noncomputable def fixture1Chunk125 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0]
noncomputable def fixture1Chunk126 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk127 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk128 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk129 : List (Fin 3) := [0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk130 : List (Fin 3) := [0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk131 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk132 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk133 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk134 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk135 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0]
noncomputable def fixture1Chunk136 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk137 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk138 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk139 : List (Fin 3) := [2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk140 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk141 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk142 : List (Fin 3) := [1,0,1,2,0]
noncomputable def fixture1Chunk143 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk144 : List (Fin 3) := [1,1,1,0,1]
noncomputable def fixture1Chunk145 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk146 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk147 : List (Fin 3) := [0,1,2,0,0,1,1]
noncomputable def fixture1Chunk148 : List (Fin 3) := [1,1,0,1,2,0,0]
noncomputable def fixture1Chunk149 : List (Fin 3) := [0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk150 : List (Fin 3) := [0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk151 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk152 : List (Fin 3) := [1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0]
noncomputable def fixture1Chunk153 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk154 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk155 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk156 : List (Fin 3) := [1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0]
noncomputable def fixture1Chunk157 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk158 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2]
noncomputable def fixture1Chunk159 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk160 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk161 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk162 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk163 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk164 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk165 : List (Fin 3) := [0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1]
noncomputable def fixture1Chunk166 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk167 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk168 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk169 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk170 : List (Fin 3) := [1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk171 : List (Fin 3) := [0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk172 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk173 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1]
noncomputable def fixture1Chunk174 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk175 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1]
noncomputable def fixture1Chunk176 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk177 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk178 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk179 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk180 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk181 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk182 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk183 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0]
noncomputable def fixture1Chunk184 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk185 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk186 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk187 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk188 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk189 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk190 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0]
noncomputable def fixture1Chunk191 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk192 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0]
noncomputable def fixture1Chunk193 : List (Fin 3) := [0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2]
noncomputable def fixture1Chunk194 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk195 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk196 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0]
noncomputable def fixture1Chunk197 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk198 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk199 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk200 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk201 : List (Fin 3) := [2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1]
noncomputable def fixture1Chunk202 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk203 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk204 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1]
noncomputable def fixture1Chunk205 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0]
noncomputable def fixture1Chunk206 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk207 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk208 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0]
noncomputable def fixture1Chunk209 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0]
noncomputable def fixture1Chunk210 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0]
noncomputable def fixture1Chunk211 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk212 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk213 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk214 : List (Fin 3) := [0,1,2]
noncomputable def fixture1Chunk215 : List (Fin 3) := [1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk216 : List (Fin 3) := [2,0,0]
noncomputable def fixture1Chunk217 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk218 : List (Fin 3) := [0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk219 : List (Fin 3) := [0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk220 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk221 : List (Fin 3) := [2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1]
noncomputable def fixture1Chunk222 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk223 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk224 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk225 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk226 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk227 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2]
noncomputable def fixture1Chunk228 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk229 : List (Fin 3) := [1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk230 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk231 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk232 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk233 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk234 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk235 : List (Fin 3) := [1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk236 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk237 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk238 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk239 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2]
noncomputable def fixture1Chunk240 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1]
noncomputable def fixture1Chunk241 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk242 : List (Fin 3) := [0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2]
noncomputable def fixture1Chunk243 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk244 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0]
noncomputable def fixture1Chunk245 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk246 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0]
noncomputable def fixture1Chunk247 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk248 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk249 : List (Fin 3) := [0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk250 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk251 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk252 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk253 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk254 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk255 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk256 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk257 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk258 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2]
noncomputable def fixture1Chunk259 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk260 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0]
noncomputable def fixture1Chunk261 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk262 : List (Fin 3) := [2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk263 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk264 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk265 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk266 : List (Fin 3) := [0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk267 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk268 : List (Fin 3) := [0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk269 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk270 : List (Fin 3) := [1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk271 : List (Fin 3) := [0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk272 : List (Fin 3) := [1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0]
noncomputable def fixture1Chunk273 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk274 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk275 : List (Fin 3) := [0,0,1,1,1]
noncomputable def fixture1Chunk276 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk277 : List (Fin 3) := [0,1,1,1,0,1]
noncomputable def fixture1Chunk278 : List (Fin 3) := [1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk279 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk280 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk281 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk282 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk283 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk284 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk285 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk286 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0]
noncomputable def fixture1Chunk287 : List (Fin 3) := [1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk288 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk289 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk290 : List (Fin 3) := [1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk291 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk292 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk293 : List (Fin 3) := [1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1]
noncomputable def fixture1Chunk294 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1]
noncomputable def fixture1Chunk295 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk296 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2]
noncomputable def fixture1Chunk297 : List (Fin 3) := [0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk298 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk299 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0]
noncomputable def fixture1Chunk300 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk301 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk302 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk303 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0]
noncomputable def fixture1Chunk304 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0]
noncomputable def fixture1Chunk305 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2]
noncomputable def fixture1Chunk306 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0]
noncomputable def fixture1Chunk307 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk308 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk309 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk310 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk311 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk312 : List (Fin 3) := [2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk313 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk314 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk315 : List (Fin 3) := [2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk316 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk317 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk318 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk319 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk320 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk321 : List (Fin 3) := [2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk322 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk323 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk324 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk325 : List (Fin 3) := [2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk326 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk327 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0]
noncomputable def fixture1Chunk328 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2]
noncomputable def fixture1Chunk329 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk330 : List (Fin 3) := [0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1]
noncomputable def fixture1Chunk331 : List (Fin 3) := [1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk332 : List (Fin 3) := [1,1]
noncomputable def fixture1Chunk333 : List (Fin 3) := [2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk334 : List (Fin 3) := [1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk335 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk336 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk337 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0]
noncomputable def fixture1Chunk338 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk339 : List (Fin 3) := [0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk340 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk341 : List (Fin 3) := [1,1,1]
noncomputable def fixture1Chunk342 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1]
noncomputable def fixture1Chunk343 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk344 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk345 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk346 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk347 : List (Fin 3) := [1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk348 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk349 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1]
noncomputable def fixture1Chunk350 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk351 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk352 : List (Fin 3) := [0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk353 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2]
noncomputable def fixture1Chunk354 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk355 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk356 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk357 : List (Fin 3) := [0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk358 : List (Fin 3) := [1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk359 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk360 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk361 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk362 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk363 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk364 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk365 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk366 : List (Fin 3) := [0,0,1,0,1,2]
noncomputable def fixture1Chunk367 : List (Fin 3) := [2,0,0,1,1,1]
noncomputable def fixture1Chunk368 : List (Fin 3) := [0,0]
noncomputable def fixture1Chunk369 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1]
noncomputable def fixture1Chunk370 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk371 : List (Fin 3) := [0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk372 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1]
noncomputable def fixture1Chunk373 : List (Fin 3) := [2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk374 : List (Fin 3) := [0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk375 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk376 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk377 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk378 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk379 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk380 : List (Fin 3) := [2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk381 : List (Fin 3) := [1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk382 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk383 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk384 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk385 : List (Fin 3) := [1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0]
noncomputable def fixture1Chunk386 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk387 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk388 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0]
noncomputable def fixture1Chunk389 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk390 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk391 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1]
noncomputable def fixture1Chunk392 : List (Fin 3) := [2,1,0,1,2]
noncomputable def fixture1Chunk393 : List (Fin 3) := [2,0,0,1,1]
noncomputable def fixture1Chunk394 : List (Fin 3) := [1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk395 : List (Fin 3) := [1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk396 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2]
noncomputable def fixture1Chunk397 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk398 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk399 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk400 : List (Fin 3) := [0,0,1,1]
noncomputable def fixture1Chunk401 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk402 : List (Fin 3) := [2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk403 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk404 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk405 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk406 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk407 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk408 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk409 : List (Fin 3) := [1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk410 : List (Fin 3) := [1,0,1]
noncomputable def fixture1Chunk411 : List (Fin 3) := [2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk412 : List (Fin 3) := [1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0]
noncomputable def fixture1Chunk413 : List (Fin 3) := [2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk414 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk415 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk416 : List (Fin 3) := [0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk417 : List (Fin 3) := [0,1,2,1,0,1,2]
noncomputable def fixture1Chunk418 : List (Fin 3) := [2,1,0,1,2,0,0]
noncomputable def fixture1Chunk419 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk420 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk421 : List (Fin 3) := [1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1]
noncomputable def fixture1Chunk422 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk423 : List (Fin 3) := [2,0,1,2,1]
noncomputable def fixture1Chunk424 : List (Fin 3) := [0,1,2,0,0]
noncomputable def fixture1Chunk425 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk426 : List (Fin 3) := [1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk427 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk428 : List (Fin 3) := [1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk429 : List (Fin 3) := [1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk430 : List (Fin 3) := [1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk431 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2]
noncomputable def fixture1Chunk432 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk433 : List (Fin 3) := [0,1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk434 : List (Fin 3) := [1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk435 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk436 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk437 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk438 : List (Fin 3) := [2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk439 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk440 : List (Fin 3) := [1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk441 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk442 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk443 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2]
noncomputable def fixture1Chunk444 : List (Fin 3) := [2,0,0,1,0,1,2]
noncomputable def fixture1Chunk445 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0]
noncomputable def fixture1Chunk446 : List (Fin 3) := [1,2,0,0,1,1,1]
noncomputable def fixture1Chunk447 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1]
noncomputable def fixture1Chunk448 : List (Fin 3) := [2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk449 : List (Fin 3) := [0,1,1]
noncomputable def fixture1Chunk450 : List (Fin 3) := [1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk451 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk452 : List (Fin 3) := [1,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk453 : List (Fin 3) := [1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk454 : List (Fin 3) := [0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk455 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1]
noncomputable def fixture1Chunk456 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk457 : List (Fin 3) := [1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk458 : List (Fin 3) := [1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk459 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk460 : List (Fin 3) := [2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk461 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1]
noncomputable def fixture1Chunk462 : List (Fin 3) := [0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk463 : List (Fin 3) := [0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk464 : List (Fin 3) := [1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk465 : List (Fin 3) := [1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk466 : List (Fin 3) := [1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk467 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk468 : List (Fin 3) := [1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk469 : List (Fin 3) := [1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk470 : List (Fin 3) := [0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk471 : List (Fin 3) := [1,1,0,1,2,0,1,2,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk472 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk473 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0]
noncomputable def fixture1Chunk474 : List (Fin 3) := [1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1]
noncomputable def fixture1Chunk475 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk476 : List (Fin 3) := [0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1]
noncomputable def fixture1Chunk477 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk478 : List (Fin 3) := [0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk479 : List (Fin 3) := [1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk480 : List (Fin 3) := [0,1,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk481 : List (Fin 3) := [2,0,1,2,1,0,1,2,0,0,1,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk482 : List (Fin 3) := [0,1,1,1,0,1,2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk483 : List (Fin 3) := [1,1,0,1,2,0,0,1,1,0,1,2,0,0]
noncomputable def fixture1Chunk484 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,1,0,1,2,0,1,2,0,1,2,1]
noncomputable def fixture1Chunk485 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk486 : List (Fin 3) := [1,2,0,0,1,1,1,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0,1,1]
noncomputable def fixture1Chunk487 : List (Fin 3) := [1,1,1,0,1,2,0,1,2,1,0,1,2,0,0,1,1,1,0,1,2,1,0,1,2]
noncomputable def fixture1Chunk488 : List (Fin 3) := [0,1,2,0,1,2,0,1,2,1,0,1,2,0,0,1,0,1,2,1,0,1,2,0,0]
noncomputable def fixture1Chunk489 : List (Fin 3) := [2,1,0,1,2,0,0,1,1,0,1,2,0]
noncomputable def fixture1Chunk490 : List (Fin 3) := [1,2,1,0,1,2,0,0,1,1,1,0,1]

noncomputable def fixture1State0 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk0].flatten, [fixture1Chunk1].flatten)
noncomputable def fixture1State1 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk1].flatten, [fixture1Chunk0].flatten)
noncomputable def fixture1State2 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk2].flatten, [fixture1Chunk3].flatten)
noncomputable def fixture1State3 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk3].flatten, [fixture1Chunk2].flatten)
noncomputable def fixture1State4 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk4].flatten, [fixture1Chunk5].flatten)
noncomputable def fixture1State5 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk5].flatten, [fixture1Chunk4].flatten)
noncomputable def fixture1State6 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk6].flatten, [fixture1Chunk7].flatten)
noncomputable def fixture1State7 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk7].flatten, [fixture1Chunk6].flatten)
noncomputable def fixture1State8 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk8].flatten, [fixture1Chunk8].flatten)
noncomputable def fixture1State9 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk9].flatten, [fixture1Chunk9].flatten)
noncomputable def fixture1State10 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk10].flatten, [fixture1Chunk11].flatten)
noncomputable def fixture1State11 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk11].flatten, [fixture1Chunk10].flatten)
noncomputable def fixture1State12 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk12].flatten, [fixture1Chunk13].flatten)
noncomputable def fixture1State13 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk13].flatten, [fixture1Chunk12].flatten)
noncomputable def fixture1State14 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk14].flatten, [fixture1Chunk15].flatten)
noncomputable def fixture1State15 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk15].flatten, [fixture1Chunk14].flatten)
noncomputable def fixture1State16 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk16].flatten, [fixture1Chunk17].flatten)
noncomputable def fixture1State17 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk17].flatten, [fixture1Chunk16].flatten)
noncomputable def fixture1State18 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk18].flatten, [fixture1Chunk19].flatten)
noncomputable def fixture1State19 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk19].flatten, [fixture1Chunk18].flatten)
noncomputable def fixture1State20 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk20].flatten, [fixture1Chunk21].flatten)
noncomputable def fixture1State21 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk21].flatten, [fixture1Chunk20].flatten)
noncomputable def fixture1State22 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk22].flatten, [fixture1Chunk23].flatten)
noncomputable def fixture1State23 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk23].flatten, [fixture1Chunk22].flatten)
noncomputable def fixture1State24 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk24].flatten, [fixture1Chunk25].flatten)
noncomputable def fixture1State25 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk25].flatten, [fixture1Chunk24].flatten)
noncomputable def fixture1State26 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk26].flatten, [fixture1Chunk27].flatten)
noncomputable def fixture1State27 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk27].flatten, [fixture1Chunk26].flatten)
noncomputable def fixture1State28 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk28].flatten, [fixture1Chunk29].flatten)
noncomputable def fixture1State29 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk29].flatten, [fixture1Chunk28].flatten)
noncomputable def fixture1State30 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk30].flatten, [fixture1Chunk31].flatten)
noncomputable def fixture1State31 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk31].flatten, [fixture1Chunk30].flatten)
noncomputable def fixture1State32 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk32].flatten, [fixture1Chunk33].flatten)
noncomputable def fixture1State33 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk33].flatten, [fixture1Chunk32].flatten)
noncomputable def fixture1State34 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk34].flatten, [fixture1Chunk35].flatten)
noncomputable def fixture1State35 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk35].flatten, [fixture1Chunk34].flatten)
noncomputable def fixture1State36 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk36].flatten, [fixture1Chunk37].flatten)
noncomputable def fixture1State37 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk37].flatten, [fixture1Chunk36].flatten)
noncomputable def fixture1State38 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk38,fixture1Chunk9].flatten, [fixture1Chunk39,fixture1Chunk40].flatten)
noncomputable def fixture1State39 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk39,fixture1Chunk40].flatten, [fixture1Chunk38,fixture1Chunk9].flatten)
noncomputable def fixture1State40 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk41].flatten, [fixture1Chunk42].flatten)
noncomputable def fixture1State41 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk42].flatten, [fixture1Chunk41].flatten)
noncomputable def fixture1State42 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk43].flatten, [fixture1Chunk44].flatten)
noncomputable def fixture1State43 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk44].flatten, [fixture1Chunk43].flatten)
noncomputable def fixture1State44 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk45].flatten, [fixture1Chunk46].flatten)
noncomputable def fixture1State45 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk46].flatten, [fixture1Chunk45].flatten)
noncomputable def fixture1State46 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk47].flatten, [fixture1Chunk48].flatten)
noncomputable def fixture1State47 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk48].flatten, [fixture1Chunk47].flatten)
noncomputable def fixture1State48 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk49].flatten, [fixture1Chunk50].flatten)
noncomputable def fixture1State49 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk50].flatten, [fixture1Chunk49].flatten)
noncomputable def fixture1State50 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk51].flatten, [fixture1Chunk52].flatten)
noncomputable def fixture1State51 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk52].flatten, [fixture1Chunk51].flatten)
noncomputable def fixture1State52 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk53].flatten, [fixture1Chunk54].flatten)
noncomputable def fixture1State53 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk54].flatten, [fixture1Chunk53].flatten)
noncomputable def fixture1State54 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk55].flatten, [fixture1Chunk56].flatten)
noncomputable def fixture1State55 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk56].flatten, [fixture1Chunk55].flatten)
noncomputable def fixture1State56 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk57].flatten, [fixture1Chunk58].flatten)
noncomputable def fixture1State57 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk58].flatten, [fixture1Chunk57].flatten)
noncomputable def fixture1State58 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk59].flatten, [fixture1Chunk60].flatten)
noncomputable def fixture1State59 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk60].flatten, [fixture1Chunk59].flatten)
noncomputable def fixture1State60 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk61].flatten, [fixture1Chunk62].flatten)
noncomputable def fixture1State61 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk62].flatten, [fixture1Chunk61].flatten)
noncomputable def fixture1State62 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk63].flatten, [fixture1Chunk64].flatten)
noncomputable def fixture1State63 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk64].flatten, [fixture1Chunk63].flatten)
noncomputable def fixture1State64 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk65].flatten, [fixture1Chunk66].flatten)
noncomputable def fixture1State65 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk66].flatten, [fixture1Chunk65].flatten)
noncomputable def fixture1State66 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk67].flatten, [fixture1Chunk68].flatten)
noncomputable def fixture1State67 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk68].flatten, [fixture1Chunk67].flatten)
noncomputable def fixture1State68 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk69].flatten, [fixture1Chunk70].flatten)
noncomputable def fixture1State69 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk70].flatten, [fixture1Chunk69].flatten)
noncomputable def fixture1State70 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk71].flatten, [fixture1Chunk72].flatten)
noncomputable def fixture1State71 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk72].flatten, [fixture1Chunk71].flatten)
noncomputable def fixture1State72 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk73].flatten, [fixture1Chunk74].flatten)
noncomputable def fixture1State73 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk74].flatten, [fixture1Chunk73].flatten)
noncomputable def fixture1State74 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk75].flatten, [fixture1Chunk76].flatten)
noncomputable def fixture1State75 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk76].flatten, [fixture1Chunk75].flatten)
noncomputable def fixture1State76 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk77].flatten, [fixture1Chunk78].flatten)
noncomputable def fixture1State77 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk78].flatten, [fixture1Chunk77].flatten)
noncomputable def fixture1State78 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk79].flatten, [fixture1Chunk80].flatten)
noncomputable def fixture1State79 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk80].flatten, [fixture1Chunk79].flatten)
noncomputable def fixture1State80 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk81].flatten, [fixture1Chunk82].flatten)
noncomputable def fixture1State81 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk82].flatten, [fixture1Chunk81].flatten)
noncomputable def fixture1State82 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk83].flatten, [fixture1Chunk84].flatten)
noncomputable def fixture1State83 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk84].flatten, [fixture1Chunk83].flatten)
noncomputable def fixture1State84 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk85].flatten, [fixture1Chunk86].flatten)
noncomputable def fixture1State85 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk86].flatten, [fixture1Chunk85].flatten)
noncomputable def fixture1State86 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk87].flatten, [fixture1Chunk88].flatten)
noncomputable def fixture1State87 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk88].flatten, [fixture1Chunk87].flatten)
noncomputable def fixture1State88 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk89].flatten, [fixture1Chunk90].flatten)
noncomputable def fixture1State89 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk90].flatten, [fixture1Chunk89].flatten)
noncomputable def fixture1State90 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk55].flatten, [fixture1Chunk91].flatten)
noncomputable def fixture1State91 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk91].flatten, [fixture1Chunk55].flatten)
noncomputable def fixture1State92 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92].flatten, [fixture1Chunk93].flatten)
noncomputable def fixture1State93 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93].flatten, [fixture1Chunk92].flatten)
noncomputable def fixture1State94 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk73].flatten, [fixture1Chunk94].flatten)
noncomputable def fixture1State95 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk94].flatten, [fixture1Chunk73].flatten)
noncomputable def fixture1State96 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk95].flatten, [fixture1Chunk96].flatten)
noncomputable def fixture1State97 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk96].flatten, [fixture1Chunk95].flatten)
noncomputable def fixture1State98 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk97,fixture1Chunk11].flatten, [fixture1Chunk98,fixture1Chunk99].flatten)
noncomputable def fixture1State99 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk98,fixture1Chunk99].flatten, [fixture1Chunk97,fixture1Chunk11].flatten)
noncomputable def fixture1State100 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk100,fixture1Chunk101].flatten, [fixture1Chunk102,fixture1Chunk103].flatten)
noncomputable def fixture1State101 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk102,fixture1Chunk103].flatten, [fixture1Chunk100,fixture1Chunk101].flatten)
noncomputable def fixture1State102 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk9].flatten, [fixture1Chunk102,fixture1Chunk8].flatten)
noncomputable def fixture1State103 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk102,fixture1Chunk8].flatten, [fixture1Chunk104,fixture1Chunk9].flatten)
noncomputable def fixture1State104 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk105].flatten, [fixture1Chunk106].flatten)
noncomputable def fixture1State105 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk106].flatten, [fixture1Chunk105].flatten)
noncomputable def fixture1State106 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk107].flatten, [fixture1Chunk108].flatten)
noncomputable def fixture1State107 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk108].flatten, [fixture1Chunk107].flatten)
noncomputable def fixture1State108 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk109,fixture1Chunk110].flatten, [fixture1Chunk111,fixture1Chunk112].flatten)
noncomputable def fixture1State109 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk112].flatten, [fixture1Chunk109,fixture1Chunk110].flatten)
noncomputable def fixture1State110 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk109,fixture1Chunk113].flatten, [fixture1Chunk111,fixture1Chunk114].flatten)
noncomputable def fixture1State111 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk114].flatten, [fixture1Chunk109,fixture1Chunk113].flatten)
noncomputable def fixture1State112 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk115].flatten, [fixture1Chunk116].flatten)
noncomputable def fixture1State113 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk116].flatten, [fixture1Chunk115].flatten)
noncomputable def fixture1State114 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk38,fixture1Chunk117,fixture1Chunk118].flatten, [fixture1Chunk119,fixture1Chunk120,fixture1Chunk121].flatten)
noncomputable def fixture1State115 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk119,fixture1Chunk120,fixture1Chunk121].flatten, [fixture1Chunk38,fixture1Chunk117,fixture1Chunk118].flatten)
noncomputable def fixture1State116 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk40].flatten, [fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk9].flatten)
noncomputable def fixture1State117 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk9].flatten, [fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk40].flatten)
noncomputable def fixture1State118 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk127].flatten, [fixture1Chunk124,fixture1Chunk128].flatten)
noncomputable def fixture1State119 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk128].flatten, [fixture1Chunk104,fixture1Chunk127].flatten)
noncomputable def fixture1State120 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk129,fixture1Chunk130].flatten, [fixture1Chunk131,fixture1Chunk132].flatten)
noncomputable def fixture1State121 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk132].flatten, [fixture1Chunk129,fixture1Chunk130].flatten)
noncomputable def fixture1State122 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk133].flatten, [fixture1Chunk134].flatten)
noncomputable def fixture1State123 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk134].flatten, [fixture1Chunk133].flatten)
noncomputable def fixture1State124 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk138].flatten, [fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk50].flatten)
noncomputable def fixture1State125 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk50].flatten, [fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk138].flatten)
noncomputable def fixture1State126 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk142].flatten, [fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk144].flatten)
noncomputable def fixture1State127 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk144].flatten, [fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk142].flatten)
noncomputable def fixture1State128 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk100,fixture1Chunk145].flatten, [fixture1Chunk102,fixture1Chunk146].flatten)
noncomputable def fixture1State129 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk102,fixture1Chunk146].flatten, [fixture1Chunk100,fixture1Chunk145].flatten)
noncomputable def fixture1State130 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk147].flatten, [fixture1Chunk148].flatten)
noncomputable def fixture1State131 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk148].flatten, [fixture1Chunk147].flatten)
noncomputable def fixture1State132 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk149,fixture1Chunk150,fixture1Chunk151].flatten, [fixture1Chunk152,fixture1Chunk153,fixture1Chunk140].flatten)
noncomputable def fixture1State133 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk153,fixture1Chunk140].flatten, [fixture1Chunk149,fixture1Chunk150,fixture1Chunk151].flatten)
noncomputable def fixture1State134 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk154].flatten, [fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk25].flatten)
noncomputable def fixture1State135 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk25].flatten, [fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk154].flatten)
noncomputable def fixture1State136 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk155].flatten, [fixture1Chunk156,fixture1Chunk157].flatten)
noncomputable def fixture1State137 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk157].flatten, [fixture1Chunk92,fixture1Chunk155].flatten)
noncomputable def fixture1State138 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk161].flatten, [fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk166].flatten)
noncomputable def fixture1State139 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk166].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk161].flatten)
noncomputable def fixture1State140 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk167].flatten, [fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk169].flatten)
noncomputable def fixture1State141 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk169].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk167].flatten)
noncomputable def fixture1State142 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk170].flatten, [fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk171].flatten)
noncomputable def fixture1State143 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk171].flatten, [fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk170].flatten)
noncomputable def fixture1State144 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk115].flatten, [fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk176].flatten)
noncomputable def fixture1State145 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk176].flatten, [fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk115].flatten)
noncomputable def fixture1State146 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk178,fixture1Chunk179].flatten, [fixture1Chunk160,fixture1Chunk93,fixture1Chunk180].flatten)
noncomputable def fixture1State147 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk160,fixture1Chunk93,fixture1Chunk180].flatten, [fixture1Chunk177,fixture1Chunk178,fixture1Chunk179].flatten)
noncomputable def fixture1State148 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk178,fixture1Chunk181].flatten, [fixture1Chunk160,fixture1Chunk93,fixture1Chunk182].flatten)
noncomputable def fixture1State149 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk160,fixture1Chunk93,fixture1Chunk182].flatten, [fixture1Chunk177,fixture1Chunk178,fixture1Chunk181].flatten)
noncomputable def fixture1State150 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk183,fixture1Chunk184].flatten, [fixture1Chunk124,fixture1Chunk128].flatten)
noncomputable def fixture1State151 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk128].flatten, [fixture1Chunk183,fixture1Chunk184].flatten)
noncomputable def fixture1State152 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk185].flatten, [fixture1Chunk186].flatten)
noncomputable def fixture1State153 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk186].flatten, [fixture1Chunk185].flatten)
noncomputable def fixture1State154 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk187].flatten, [fixture1Chunk186].flatten)
noncomputable def fixture1State155 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk186].flatten, [fixture1Chunk187].flatten)
noncomputable def fixture1State156 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk189,fixture1Chunk69].flatten, [fixture1Chunk124,fixture1Chunk190,fixture1Chunk191].flatten)
noncomputable def fixture1State157 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk190,fixture1Chunk191].flatten, [fixture1Chunk188,fixture1Chunk189,fixture1Chunk69].flatten)
noncomputable def fixture1State158 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk155].flatten, [fixture1Chunk192,fixture1Chunk157].flatten)
noncomputable def fixture1State159 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk192,fixture1Chunk157].flatten, [fixture1Chunk92,fixture1Chunk155].flatten)
noncomputable def fixture1State160 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk194].flatten, [fixture1Chunk93,fixture1Chunk195].flatten)
noncomputable def fixture1State161 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk195].flatten, [fixture1Chunk193,fixture1Chunk194].flatten)
noncomputable def fixture1State162 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk198].flatten, [fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk200].flatten)
noncomputable def fixture1State163 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk200].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk198].flatten)
noncomputable def fixture1State164 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk207].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk213].flatten)
noncomputable def fixture1State165 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk213].flatten, [fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk207].flatten)
noncomputable def fixture1State166 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk129,fixture1Chunk214].flatten, [fixture1Chunk215,fixture1Chunk216].flatten)
noncomputable def fixture1State167 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk216].flatten, [fixture1Chunk129,fixture1Chunk214].flatten)
noncomputable def fixture1State168 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk217].flatten, [fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk218].flatten)
noncomputable def fixture1State169 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk218].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk217].flatten)
noncomputable def fixture1State170 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk149,fixture1Chunk219].flatten, [fixture1Chunk111,fixture1Chunk220].flatten)
noncomputable def fixture1State171 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk220].flatten, [fixture1Chunk149,fixture1Chunk219].flatten)
noncomputable def fixture1State172 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk79].flatten, [fixture1Chunk221,fixture1Chunk222].flatten)
noncomputable def fixture1State173 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk222].flatten, [fixture1Chunk172,fixture1Chunk79].flatten)
noncomputable def fixture1State174 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk223].flatten, [fixture1Chunk224].flatten)
noncomputable def fixture1State175 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk224].flatten, [fixture1Chunk223].flatten)
noncomputable def fixture1State176 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk225].flatten, [fixture1Chunk226].flatten)
noncomputable def fixture1State177 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk226].flatten, [fixture1Chunk225].flatten)
noncomputable def fixture1State178 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk230].flatten, [fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk39,fixture1Chunk232].flatten)
noncomputable def fixture1State179 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk39,fixture1Chunk232].flatten, [fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk230].flatten)
noncomputable def fixture1State180 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk109,fixture1Chunk233].flatten, [fixture1Chunk111,fixture1Chunk112].flatten)
noncomputable def fixture1State181 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk112].flatten, [fixture1Chunk109,fixture1Chunk233].flatten)
noncomputable def fixture1State182 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk109,fixture1Chunk234,fixture1Chunk57].flatten, [fixture1Chunk235,fixture1Chunk236,fixture1Chunk237].flatten)
noncomputable def fixture1State183 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk235,fixture1Chunk236,fixture1Chunk237].flatten, [fixture1Chunk109,fixture1Chunk234,fixture1Chunk57].flatten)
noncomputable def fixture1State184 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk8].flatten, [fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk9].flatten)
noncomputable def fixture1State185 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk9].flatten, [fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk8].flatten)
noncomputable def fixture1State186 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk245].flatten, [fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk249].flatten)
noncomputable def fixture1State187 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk249].flatten, [fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk245].flatten)
noncomputable def fixture1State188 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk170].flatten, [fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk171].flatten)
noncomputable def fixture1State189 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk171].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk170].flatten)
noncomputable def fixture1State190 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk151,fixture1Chunk150,fixture1Chunk45].flatten, [fixture1Chunk139,fixture1Chunk140,fixture1Chunk250].flatten)
noncomputable def fixture1State191 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk139,fixture1Chunk140,fixture1Chunk250].flatten, [fixture1Chunk151,fixture1Chunk150,fixture1Chunk45].flatten)
noncomputable def fixture1State192 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk251].flatten, [fixture1Chunk252].flatten)
noncomputable def fixture1State193 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk252].flatten, [fixture1Chunk251].flatten)
noncomputable def fixture1State194 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk253].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk256].flatten)
noncomputable def fixture1State195 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk256].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk253].flatten)
noncomputable def fixture1State196 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk257].flatten, [fixture1Chunk131,fixture1Chunk258,fixture1Chunk259].flatten)
noncomputable def fixture1State197 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk258,fixture1Chunk259].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk257].flatten)
noncomputable def fixture1State198 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk260,fixture1Chunk209,fixture1Chunk261].flatten, [fixture1Chunk262,fixture1Chunk137,fixture1Chunk263].flatten)
noncomputable def fixture1State199 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk262,fixture1Chunk137,fixture1Chunk263].flatten, [fixture1Chunk260,fixture1Chunk209,fixture1Chunk261].flatten)
noncomputable def fixture1State200 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk264].flatten, [fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk265].flatten)
noncomputable def fixture1State201 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk265].flatten, [fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk264].flatten)
noncomputable def fixture1State202 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk266].flatten, [fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk86].flatten)
noncomputable def fixture1State203 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk86].flatten, [fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk266].flatten)
noncomputable def fixture1State204 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk129,fixture1Chunk268].flatten, [fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk270].flatten)
noncomputable def fixture1State205 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk270].flatten, [fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk129,fixture1Chunk268].flatten)
noncomputable def fixture1State206 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk275].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk10].flatten)
noncomputable def fixture1State207 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk10].flatten, [fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk275].flatten)
noncomputable def fixture1State208 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk277].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk64].flatten)
noncomputable def fixture1State209 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk64].flatten, [fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk277].flatten)
noncomputable def fixture1State210 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk279].flatten, [fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk280].flatten)
noncomputable def fixture1State211 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk280].flatten, [fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk279].flatten)
noncomputable def fixture1State212 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk129,fixture1Chunk281].flatten, [fixture1Chunk131,fixture1Chunk282].flatten)
noncomputable def fixture1State213 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk282].flatten, [fixture1Chunk129,fixture1Chunk281].flatten)
noncomputable def fixture1State214 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk285].flatten, [fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk287].flatten)
noncomputable def fixture1State215 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk287].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk285].flatten)
noncomputable def fixture1State216 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk288].flatten, [fixture1Chunk215,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk290].flatten)
noncomputable def fixture1State217 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk290].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk288].flatten)
noncomputable def fixture1State218 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk40].flatten, [fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk8].flatten)
noncomputable def fixture1State219 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk8].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk40].flatten)
noncomputable def fixture1State220 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk297].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk98,fixture1Chunk298,fixture1Chunk299,fixture1Chunk126,fixture1Chunk300].flatten)
noncomputable def fixture1State221 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk98,fixture1Chunk298,fixture1Chunk299,fixture1Chunk126,fixture1Chunk300].flatten, [fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk297].flatten)
noncomputable def fixture1State222 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk238,fixture1Chunk301].flatten, [fixture1Chunk139,fixture1Chunk140,fixture1Chunk302].flatten)
noncomputable def fixture1State223 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk139,fixture1Chunk140,fixture1Chunk302].flatten, [fixture1Chunk135,fixture1Chunk238,fixture1Chunk301].flatten)
noncomputable def fixture1State224 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk3].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk0].flatten)
noncomputable def fixture1State225 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk0].flatten, [fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk3].flatten)
noncomputable def fixture1State226 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk312,fixture1Chunk313].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk314].flatten)
noncomputable def fixture1State227 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk314].flatten, [fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk312,fixture1Chunk313].flatten)
noncomputable def fixture1State228 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk315].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk316].flatten)
noncomputable def fixture1State229 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk316].flatten, [fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk315].flatten)
noncomputable def fixture1State230 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk317].flatten, [fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk318].flatten)
noncomputable def fixture1State231 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk318].flatten, [fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk317].flatten)
noncomputable def fixture1State232 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk319].flatten, [fixture1Chunk240,fixture1Chunk246,fixture1Chunk304,fixture1Chunk305,fixture1Chunk320].flatten)
noncomputable def fixture1State233 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk240,fixture1Chunk246,fixture1Chunk304,fixture1Chunk305,fixture1Chunk320].flatten, [fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk319].flatten)
noncomputable def fixture1State234 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk321].flatten, [fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk171].flatten)
noncomputable def fixture1State235 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk171].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk321].flatten)
noncomputable def fixture1State236 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk321].flatten, [fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk171].flatten)
noncomputable def fixture1State237 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk171].flatten, [fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk321].flatten)
noncomputable def fixture1State238 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk122,fixture1Chunk322].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk324].flatten)
noncomputable def fixture1State239 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk324].flatten, [fixture1Chunk104,fixture1Chunk122,fixture1Chunk322].flatten)
noncomputable def fixture1State240 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk129,fixture1Chunk214].flatten, [fixture1Chunk162,fixture1Chunk216].flatten)
noncomputable def fixture1State241 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk162,fixture1Chunk216].flatten, [fixture1Chunk129,fixture1Chunk214].flatten)
noncomputable def fixture1State242 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk325].flatten, [fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk326].flatten)
noncomputable def fixture1State243 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk326].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk325].flatten)
noncomputable def fixture1State244 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk288].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk329].flatten)
noncomputable def fixture1State245 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk329].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk288].flatten)
noncomputable def fixture1State246 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk129,fixture1Chunk330,fixture1Chunk59].flatten, [fixture1Chunk192,fixture1Chunk208,fixture1Chunk331].flatten)
noncomputable def fixture1State247 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk192,fixture1Chunk208,fixture1Chunk331].flatten, [fixture1Chunk129,fixture1Chunk330,fixture1Chunk59].flatten)
noncomputable def fixture1State248 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk288].flatten, [fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk290].flatten)
noncomputable def fixture1State249 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk290].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk288].flatten)
noncomputable def fixture1State250 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk4].flatten, [fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk332].flatten)
noncomputable def fixture1State251 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk332].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk4].flatten)
noncomputable def fixture1State252 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk165,fixture1Chunk333].flatten, [fixture1Chunk124,fixture1Chunk125,fixture1Chunk55].flatten)
noncomputable def fixture1State253 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk125,fixture1Chunk55].flatten, [fixture1Chunk104,fixture1Chunk165,fixture1Chunk333].flatten)
noncomputable def fixture1State254 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk335].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk340].flatten)
noncomputable def fixture1State255 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk340].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk335].flatten)
noncomputable def fixture1State256 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk121].flatten, [fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk118].flatten)
noncomputable def fixture1State257 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk118].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk121].flatten)
noncomputable def fixture1State258 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk214].flatten, [fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk341].flatten)
noncomputable def fixture1State259 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk341].flatten, [fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk214].flatten)
noncomputable def fixture1State260 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk342,fixture1Chunk241,fixture1Chunk9].flatten, [fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk8].flatten)
noncomputable def fixture1State261 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk8].flatten, [fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk342,fixture1Chunk241,fixture1Chunk9].flatten)
noncomputable def fixture1State262 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk343].flatten, [fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk344].flatten)
noncomputable def fixture1State263 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk344].flatten, [fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk343].flatten)
noncomputable def fixture1State264 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk149,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk345].flatten, [fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk346].flatten)
noncomputable def fixture1State265 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk346].flatten, [fixture1Chunk149,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk345].flatten)
noncomputable def fixture1State266 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk347].flatten, [fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk348].flatten)
noncomputable def fixture1State267 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk348].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk347].flatten)
noncomputable def fixture1State268 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk109,fixture1Chunk349].flatten, [fixture1Chunk152,fixture1Chunk350].flatten)
noncomputable def fixture1State269 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk350].flatten, [fixture1Chunk109,fixture1Chunk349].flatten)
noncomputable def fixture1State270 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk317].flatten, [fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk351].flatten)
noncomputable def fixture1State271 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk351].flatten, [fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk317].flatten)
noncomputable def fixture1State272 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk109,fixture1Chunk234,fixture1Chunk187].flatten, [fixture1Chunk235,fixture1Chunk236,fixture1Chunk352].flatten)
noncomputable def fixture1State273 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk235,fixture1Chunk236,fixture1Chunk352].flatten, [fixture1Chunk109,fixture1Chunk234,fixture1Chunk187].flatten)
noncomputable def fixture1State274 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk170].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk55].flatten)
noncomputable def fixture1State275 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk55].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk170].flatten)
noncomputable def fixture1State276 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk354].flatten, [fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk355].flatten)
noncomputable def fixture1State277 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk355].flatten, [fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk354].flatten)
noncomputable def fixture1State278 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk149,fixture1Chunk150,fixture1Chunk151,fixture1Chunk214].flatten, [fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk216].flatten)
noncomputable def fixture1State279 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk216].flatten, [fixture1Chunk149,fixture1Chunk150,fixture1Chunk151,fixture1Chunk214].flatten)
noncomputable def fixture1State280 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk356].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk358].flatten)
noncomputable def fixture1State281 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk358].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk356].flatten)
noncomputable def fixture1State282 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk185].flatten, [fixture1Chunk240,fixture1Chunk338,fixture1Chunk352].flatten)
noncomputable def fixture1State283 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk240,fixture1Chunk338,fixture1Chunk352].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk185].flatten)
noncomputable def fixture1State284 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk359].flatten, [fixture1Chunk262,fixture1Chunk360].flatten)
noncomputable def fixture1State285 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk262,fixture1Chunk360].flatten, [fixture1Chunk172,fixture1Chunk359].flatten)
noncomputable def fixture1State286 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk115].flatten, [fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk176].flatten)
noncomputable def fixture1State287 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk176].flatten, [fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk115].flatten)
noncomputable def fixture1State288 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk9].flatten, [fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk8].flatten)
noncomputable def fixture1State289 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk8].flatten, [fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk9].flatten)
noncomputable def fixture1State290 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk178,fixture1Chunk164,fixture1Chunk165,fixture1Chunk361].flatten, [fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk362].flatten)
noncomputable def fixture1State291 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk362].flatten, [fixture1Chunk177,fixture1Chunk178,fixture1Chunk164,fixture1Chunk165,fixture1Chunk361].flatten)
noncomputable def fixture1State292 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk363].flatten, [fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk360].flatten)
noncomputable def fixture1State293 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk360].flatten, [fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk363].flatten)
noncomputable def fixture1State294 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk238,fixture1Chunk364].flatten, [fixture1Chunk173,fixture1Chunk174,fixture1Chunk365].flatten)
noncomputable def fixture1State295 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk173,fixture1Chunk174,fixture1Chunk365].flatten, [fixture1Chunk135,fixture1Chunk238,fixture1Chunk364].flatten)
noncomputable def fixture1State296 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk238,fixture1Chunk364].flatten, [fixture1Chunk221,fixture1Chunk231,fixture1Chunk365].flatten)
noncomputable def fixture1State297 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk231,fixture1Chunk365].flatten, [fixture1Chunk135,fixture1Chunk238,fixture1Chunk364].flatten)
noncomputable def fixture1State298 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk366].flatten, [fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk367].flatten)
noncomputable def fixture1State299 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk367].flatten, [fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk366].flatten)
noncomputable def fixture1State300 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk178,fixture1Chunk164,fixture1Chunk368].flatten, [fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk332].flatten)
noncomputable def fixture1State301 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk332].flatten, [fixture1Chunk177,fixture1Chunk178,fixture1Chunk164,fixture1Chunk368].flatten)
noncomputable def fixture1State302 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk129,fixture1Chunk352].flatten, [fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk369,fixture1Chunk370].flatten)
noncomputable def fixture1State303 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk369,fixture1Chunk370].flatten, [fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk129,fixture1Chunk352].flatten)
noncomputable def fixture1State304 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk267,fixture1Chunk371].flatten, [fixture1Chunk221,fixture1Chunk372,fixture1Chunk373].flatten)
noncomputable def fixture1State305 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk372,fixture1Chunk373].flatten, [fixture1Chunk227,fixture1Chunk267,fixture1Chunk371].flatten)
noncomputable def fixture1State306 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk242,fixture1Chunk374].flatten, [fixture1Chunk201,fixture1Chunk203,fixture1Chunk373].flatten)
noncomputable def fixture1State307 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk201,fixture1Chunk203,fixture1Chunk373].flatten, [fixture1Chunk177,fixture1Chunk242,fixture1Chunk374].flatten)
noncomputable def fixture1State308 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk151,fixture1Chunk150].flatten, [fixture1Chunk221,fixture1Chunk284].flatten)
noncomputable def fixture1State309 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk284].flatten, [fixture1Chunk151,fixture1Chunk150].flatten)
noncomputable def fixture1State310 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk136,fixture1Chunk375].flatten, [fixture1Chunk221,fixture1Chunk372,fixture1Chunk376].flatten)
noncomputable def fixture1State311 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk372,fixture1Chunk376].flatten, [fixture1Chunk135,fixture1Chunk136,fixture1Chunk375].flatten)
noncomputable def fixture1State312 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk379].flatten, [fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk380].flatten)
noncomputable def fixture1State313 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk380].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk379].flatten)
noncomputable def fixture1State314 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk228,fixture1Chunk381].flatten, [fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk382].flatten)
noncomputable def fixture1State315 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk382].flatten, [fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk228,fixture1Chunk381].flatten)
noncomputable def fixture1State316 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk303,fixture1Chunk383].flatten, [fixture1Chunk201,fixture1Chunk176].flatten)
noncomputable def fixture1State317 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk201,fixture1Chunk176].flatten, [fixture1Chunk303,fixture1Chunk383].flatten)
noncomputable def fixture1State318 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk25].flatten, [fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk246,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk154].flatten)
noncomputable def fixture1State319 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk246,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk154].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk25].flatten)
noncomputable def fixture1State320 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk387].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk389].flatten)
noncomputable def fixture1State321 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk389].flatten, [fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk387].flatten)
noncomputable def fixture1State322 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk155].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk390].flatten)
noncomputable def fixture1State323 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk390].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk155].flatten)
noncomputable def fixture1State324 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk207].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk213].flatten)
noncomputable def fixture1State325 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk213].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk207].flatten)
noncomputable def fixture1State326 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk392].flatten, [fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk39,fixture1Chunk393].flatten)
noncomputable def fixture1State327 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk39,fixture1Chunk393].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk392].flatten)
noncomputable def fixture1State328 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk333].flatten, [fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk394].flatten)
noncomputable def fixture1State329 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk394].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk333].flatten)
noncomputable def fixture1State330 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk4].flatten, [fixture1Chunk215,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk332].flatten)
noncomputable def fixture1State331 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk332].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk4].flatten)
noncomputable def fixture1State332 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk167].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk395].flatten)
noncomputable def fixture1State333 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk395].flatten, [fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk167].flatten)
noncomputable def fixture1State334 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk167].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk395].flatten)
noncomputable def fixture1State335 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk395].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk167].flatten)
noncomputable def fixture1State336 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk396].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk98,fixture1Chunk298,fixture1Chunk397].flatten)
noncomputable def fixture1State337 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk98,fixture1Chunk298,fixture1Chunk397].flatten, [fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk396].flatten)
noncomputable def fixture1State338 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk398].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk98,fixture1Chunk298,fixture1Chunk299,fixture1Chunk126,fixture1Chunk399].flatten)
noncomputable def fixture1State339 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk98,fixture1Chunk298,fixture1Chunk299,fixture1Chunk126,fixture1Chunk399].flatten, [fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk398].flatten)
noncomputable def fixture1State340 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk121].flatten, [fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk400].flatten)
noncomputable def fixture1State341 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk400].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk121].flatten)
noncomputable def fixture1State342 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk121].flatten, [fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk400].flatten)
noncomputable def fixture1State343 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk400].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk121].flatten)
noncomputable def fixture1State344 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk295,fixture1Chunk288].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk108].flatten)
noncomputable def fixture1State345 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk108].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk295,fixture1Chunk288].flatten)
noncomputable def fixture1State346 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk401].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk402].flatten)
noncomputable def fixture1State347 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk402].flatten, [fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk401].flatten)
noncomputable def fixture1State348 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk404].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk136,fixture1Chunk137,fixture1Chunk258,fixture1Chunk244,fixture1Chunk405].flatten)
noncomputable def fixture1State349 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk136,fixture1Chunk137,fixture1Chunk258,fixture1Chunk244,fixture1Chunk405].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk404].flatten)
noncomputable def fixture1State350 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk322].flatten, [fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk407].flatten)
noncomputable def fixture1State351 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk407].flatten, [fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk322].flatten)
noncomputable def fixture1State352 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk40].flatten, [fixture1Chunk215,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk8].flatten)
noncomputable def fixture1State353 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk8].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk40].flatten)
noncomputable def fixture1State354 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk16].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk410].flatten)
noncomputable def fixture1State355 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk410].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk16].flatten)
noncomputable def fixture1State356 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk411].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk48].flatten)
noncomputable def fixture1State357 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk48].flatten, [fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk411].flatten)
noncomputable def fixture1State358 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk301].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk302].flatten)
noncomputable def fixture1State359 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk302].flatten, [fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk301].flatten)
noncomputable def fixture1State360 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk260,fixture1Chunk293,fixture1Chunk413].flatten, [fixture1Chunk262,fixture1Chunk137,fixture1Chunk414].flatten)
noncomputable def fixture1State361 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk262,fixture1Chunk137,fixture1Chunk414].flatten, [fixture1Chunk260,fixture1Chunk293,fixture1Chunk413].flatten)
noncomputable def fixture1State362 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk415].flatten, [fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk416].flatten)
noncomputable def fixture1State363 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk416].flatten, [fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk415].flatten)
noncomputable def fixture1State364 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk170].flatten, [fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk171].flatten)
noncomputable def fixture1State365 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk171].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk170].flatten)
noncomputable def fixture1State366 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk417].flatten, [fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk418].flatten)
noncomputable def fixture1State367 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk418].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk417].flatten)
noncomputable def fixture1State368 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk419].flatten, [fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk249].flatten)
noncomputable def fixture1State369 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk249].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk419].flatten)
noncomputable def fixture1State370 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk100,fixture1Chunk294,fixture1Chunk187].flatten, [fixture1Chunk240,fixture1Chunk338,fixture1Chunk352].flatten)
noncomputable def fixture1State371 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk240,fixture1Chunk338,fixture1Chunk352].flatten, [fixture1Chunk100,fixture1Chunk294,fixture1Chunk187].flatten)
noncomputable def fixture1State372 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk420].flatten, [fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk422].flatten)
noncomputable def fixture1State373 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk422].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk420].flatten)
noncomputable def fixture1State374 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk165,fixture1Chunk423].flatten, [fixture1Chunk240,fixture1Chunk338,fixture1Chunk424].flatten)
noncomputable def fixture1State375 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk240,fixture1Chunk338,fixture1Chunk424].flatten, [fixture1Chunk104,fixture1Chunk165,fixture1Chunk423].flatten)
noncomputable def fixture1State376 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk425].flatten, [fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk426].flatten)
noncomputable def fixture1State377 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk426].flatten, [fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk425].flatten)
noncomputable def fixture1State378 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk129,fixture1Chunk388,fixture1Chunk427].flatten, [fixture1Chunk192,fixture1Chunk208,fixture1Chunk428].flatten)
noncomputable def fixture1State379 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk192,fixture1Chunk208,fixture1Chunk428].flatten, [fixture1Chunk129,fixture1Chunk388,fixture1Chunk427].flatten)
noncomputable def fixture1State380 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk97,fixture1Chunk4].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk368].flatten)
noncomputable def fixture1State381 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk368].flatten, [fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk97,fixture1Chunk4].flatten)
noncomputable def fixture1State382 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk430].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk324].flatten)
noncomputable def fixture1State383 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk324].flatten, [fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk430].flatten)
noncomputable def fixture1State384 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk251].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk433].flatten)
noncomputable def fixture1State385 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk433].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk251].flatten)
noncomputable def fixture1State386 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk4].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk368].flatten)
noncomputable def fixture1State387 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk368].flatten, [fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk4].flatten)
noncomputable def fixture1State388 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk434].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk435].flatten)
noncomputable def fixture1State389 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk435].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk434].flatten)
noncomputable def fixture1State390 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk423].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk424].flatten)
noncomputable def fixture1State391 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk424].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk423].flatten)
noncomputable def fixture1State392 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk207].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk61].flatten)
noncomputable def fixture1State393 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk61].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk207].flatten)
noncomputable def fixture1State394 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk246,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk436].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk437].flatten)
noncomputable def fixture1State395 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk437].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk246,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk436].flatten)
noncomputable def fixture1State396 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk155].flatten, [fixture1Chunk215,fixture1Chunk204,fixture1Chunk205,fixture1Chunk157].flatten)
noncomputable def fixture1State397 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk204,fixture1Chunk205,fixture1Chunk157].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk155].flatten)
noncomputable def fixture1State398 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk438].flatten, [fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk439].flatten)
noncomputable def fixture1State399 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk439].flatten, [fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk438].flatten)
noncomputable def fixture1State400 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk227,fixture1Chunk440].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk441].flatten)
noncomputable def fixture1State401 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk441].flatten, [fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk227,fixture1Chunk440].flatten)
noncomputable def fixture1State402 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk390].flatten, [fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk157].flatten)
noncomputable def fixture1State403 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk157].flatten, [fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk390].flatten)
noncomputable def fixture1State404 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk442].flatten, [fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk443].flatten)
noncomputable def fixture1State405 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk443].flatten, [fixture1Chunk271,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk442].flatten)
noncomputable def fixture1State406 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk444].flatten, [fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk446].flatten)
noncomputable def fixture1State407 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk446].flatten, [fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk444].flatten)
noncomputable def fixture1State408 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk370].flatten, [fixture1Chunk152,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk352].flatten)
noncomputable def fixture1State409 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk352].flatten, [fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk370].flatten)
noncomputable def fixture1State410 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk86].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk369,fixture1Chunk137,fixture1Chunk266].flatten)
noncomputable def fixture1State411 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk369,fixture1Chunk137,fixture1Chunk266].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk86].flatten)
noncomputable def fixture1State412 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk430].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk269,fixture1Chunk448].flatten)
noncomputable def fixture1State413 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk269,fixture1Chunk448].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk430].flatten)
noncomputable def fixture1State414 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk449].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk216].flatten)
noncomputable def fixture1State415 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk216].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk449].flatten)
noncomputable def fixture1State416 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk450].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk117,fixture1Chunk197,fixture1Chunk25].flatten)
noncomputable def fixture1State417 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk117,fixture1Chunk197,fixture1Chunk25].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk450].flatten)
noncomputable def fixture1State418 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk86].flatten, [fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk266].flatten)
noncomputable def fixture1State419 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk266].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk86].flatten)
noncomputable def fixture1State420 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk451].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk117,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk25].flatten)
noncomputable def fixture1State421 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk117,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk25].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk451].flatten)
noncomputable def fixture1State422 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk170].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk55].flatten)
noncomputable def fixture1State423 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk55].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk170].flatten)
noncomputable def fixture1State424 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk345].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk346].flatten)
noncomputable def fixture1State425 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk346].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk345].flatten)
noncomputable def fixture1State426 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk452].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk55].flatten)
noncomputable def fixture1State427 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk55].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk452].flatten)
noncomputable def fixture1State428 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk453].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk358].flatten)
noncomputable def fixture1State429 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk358].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk453].flatten)
noncomputable def fixture1State430 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk454].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk369,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk455,fixture1Chunk248,fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk456].flatten)
noncomputable def fixture1State431 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk369,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk455,fixture1Chunk248,fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk456].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk454].flatten)
noncomputable def fixture1State432 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk457].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk458].flatten)
noncomputable def fixture1State433 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk458].flatten, [fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk457].flatten)
noncomputable def fixture1State434 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk459].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk199,fixture1Chunk219].flatten)
noncomputable def fixture1State435 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk199,fixture1Chunk219].flatten, [fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk459].flatten)
noncomputable def fixture1State436 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk305,fixture1Chunk461,fixture1Chunk462].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk463].flatten)
noncomputable def fixture1State437 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk463].flatten, [fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk305,fixture1Chunk461,fixture1Chunk462].flatten)
noncomputable def fixture1State438 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk260,fixture1Chunk16].flatten, [fixture1Chunk312,fixture1Chunk410].flatten)
noncomputable def fixture1State439 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk410].flatten, [fixture1Chunk260,fixture1Chunk16].flatten)
noncomputable def fixture1State440 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk464].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk212,fixture1Chunk465].flatten)
noncomputable def fixture1State441 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk212,fixture1Chunk465].flatten, [fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk464].flatten)
noncomputable def fixture1State442 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk466].flatten, [fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk467].flatten)
noncomputable def fixture1State443 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk467].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk466].flatten)
noncomputable def fixture1State444 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk266].flatten, [fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk86].flatten)
noncomputable def fixture1State445 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk86].flatten, [fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk266].flatten)
noncomputable def fixture1State446 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk40].flatten, [fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk8].flatten)
noncomputable def fixture1State447 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk8].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk40].flatten)
noncomputable def fixture1State448 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk468].flatten, [fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk469].flatten)
noncomputable def fixture1State449 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk469].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk468].flatten)
noncomputable def fixture1State450 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk464].flatten, [fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk465].flatten)
noncomputable def fixture1State451 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk465].flatten, [fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk464].flatten)
noncomputable def fixture1State452 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk299,fixture1Chunk126,fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk246,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk129,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk379].flatten, [fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk129,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk380].flatten)
noncomputable def fixture1State453 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk129,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk380].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk299,fixture1Chunk126,fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk246,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk129,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk379].flatten)
noncomputable def fixture1State454 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk267].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295].flatten)
noncomputable def fixture1State455 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk267].flatten)
noncomputable def fixture1State456 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk401].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk402].flatten)
noncomputable def fixture1State457 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk402].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk401].flatten)
noncomputable def fixture1State458 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk304,fixture1Chunk305,fixture1Chunk470].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk431,fixture1Chunk461,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk238,fixture1Chunk102,fixture1Chunk154].flatten)
noncomputable def fixture1State459 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk431,fixture1Chunk461,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk238,fixture1Chunk102,fixture1Chunk154].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk165,fixture1Chunk174,fixture1Chunk175,fixture1Chunk39,fixture1Chunk299,fixture1Chunk304,fixture1Chunk305,fixture1Chunk470].flatten)
noncomputable def fixture1State460 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk471].flatten, [fixture1Chunk215,fixture1Chunk204,fixture1Chunk370].flatten)
noncomputable def fixture1State461 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk204,fixture1Chunk370].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk471].flatten)
noncomputable def fixture1State462 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk167].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk395].flatten)
noncomputable def fixture1State463 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk395].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk167].flatten)
noncomputable def fixture1State464 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk207].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk213].flatten)
noncomputable def fixture1State465 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk213].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk207].flatten)
noncomputable def fixture1State466 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk129,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk473].flatten, [fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk474].flatten)
noncomputable def fixture1State467 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk474].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk129,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk473].flatten)
noncomputable def fixture1State468 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk139,fixture1Chunk475].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk476].flatten)
noncomputable def fixture1State469 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk476].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk139,fixture1Chunk475].flatten)
noncomputable def fixture1State470 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk241].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109].flatten)
noncomputable def fixture1State471 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk342,fixture1Chunk241].flatten)
noncomputable def fixture1State472 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk325].flatten, [fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk89].flatten)
noncomputable def fixture1State473 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk215,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk303,fixture1Chunk304,fixture1Chunk305,fixture1Chunk306,fixture1Chunk307,fixture1Chunk165,fixture1Chunk269,fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk89].flatten, [fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk325].flatten)
noncomputable def fixture1State474 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk455,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk342,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk455,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk342,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk371].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk373].flatten)
noncomputable def fixture1State475 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk373].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk455,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk342,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk455,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk342,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk371].flatten)
noncomputable def fixture1State476 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk477].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk478].flatten)
noncomputable def fixture1State477 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk478].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk477].flatten)
noncomputable def fixture1State478 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk136,fixture1Chunk137,fixture1Chunk258,fixture1Chunk479].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk329].flatten)
noncomputable def fixture1State479 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk329].flatten, [fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk136,fixture1Chunk137,fixture1Chunk258,fixture1Chunk479].flatten)
noncomputable def fixture1State480 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk356].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk358].flatten)
noncomputable def fixture1State481 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk358].flatten, [fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk356].flatten)
noncomputable def fixture1State482 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk480].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk481].flatten)
noncomputable def fixture1State483 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk481].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk480].flatten)
noncomputable def fixture1State484 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk482].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk483].flatten)
noncomputable def fixture1State485 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk483].flatten, [fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk482].flatten)
noncomputable def fixture1State486 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk97,fixture1Chunk4].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk368].flatten)
noncomputable def fixture1State487 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk368].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk386,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk97,fixture1Chunk4].flatten)
noncomputable def fixture1State488 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk129,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk139,fixture1Chunk484].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk282].flatten)
noncomputable def fixture1State489 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk282].flatten, [fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk129,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk139,fixture1Chunk484].flatten)
noncomputable def fixture1State490 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk482].flatten, [fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk483].flatten)
noncomputable def fixture1State491 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk483].flatten, [fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk482].flatten)
noncomputable def fixture1State492 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk401].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk96].flatten)
noncomputable def fixture1State493 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk96].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk401].flatten)
noncomputable def fixture1State494 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk401].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk96].flatten)
noncomputable def fixture1State495 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk96].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk401].flatten)
noncomputable def fixture1State496 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk214].flatten, [fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk216].flatten)
noncomputable def fixture1State497 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk203,fixture1Chunk216].flatten, [fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk214].flatten)
noncomputable def fixture1State498 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk216].flatten, [fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk449].flatten)
noncomputable def fixture1State499 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk449].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk216].flatten)
noncomputable def fixture1State500 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk394].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk129,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk183,fixture1Chunk55].flatten)
noncomputable def fixture1State501 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk295,fixture1Chunk192,fixture1Chunk208,fixture1Chunk272,fixture1Chunk296,fixture1Chunk267,fixture1Chunk129,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk178,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk183,fixture1Chunk55].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk336,fixture1Chunk337,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk394].flatten)
noncomputable def fixture1State502 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk370].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk352].flatten)
noncomputable def fixture1State503 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk352].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk370].flatten)
noncomputable def fixture1State504 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk444].flatten, [fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk446].flatten)
noncomputable def fixture1State505 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk446].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk444].flatten)
noncomputable def fixture1State506 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk354].flatten, [fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk355].flatten)
noncomputable def fixture1State507 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk173,fixture1Chunk269,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk355].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk354].flatten)
noncomputable def fixture1State508 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk485].flatten, [fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk486].flatten)
noncomputable def fixture1State509 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk312,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk199,fixture1Chunk150,fixture1Chunk151,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk278,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk258,fixture1Chunk431,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk119,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk445,fixture1Chunk486].flatten, [fixture1Chunk172,fixture1Chunk309,fixture1Chunk227,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk337,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk117,fixture1Chunk197,fixture1Chunk391,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk208,fixture1Chunk272,fixture1Chunk206,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk160,fixture1Chunk93,fixture1Chunk295,fixture1Chunk485].flatten)
noncomputable def fixture1State510 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk487].flatten, [fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk431,fixture1Chunk461,fixture1Chunk488].flatten)
noncomputable def fixture1State511 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk124,fixture1Chunk212,fixture1Chunk240,fixture1Chunk338,fixture1Chunk330,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk447,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk431,fixture1Chunk461,fixture1Chunk488].flatten, [fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk156,fixture1Chunk208,fixture1Chunk293,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk487].flatten)
noncomputable def fixture1State512 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk354].flatten, [fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk355].flatten)
noncomputable def fixture1State513 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk355].flatten, [fixture1Chunk271,fixture1Chunk162,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk241,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk196,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk354].flatten)
noncomputable def fixture1State514 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk472,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk301].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk302].flatten)
noncomputable def fixture1State515 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk302].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk472,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk301].flatten)
noncomputable def fixture1State516 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk39,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk16].flatten, [fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk129,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk292,fixture1Chunk215,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk410].flatten)
noncomputable def fixture1State517 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk159,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk284,fixture1Chunk262,fixture1Chunk137,fixture1Chunk258,fixture1Chunk408,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk248,fixture1Chunk149,fixture1Chunk150,fixture1Chunk135,fixture1Chunk136,fixture1Chunk137,fixture1Chunk267,fixture1Chunk129,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk131,fixture1Chunk292,fixture1Chunk215,fixture1Chunk204,fixture1Chunk203,fixture1Chunk289,fixture1Chunk111,fixture1Chunk276,fixture1Chunk235,fixture1Chunk236,fixture1Chunk388,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk274,fixture1Chunk158,fixture1Chunk92,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk410].flatten, [fixture1Chunk177,fixture1Chunk242,fixture1Chunk243,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk122,fixture1Chunk140,fixture1Chunk175,fixture1Chunk137,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk104,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk141,fixture1Chunk123,fixture1Chunk98,fixture1Chunk298,fixture1Chunk460,fixture1Chunk242,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk201,fixture1Chunk203,fixture1Chunk204,fixture1Chunk205,fixture1Chunk206,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk163,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk231,fixture1Chunk175,fixture1Chunk39,fixture1Chunk98,fixture1Chunk298,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk412,fixture1Chunk386,fixture1Chunk353,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk172,fixture1Chunk309,fixture1Chunk172,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk377,fixture1Chunk201,fixture1Chunk378,fixture1Chunk258,fixture1Chunk384,fixture1Chunk353,fixture1Chunk100,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk38,fixture1Chunk117,fixture1Chunk16].flatten)
noncomputable def fixture1State518 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk472,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk289,fixture1Chunk111,fixture1Chunk489].flatten, [fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk472,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk490].flatten)
noncomputable def fixture1State519 : List (Fin 3) × List (Fin 3) :=
  ([fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk152,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk385,fixture1Chunk197,fixture1Chunk295,fixture1Chunk93,fixture1Chunk327,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk267,fixture1Chunk92,fixture1Chunk158,fixture1Chunk159,fixture1Chunk160,fixture1Chunk162,fixture1Chunk163,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk122,fixture1Chunk140,fixture1Chunk143,fixture1Chunk124,fixture1Chunk212,fixture1Chunk124,fixture1Chunk125,fixture1Chunk126,fixture1Chunk177,fixture1Chunk178,fixture1Chunk255,fixture1Chunk294,fixture1Chunk284,fixture1Chunk221,fixture1Chunk372,fixture1Chunk98,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk238,fixture1Chunk328,fixture1Chunk267,fixture1Chunk193,fixture1Chunk196,fixture1Chunk197,fixture1Chunk391,fixture1Chunk378,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk111,fixture1Chunk276,fixture1Chunk111,fixture1Chunk139,fixture1Chunk140,fixture1Chunk143,fixture1Chunk240,fixture1Chunk246,fixture1Chunk126,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk472,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk490].flatten, [fixture1Chunk193,fixture1Chunk228,fixture1Chunk334,fixture1Chunk228,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk412,fixture1Chunk305,fixture1Chunk306,fixture1Chunk305,fixture1Chunk432,fixture1Chunk188,fixture1Chunk283,fixture1Chunk231,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk244,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk472,fixture1Chunk188,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk209,fixture1Chunk211,fixture1Chunk124,fixture1Chunk212,fixture1Chunk323,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk254,fixture1Chunk164,fixture1Chunk165,fixture1Chunk168,fixture1Chunk357,fixture1Chunk124,fixture1Chunk190,fixture1Chunk286,fixture1Chunk97,fixture1Chunk197,fixture1Chunk421,fixture1Chunk248,fixture1Chunk109,fixture1Chunk472,fixture1Chunk188,fixture1Chunk189,fixture1Chunk183,fixture1Chunk238,fixture1Chunk102,fixture1Chunk239,fixture1Chunk244,fixture1Chunk429,fixture1Chunk229,fixture1Chunk201,fixture1Chunk202,fixture1Chunk308,fixture1Chunk150,fixture1Chunk260,fixture1Chunk209,fixture1Chunk210,fixture1Chunk273,fixture1Chunk274,fixture1Chunk291,fixture1Chunk131,fixture1Chunk292,fixture1Chunk131,fixture1Chunk254,fixture1Chunk255,fixture1Chunk403,fixture1Chunk152,fixture1Chunk153,fixture1Chunk140,fixture1Chunk120,fixture1Chunk244,fixture1Chunk406,fixture1Chunk408,fixture1Chunk117,fixture1Chunk409,fixture1Chunk247,fixture1Chunk248,fixture1Chunk109,fixture1Chunk234,fixture1Chunk284,fixture1Chunk312,fixture1Chunk336,fixture1Chunk310,fixture1Chunk236,fixture1Chunk311,fixture1Chunk236,fixture1Chunk330,fixture1Chunk338,fixture1Chunk339,fixture1Chunk215,fixture1Chunk289,fixture1Chunk111,fixture1Chunk489].flatten)

noncomputable def fixture1StateArray : Array (List (Fin 3) × List (Fin 3)) := #[
  fixture1State0
  ,fixture1State1
  ,fixture1State2
  ,fixture1State3
  ,fixture1State4
  ,fixture1State5
  ,fixture1State6
  ,fixture1State7
  ,fixture1State8
  ,fixture1State9
  ,fixture1State10
  ,fixture1State11
  ,fixture1State12
  ,fixture1State13
  ,fixture1State14
  ,fixture1State15
  ,fixture1State16
  ,fixture1State17
  ,fixture1State18
  ,fixture1State19
  ,fixture1State20
  ,fixture1State21
  ,fixture1State22
  ,fixture1State23
  ,fixture1State24
  ,fixture1State25
  ,fixture1State26
  ,fixture1State27
  ,fixture1State28
  ,fixture1State29
  ,fixture1State30
  ,fixture1State31
  ,fixture1State32
  ,fixture1State33
  ,fixture1State34
  ,fixture1State35
  ,fixture1State36
  ,fixture1State37
  ,fixture1State38
  ,fixture1State39
  ,fixture1State40
  ,fixture1State41
  ,fixture1State42
  ,fixture1State43
  ,fixture1State44
  ,fixture1State45
  ,fixture1State46
  ,fixture1State47
  ,fixture1State48
  ,fixture1State49
  ,fixture1State50
  ,fixture1State51
  ,fixture1State52
  ,fixture1State53
  ,fixture1State54
  ,fixture1State55
  ,fixture1State56
  ,fixture1State57
  ,fixture1State58
  ,fixture1State59
  ,fixture1State60
  ,fixture1State61
  ,fixture1State62
  ,fixture1State63
  ,fixture1State64
  ,fixture1State65
  ,fixture1State66
  ,fixture1State67
  ,fixture1State68
  ,fixture1State69
  ,fixture1State70
  ,fixture1State71
  ,fixture1State72
  ,fixture1State73
  ,fixture1State74
  ,fixture1State75
  ,fixture1State76
  ,fixture1State77
  ,fixture1State78
  ,fixture1State79
  ,fixture1State80
  ,fixture1State81
  ,fixture1State82
  ,fixture1State83
  ,fixture1State84
  ,fixture1State85
  ,fixture1State86
  ,fixture1State87
  ,fixture1State88
  ,fixture1State89
  ,fixture1State90
  ,fixture1State91
  ,fixture1State92
  ,fixture1State93
  ,fixture1State94
  ,fixture1State95
  ,fixture1State96
  ,fixture1State97
  ,fixture1State98
  ,fixture1State99
  ,fixture1State100
  ,fixture1State101
  ,fixture1State102
  ,fixture1State103
  ,fixture1State104
  ,fixture1State105
  ,fixture1State106
  ,fixture1State107
  ,fixture1State108
  ,fixture1State109
  ,fixture1State110
  ,fixture1State111
  ,fixture1State112
  ,fixture1State113
  ,fixture1State114
  ,fixture1State115
  ,fixture1State116
  ,fixture1State117
  ,fixture1State118
  ,fixture1State119
  ,fixture1State120
  ,fixture1State121
  ,fixture1State122
  ,fixture1State123
  ,fixture1State124
  ,fixture1State125
  ,fixture1State126
  ,fixture1State127
  ,fixture1State128
  ,fixture1State129
  ,fixture1State130
  ,fixture1State131
  ,fixture1State132
  ,fixture1State133
  ,fixture1State134
  ,fixture1State135
  ,fixture1State136
  ,fixture1State137
  ,fixture1State138
  ,fixture1State139
  ,fixture1State140
  ,fixture1State141
  ,fixture1State142
  ,fixture1State143
  ,fixture1State144
  ,fixture1State145
  ,fixture1State146
  ,fixture1State147
  ,fixture1State148
  ,fixture1State149
  ,fixture1State150
  ,fixture1State151
  ,fixture1State152
  ,fixture1State153
  ,fixture1State154
  ,fixture1State155
  ,fixture1State156
  ,fixture1State157
  ,fixture1State158
  ,fixture1State159
  ,fixture1State160
  ,fixture1State161
  ,fixture1State162
  ,fixture1State163
  ,fixture1State164
  ,fixture1State165
  ,fixture1State166
  ,fixture1State167
  ,fixture1State168
  ,fixture1State169
  ,fixture1State170
  ,fixture1State171
  ,fixture1State172
  ,fixture1State173
  ,fixture1State174
  ,fixture1State175
  ,fixture1State176
  ,fixture1State177
  ,fixture1State178
  ,fixture1State179
  ,fixture1State180
  ,fixture1State181
  ,fixture1State182
  ,fixture1State183
  ,fixture1State184
  ,fixture1State185
  ,fixture1State186
  ,fixture1State187
  ,fixture1State188
  ,fixture1State189
  ,fixture1State190
  ,fixture1State191
  ,fixture1State192
  ,fixture1State193
  ,fixture1State194
  ,fixture1State195
  ,fixture1State196
  ,fixture1State197
  ,fixture1State198
  ,fixture1State199
  ,fixture1State200
  ,fixture1State201
  ,fixture1State202
  ,fixture1State203
  ,fixture1State204
  ,fixture1State205
  ,fixture1State206
  ,fixture1State207
  ,fixture1State208
  ,fixture1State209
  ,fixture1State210
  ,fixture1State211
  ,fixture1State212
  ,fixture1State213
  ,fixture1State214
  ,fixture1State215
  ,fixture1State216
  ,fixture1State217
  ,fixture1State218
  ,fixture1State219
  ,fixture1State220
  ,fixture1State221
  ,fixture1State222
  ,fixture1State223
  ,fixture1State224
  ,fixture1State225
  ,fixture1State226
  ,fixture1State227
  ,fixture1State228
  ,fixture1State229
  ,fixture1State230
  ,fixture1State231
  ,fixture1State232
  ,fixture1State233
  ,fixture1State234
  ,fixture1State235
  ,fixture1State236
  ,fixture1State237
  ,fixture1State238
  ,fixture1State239
  ,fixture1State240
  ,fixture1State241
  ,fixture1State242
  ,fixture1State243
  ,fixture1State244
  ,fixture1State245
  ,fixture1State246
  ,fixture1State247
  ,fixture1State248
  ,fixture1State249
  ,fixture1State250
  ,fixture1State251
  ,fixture1State252
  ,fixture1State253
  ,fixture1State254
  ,fixture1State255
  ,fixture1State256
  ,fixture1State257
  ,fixture1State258
  ,fixture1State259
  ,fixture1State260
  ,fixture1State261
  ,fixture1State262
  ,fixture1State263
  ,fixture1State264
  ,fixture1State265
  ,fixture1State266
  ,fixture1State267
  ,fixture1State268
  ,fixture1State269
  ,fixture1State270
  ,fixture1State271
  ,fixture1State272
  ,fixture1State273
  ,fixture1State274
  ,fixture1State275
  ,fixture1State276
  ,fixture1State277
  ,fixture1State278
  ,fixture1State279
  ,fixture1State280
  ,fixture1State281
  ,fixture1State282
  ,fixture1State283
  ,fixture1State284
  ,fixture1State285
  ,fixture1State286
  ,fixture1State287
  ,fixture1State288
  ,fixture1State289
  ,fixture1State290
  ,fixture1State291
  ,fixture1State292
  ,fixture1State293
  ,fixture1State294
  ,fixture1State295
  ,fixture1State296
  ,fixture1State297
  ,fixture1State298
  ,fixture1State299
  ,fixture1State300
  ,fixture1State301
  ,fixture1State302
  ,fixture1State303
  ,fixture1State304
  ,fixture1State305
  ,fixture1State306
  ,fixture1State307
  ,fixture1State308
  ,fixture1State309
  ,fixture1State310
  ,fixture1State311
  ,fixture1State312
  ,fixture1State313
  ,fixture1State314
  ,fixture1State315
  ,fixture1State316
  ,fixture1State317
  ,fixture1State318
  ,fixture1State319
  ,fixture1State320
  ,fixture1State321
  ,fixture1State322
  ,fixture1State323
  ,fixture1State324
  ,fixture1State325
  ,fixture1State326
  ,fixture1State327
  ,fixture1State328
  ,fixture1State329
  ,fixture1State330
  ,fixture1State331
  ,fixture1State332
  ,fixture1State333
  ,fixture1State334
  ,fixture1State335
  ,fixture1State336
  ,fixture1State337
  ,fixture1State338
  ,fixture1State339
  ,fixture1State340
  ,fixture1State341
  ,fixture1State342
  ,fixture1State343
  ,fixture1State344
  ,fixture1State345
  ,fixture1State346
  ,fixture1State347
  ,fixture1State348
  ,fixture1State349
  ,fixture1State350
  ,fixture1State351
  ,fixture1State352
  ,fixture1State353
  ,fixture1State354
  ,fixture1State355
  ,fixture1State356
  ,fixture1State357
  ,fixture1State358
  ,fixture1State359
  ,fixture1State360
  ,fixture1State361
  ,fixture1State362
  ,fixture1State363
  ,fixture1State364
  ,fixture1State365
  ,fixture1State366
  ,fixture1State367
  ,fixture1State368
  ,fixture1State369
  ,fixture1State370
  ,fixture1State371
  ,fixture1State372
  ,fixture1State373
  ,fixture1State374
  ,fixture1State375
  ,fixture1State376
  ,fixture1State377
  ,fixture1State378
  ,fixture1State379
  ,fixture1State380
  ,fixture1State381
  ,fixture1State382
  ,fixture1State383
  ,fixture1State384
  ,fixture1State385
  ,fixture1State386
  ,fixture1State387
  ,fixture1State388
  ,fixture1State389
  ,fixture1State390
  ,fixture1State391
  ,fixture1State392
  ,fixture1State393
  ,fixture1State394
  ,fixture1State395
  ,fixture1State396
  ,fixture1State397
  ,fixture1State398
  ,fixture1State399
  ,fixture1State400
  ,fixture1State401
  ,fixture1State402
  ,fixture1State403
  ,fixture1State404
  ,fixture1State405
  ,fixture1State406
  ,fixture1State407
  ,fixture1State408
  ,fixture1State409
  ,fixture1State410
  ,fixture1State411
  ,fixture1State412
  ,fixture1State413
  ,fixture1State414
  ,fixture1State415
  ,fixture1State416
  ,fixture1State417
  ,fixture1State418
  ,fixture1State419
  ,fixture1State420
  ,fixture1State421
  ,fixture1State422
  ,fixture1State423
  ,fixture1State424
  ,fixture1State425
  ,fixture1State426
  ,fixture1State427
  ,fixture1State428
  ,fixture1State429
  ,fixture1State430
  ,fixture1State431
  ,fixture1State432
  ,fixture1State433
  ,fixture1State434
  ,fixture1State435
  ,fixture1State436
  ,fixture1State437
  ,fixture1State438
  ,fixture1State439
  ,fixture1State440
  ,fixture1State441
  ,fixture1State442
  ,fixture1State443
  ,fixture1State444
  ,fixture1State445
  ,fixture1State446
  ,fixture1State447
  ,fixture1State448
  ,fixture1State449
  ,fixture1State450
  ,fixture1State451
  ,fixture1State452
  ,fixture1State453
  ,fixture1State454
  ,fixture1State455
  ,fixture1State456
  ,fixture1State457
  ,fixture1State458
  ,fixture1State459
  ,fixture1State460
  ,fixture1State461
  ,fixture1State462
  ,fixture1State463
  ,fixture1State464
  ,fixture1State465
  ,fixture1State466
  ,fixture1State467
  ,fixture1State468
  ,fixture1State469
  ,fixture1State470
  ,fixture1State471
  ,fixture1State472
  ,fixture1State473
  ,fixture1State474
  ,fixture1State475
  ,fixture1State476
  ,fixture1State477
  ,fixture1State478
  ,fixture1State479
  ,fixture1State480
  ,fixture1State481
  ,fixture1State482
  ,fixture1State483
  ,fixture1State484
  ,fixture1State485
  ,fixture1State486
  ,fixture1State487
  ,fixture1State488
  ,fixture1State489
  ,fixture1State490
  ,fixture1State491
  ,fixture1State492
  ,fixture1State493
  ,fixture1State494
  ,fixture1State495
  ,fixture1State496
  ,fixture1State497
  ,fixture1State498
  ,fixture1State499
  ,fixture1State500
  ,fixture1State501
  ,fixture1State502
  ,fixture1State503
  ,fixture1State504
  ,fixture1State505
  ,fixture1State506
  ,fixture1State507
  ,fixture1State508
  ,fixture1State509
  ,fixture1State510
  ,fixture1State511
  ,fixture1State512
  ,fixture1State513
  ,fixture1State514
  ,fixture1State515
  ,fixture1State516
  ,fixture1State517
  ,fixture1State518
  ,fixture1State519
]

noncomputable def fixture1State (i : Fin 520) : List (Fin 3) × List (Fin 3) :=
  fixture1StateArray[i.val]'i.isLt

noncomputable def fixture1Index0 : Fin 520 := ⟨0, by decide⟩
noncomputable def fixture1Index1 : Fin 520 := ⟨1, by decide⟩
noncomputable def fixture1Index2 : Fin 520 := ⟨2, by decide⟩
noncomputable def fixture1Index3 : Fin 520 := ⟨3, by decide⟩
noncomputable def fixture1Index4 : Fin 520 := ⟨4, by decide⟩
noncomputable def fixture1Index5 : Fin 520 := ⟨5, by decide⟩
noncomputable def fixture1Index6 : Fin 520 := ⟨6, by decide⟩
noncomputable def fixture1Index7 : Fin 520 := ⟨7, by decide⟩
noncomputable def fixture1Index8 : Fin 520 := ⟨8, by decide⟩
noncomputable def fixture1Index9 : Fin 520 := ⟨9, by decide⟩
noncomputable def fixture1Index10 : Fin 520 := ⟨10, by decide⟩
noncomputable def fixture1Index11 : Fin 520 := ⟨11, by decide⟩
noncomputable def fixture1Index12 : Fin 520 := ⟨12, by decide⟩
noncomputable def fixture1Index13 : Fin 520 := ⟨13, by decide⟩
noncomputable def fixture1Index14 : Fin 520 := ⟨14, by decide⟩
noncomputable def fixture1Index15 : Fin 520 := ⟨15, by decide⟩
noncomputable def fixture1Index16 : Fin 520 := ⟨16, by decide⟩
noncomputable def fixture1Index17 : Fin 520 := ⟨17, by decide⟩
noncomputable def fixture1Index18 : Fin 520 := ⟨18, by decide⟩
noncomputable def fixture1Index19 : Fin 520 := ⟨19, by decide⟩
noncomputable def fixture1Index20 : Fin 520 := ⟨20, by decide⟩
noncomputable def fixture1Index21 : Fin 520 := ⟨21, by decide⟩
noncomputable def fixture1Index22 : Fin 520 := ⟨22, by decide⟩
noncomputable def fixture1Index23 : Fin 520 := ⟨23, by decide⟩
noncomputable def fixture1Index24 : Fin 520 := ⟨24, by decide⟩
noncomputable def fixture1Index25 : Fin 520 := ⟨25, by decide⟩
noncomputable def fixture1Index26 : Fin 520 := ⟨26, by decide⟩
noncomputable def fixture1Index27 : Fin 520 := ⟨27, by decide⟩
noncomputable def fixture1Index28 : Fin 520 := ⟨28, by decide⟩
noncomputable def fixture1Index29 : Fin 520 := ⟨29, by decide⟩
noncomputable def fixture1Index30 : Fin 520 := ⟨30, by decide⟩
noncomputable def fixture1Index31 : Fin 520 := ⟨31, by decide⟩
noncomputable def fixture1Index32 : Fin 520 := ⟨32, by decide⟩
noncomputable def fixture1Index33 : Fin 520 := ⟨33, by decide⟩
noncomputable def fixture1Index34 : Fin 520 := ⟨34, by decide⟩
noncomputable def fixture1Index35 : Fin 520 := ⟨35, by decide⟩
noncomputable def fixture1Index36 : Fin 520 := ⟨36, by decide⟩
noncomputable def fixture1Index37 : Fin 520 := ⟨37, by decide⟩
noncomputable def fixture1Index38 : Fin 520 := ⟨38, by decide⟩
noncomputable def fixture1Index39 : Fin 520 := ⟨39, by decide⟩
noncomputable def fixture1Index40 : Fin 520 := ⟨40, by decide⟩
noncomputable def fixture1Index41 : Fin 520 := ⟨41, by decide⟩
noncomputable def fixture1Index42 : Fin 520 := ⟨42, by decide⟩
noncomputable def fixture1Index43 : Fin 520 := ⟨43, by decide⟩
noncomputable def fixture1Index44 : Fin 520 := ⟨44, by decide⟩
noncomputable def fixture1Index45 : Fin 520 := ⟨45, by decide⟩
noncomputable def fixture1Index46 : Fin 520 := ⟨46, by decide⟩
noncomputable def fixture1Index47 : Fin 520 := ⟨47, by decide⟩
noncomputable def fixture1Index48 : Fin 520 := ⟨48, by decide⟩
noncomputable def fixture1Index49 : Fin 520 := ⟨49, by decide⟩
noncomputable def fixture1Index50 : Fin 520 := ⟨50, by decide⟩
noncomputable def fixture1Index51 : Fin 520 := ⟨51, by decide⟩
noncomputable def fixture1Index52 : Fin 520 := ⟨52, by decide⟩
noncomputable def fixture1Index53 : Fin 520 := ⟨53, by decide⟩
noncomputable def fixture1Index54 : Fin 520 := ⟨54, by decide⟩
noncomputable def fixture1Index55 : Fin 520 := ⟨55, by decide⟩
noncomputable def fixture1Index56 : Fin 520 := ⟨56, by decide⟩
noncomputable def fixture1Index57 : Fin 520 := ⟨57, by decide⟩
noncomputable def fixture1Index58 : Fin 520 := ⟨58, by decide⟩
noncomputable def fixture1Index59 : Fin 520 := ⟨59, by decide⟩
noncomputable def fixture1Index60 : Fin 520 := ⟨60, by decide⟩
noncomputable def fixture1Index61 : Fin 520 := ⟨61, by decide⟩
noncomputable def fixture1Index62 : Fin 520 := ⟨62, by decide⟩
noncomputable def fixture1Index63 : Fin 520 := ⟨63, by decide⟩
noncomputable def fixture1Index64 : Fin 520 := ⟨64, by decide⟩
noncomputable def fixture1Index65 : Fin 520 := ⟨65, by decide⟩
noncomputable def fixture1Index66 : Fin 520 := ⟨66, by decide⟩
noncomputable def fixture1Index67 : Fin 520 := ⟨67, by decide⟩
noncomputable def fixture1Index68 : Fin 520 := ⟨68, by decide⟩
noncomputable def fixture1Index69 : Fin 520 := ⟨69, by decide⟩
noncomputable def fixture1Index70 : Fin 520 := ⟨70, by decide⟩
noncomputable def fixture1Index71 : Fin 520 := ⟨71, by decide⟩
noncomputable def fixture1Index72 : Fin 520 := ⟨72, by decide⟩
noncomputable def fixture1Index73 : Fin 520 := ⟨73, by decide⟩
noncomputable def fixture1Index74 : Fin 520 := ⟨74, by decide⟩
noncomputable def fixture1Index75 : Fin 520 := ⟨75, by decide⟩
noncomputable def fixture1Index76 : Fin 520 := ⟨76, by decide⟩
noncomputable def fixture1Index77 : Fin 520 := ⟨77, by decide⟩
noncomputable def fixture1Index78 : Fin 520 := ⟨78, by decide⟩
noncomputable def fixture1Index79 : Fin 520 := ⟨79, by decide⟩
noncomputable def fixture1Index80 : Fin 520 := ⟨80, by decide⟩
noncomputable def fixture1Index81 : Fin 520 := ⟨81, by decide⟩
noncomputable def fixture1Index82 : Fin 520 := ⟨82, by decide⟩
noncomputable def fixture1Index83 : Fin 520 := ⟨83, by decide⟩
noncomputable def fixture1Index84 : Fin 520 := ⟨84, by decide⟩
noncomputable def fixture1Index85 : Fin 520 := ⟨85, by decide⟩
noncomputable def fixture1Index86 : Fin 520 := ⟨86, by decide⟩
noncomputable def fixture1Index87 : Fin 520 := ⟨87, by decide⟩
noncomputable def fixture1Index88 : Fin 520 := ⟨88, by decide⟩
noncomputable def fixture1Index89 : Fin 520 := ⟨89, by decide⟩
noncomputable def fixture1Index90 : Fin 520 := ⟨90, by decide⟩
noncomputable def fixture1Index91 : Fin 520 := ⟨91, by decide⟩
noncomputable def fixture1Index92 : Fin 520 := ⟨92, by decide⟩
noncomputable def fixture1Index93 : Fin 520 := ⟨93, by decide⟩
noncomputable def fixture1Index94 : Fin 520 := ⟨94, by decide⟩
noncomputable def fixture1Index95 : Fin 520 := ⟨95, by decide⟩
noncomputable def fixture1Index96 : Fin 520 := ⟨96, by decide⟩
noncomputable def fixture1Index97 : Fin 520 := ⟨97, by decide⟩
noncomputable def fixture1Index98 : Fin 520 := ⟨98, by decide⟩
noncomputable def fixture1Index99 : Fin 520 := ⟨99, by decide⟩
noncomputable def fixture1Index100 : Fin 520 := ⟨100, by decide⟩
noncomputable def fixture1Index101 : Fin 520 := ⟨101, by decide⟩
noncomputable def fixture1Index102 : Fin 520 := ⟨102, by decide⟩
noncomputable def fixture1Index103 : Fin 520 := ⟨103, by decide⟩
noncomputable def fixture1Index104 : Fin 520 := ⟨104, by decide⟩
noncomputable def fixture1Index105 : Fin 520 := ⟨105, by decide⟩
noncomputable def fixture1Index106 : Fin 520 := ⟨106, by decide⟩
noncomputable def fixture1Index107 : Fin 520 := ⟨107, by decide⟩
noncomputable def fixture1Index108 : Fin 520 := ⟨108, by decide⟩
noncomputable def fixture1Index109 : Fin 520 := ⟨109, by decide⟩
noncomputable def fixture1Index110 : Fin 520 := ⟨110, by decide⟩
noncomputable def fixture1Index111 : Fin 520 := ⟨111, by decide⟩
noncomputable def fixture1Index112 : Fin 520 := ⟨112, by decide⟩
noncomputable def fixture1Index113 : Fin 520 := ⟨113, by decide⟩
noncomputable def fixture1Index114 : Fin 520 := ⟨114, by decide⟩
noncomputable def fixture1Index115 : Fin 520 := ⟨115, by decide⟩
noncomputable def fixture1Index116 : Fin 520 := ⟨116, by decide⟩
noncomputable def fixture1Index117 : Fin 520 := ⟨117, by decide⟩
noncomputable def fixture1Index118 : Fin 520 := ⟨118, by decide⟩
noncomputable def fixture1Index119 : Fin 520 := ⟨119, by decide⟩
noncomputable def fixture1Index120 : Fin 520 := ⟨120, by decide⟩
noncomputable def fixture1Index121 : Fin 520 := ⟨121, by decide⟩
noncomputable def fixture1Index122 : Fin 520 := ⟨122, by decide⟩
noncomputable def fixture1Index123 : Fin 520 := ⟨123, by decide⟩
noncomputable def fixture1Index124 : Fin 520 := ⟨124, by decide⟩
noncomputable def fixture1Index125 : Fin 520 := ⟨125, by decide⟩
noncomputable def fixture1Index126 : Fin 520 := ⟨126, by decide⟩
noncomputable def fixture1Index127 : Fin 520 := ⟨127, by decide⟩
noncomputable def fixture1Index128 : Fin 520 := ⟨128, by decide⟩
noncomputable def fixture1Index129 : Fin 520 := ⟨129, by decide⟩
noncomputable def fixture1Index130 : Fin 520 := ⟨130, by decide⟩
noncomputable def fixture1Index131 : Fin 520 := ⟨131, by decide⟩
noncomputable def fixture1Index132 : Fin 520 := ⟨132, by decide⟩
noncomputable def fixture1Index133 : Fin 520 := ⟨133, by decide⟩
noncomputable def fixture1Index134 : Fin 520 := ⟨134, by decide⟩
noncomputable def fixture1Index135 : Fin 520 := ⟨135, by decide⟩
noncomputable def fixture1Index136 : Fin 520 := ⟨136, by decide⟩
noncomputable def fixture1Index137 : Fin 520 := ⟨137, by decide⟩
noncomputable def fixture1Index138 : Fin 520 := ⟨138, by decide⟩
noncomputable def fixture1Index139 : Fin 520 := ⟨139, by decide⟩
noncomputable def fixture1Index140 : Fin 520 := ⟨140, by decide⟩
noncomputable def fixture1Index141 : Fin 520 := ⟨141, by decide⟩
noncomputable def fixture1Index142 : Fin 520 := ⟨142, by decide⟩
noncomputable def fixture1Index143 : Fin 520 := ⟨143, by decide⟩
noncomputable def fixture1Index144 : Fin 520 := ⟨144, by decide⟩
noncomputable def fixture1Index145 : Fin 520 := ⟨145, by decide⟩
noncomputable def fixture1Index146 : Fin 520 := ⟨146, by decide⟩
noncomputable def fixture1Index147 : Fin 520 := ⟨147, by decide⟩
noncomputable def fixture1Index148 : Fin 520 := ⟨148, by decide⟩
noncomputable def fixture1Index149 : Fin 520 := ⟨149, by decide⟩
noncomputable def fixture1Index150 : Fin 520 := ⟨150, by decide⟩
noncomputable def fixture1Index151 : Fin 520 := ⟨151, by decide⟩
noncomputable def fixture1Index152 : Fin 520 := ⟨152, by decide⟩
noncomputable def fixture1Index153 : Fin 520 := ⟨153, by decide⟩
noncomputable def fixture1Index154 : Fin 520 := ⟨154, by decide⟩
noncomputable def fixture1Index155 : Fin 520 := ⟨155, by decide⟩
noncomputable def fixture1Index156 : Fin 520 := ⟨156, by decide⟩
noncomputable def fixture1Index157 : Fin 520 := ⟨157, by decide⟩
noncomputable def fixture1Index158 : Fin 520 := ⟨158, by decide⟩
noncomputable def fixture1Index159 : Fin 520 := ⟨159, by decide⟩
noncomputable def fixture1Index160 : Fin 520 := ⟨160, by decide⟩
noncomputable def fixture1Index161 : Fin 520 := ⟨161, by decide⟩
noncomputable def fixture1Index162 : Fin 520 := ⟨162, by decide⟩
noncomputable def fixture1Index163 : Fin 520 := ⟨163, by decide⟩
noncomputable def fixture1Index164 : Fin 520 := ⟨164, by decide⟩
noncomputable def fixture1Index165 : Fin 520 := ⟨165, by decide⟩
noncomputable def fixture1Index166 : Fin 520 := ⟨166, by decide⟩
noncomputable def fixture1Index167 : Fin 520 := ⟨167, by decide⟩
noncomputable def fixture1Index168 : Fin 520 := ⟨168, by decide⟩
noncomputable def fixture1Index169 : Fin 520 := ⟨169, by decide⟩
noncomputable def fixture1Index170 : Fin 520 := ⟨170, by decide⟩
noncomputable def fixture1Index171 : Fin 520 := ⟨171, by decide⟩
noncomputable def fixture1Index172 : Fin 520 := ⟨172, by decide⟩
noncomputable def fixture1Index173 : Fin 520 := ⟨173, by decide⟩
noncomputable def fixture1Index174 : Fin 520 := ⟨174, by decide⟩
noncomputable def fixture1Index175 : Fin 520 := ⟨175, by decide⟩
noncomputable def fixture1Index176 : Fin 520 := ⟨176, by decide⟩
noncomputable def fixture1Index177 : Fin 520 := ⟨177, by decide⟩
noncomputable def fixture1Index178 : Fin 520 := ⟨178, by decide⟩
noncomputable def fixture1Index179 : Fin 520 := ⟨179, by decide⟩
noncomputable def fixture1Index180 : Fin 520 := ⟨180, by decide⟩
noncomputable def fixture1Index181 : Fin 520 := ⟨181, by decide⟩
noncomputable def fixture1Index182 : Fin 520 := ⟨182, by decide⟩
noncomputable def fixture1Index183 : Fin 520 := ⟨183, by decide⟩
noncomputable def fixture1Index184 : Fin 520 := ⟨184, by decide⟩
noncomputable def fixture1Index185 : Fin 520 := ⟨185, by decide⟩
noncomputable def fixture1Index186 : Fin 520 := ⟨186, by decide⟩
noncomputable def fixture1Index187 : Fin 520 := ⟨187, by decide⟩
noncomputable def fixture1Index188 : Fin 520 := ⟨188, by decide⟩
noncomputable def fixture1Index189 : Fin 520 := ⟨189, by decide⟩
noncomputable def fixture1Index190 : Fin 520 := ⟨190, by decide⟩
noncomputable def fixture1Index191 : Fin 520 := ⟨191, by decide⟩
noncomputable def fixture1Index192 : Fin 520 := ⟨192, by decide⟩
noncomputable def fixture1Index193 : Fin 520 := ⟨193, by decide⟩
noncomputable def fixture1Index194 : Fin 520 := ⟨194, by decide⟩
noncomputable def fixture1Index195 : Fin 520 := ⟨195, by decide⟩
noncomputable def fixture1Index196 : Fin 520 := ⟨196, by decide⟩
noncomputable def fixture1Index197 : Fin 520 := ⟨197, by decide⟩
noncomputable def fixture1Index198 : Fin 520 := ⟨198, by decide⟩
noncomputable def fixture1Index199 : Fin 520 := ⟨199, by decide⟩
noncomputable def fixture1Index200 : Fin 520 := ⟨200, by decide⟩
noncomputable def fixture1Index201 : Fin 520 := ⟨201, by decide⟩
noncomputable def fixture1Index202 : Fin 520 := ⟨202, by decide⟩
noncomputable def fixture1Index203 : Fin 520 := ⟨203, by decide⟩
noncomputable def fixture1Index204 : Fin 520 := ⟨204, by decide⟩
noncomputable def fixture1Index205 : Fin 520 := ⟨205, by decide⟩
noncomputable def fixture1Index206 : Fin 520 := ⟨206, by decide⟩
noncomputable def fixture1Index207 : Fin 520 := ⟨207, by decide⟩
noncomputable def fixture1Index208 : Fin 520 := ⟨208, by decide⟩
noncomputable def fixture1Index209 : Fin 520 := ⟨209, by decide⟩
noncomputable def fixture1Index210 : Fin 520 := ⟨210, by decide⟩
noncomputable def fixture1Index211 : Fin 520 := ⟨211, by decide⟩
noncomputable def fixture1Index212 : Fin 520 := ⟨212, by decide⟩
noncomputable def fixture1Index213 : Fin 520 := ⟨213, by decide⟩
noncomputable def fixture1Index214 : Fin 520 := ⟨214, by decide⟩
noncomputable def fixture1Index215 : Fin 520 := ⟨215, by decide⟩
noncomputable def fixture1Index216 : Fin 520 := ⟨216, by decide⟩
noncomputable def fixture1Index217 : Fin 520 := ⟨217, by decide⟩
noncomputable def fixture1Index218 : Fin 520 := ⟨218, by decide⟩
noncomputable def fixture1Index219 : Fin 520 := ⟨219, by decide⟩
noncomputable def fixture1Index220 : Fin 520 := ⟨220, by decide⟩
noncomputable def fixture1Index221 : Fin 520 := ⟨221, by decide⟩
noncomputable def fixture1Index222 : Fin 520 := ⟨222, by decide⟩
noncomputable def fixture1Index223 : Fin 520 := ⟨223, by decide⟩
noncomputable def fixture1Index224 : Fin 520 := ⟨224, by decide⟩
noncomputable def fixture1Index225 : Fin 520 := ⟨225, by decide⟩
noncomputable def fixture1Index226 : Fin 520 := ⟨226, by decide⟩
noncomputable def fixture1Index227 : Fin 520 := ⟨227, by decide⟩
noncomputable def fixture1Index228 : Fin 520 := ⟨228, by decide⟩
noncomputable def fixture1Index229 : Fin 520 := ⟨229, by decide⟩
noncomputable def fixture1Index230 : Fin 520 := ⟨230, by decide⟩
noncomputable def fixture1Index231 : Fin 520 := ⟨231, by decide⟩
noncomputable def fixture1Index232 : Fin 520 := ⟨232, by decide⟩
noncomputable def fixture1Index233 : Fin 520 := ⟨233, by decide⟩
noncomputable def fixture1Index234 : Fin 520 := ⟨234, by decide⟩
noncomputable def fixture1Index235 : Fin 520 := ⟨235, by decide⟩
noncomputable def fixture1Index236 : Fin 520 := ⟨236, by decide⟩
noncomputable def fixture1Index237 : Fin 520 := ⟨237, by decide⟩
noncomputable def fixture1Index238 : Fin 520 := ⟨238, by decide⟩
noncomputable def fixture1Index239 : Fin 520 := ⟨239, by decide⟩
noncomputable def fixture1Index240 : Fin 520 := ⟨240, by decide⟩
noncomputable def fixture1Index241 : Fin 520 := ⟨241, by decide⟩
noncomputable def fixture1Index242 : Fin 520 := ⟨242, by decide⟩
noncomputable def fixture1Index243 : Fin 520 := ⟨243, by decide⟩
noncomputable def fixture1Index244 : Fin 520 := ⟨244, by decide⟩
noncomputable def fixture1Index245 : Fin 520 := ⟨245, by decide⟩
noncomputable def fixture1Index246 : Fin 520 := ⟨246, by decide⟩
noncomputable def fixture1Index247 : Fin 520 := ⟨247, by decide⟩
noncomputable def fixture1Index248 : Fin 520 := ⟨248, by decide⟩
noncomputable def fixture1Index249 : Fin 520 := ⟨249, by decide⟩
noncomputable def fixture1Index250 : Fin 520 := ⟨250, by decide⟩
noncomputable def fixture1Index251 : Fin 520 := ⟨251, by decide⟩
noncomputable def fixture1Index252 : Fin 520 := ⟨252, by decide⟩
noncomputable def fixture1Index253 : Fin 520 := ⟨253, by decide⟩
noncomputable def fixture1Index254 : Fin 520 := ⟨254, by decide⟩
noncomputable def fixture1Index255 : Fin 520 := ⟨255, by decide⟩
noncomputable def fixture1Index256 : Fin 520 := ⟨256, by decide⟩
noncomputable def fixture1Index257 : Fin 520 := ⟨257, by decide⟩
noncomputable def fixture1Index258 : Fin 520 := ⟨258, by decide⟩
noncomputable def fixture1Index259 : Fin 520 := ⟨259, by decide⟩
noncomputable def fixture1Index260 : Fin 520 := ⟨260, by decide⟩
noncomputable def fixture1Index261 : Fin 520 := ⟨261, by decide⟩
noncomputable def fixture1Index262 : Fin 520 := ⟨262, by decide⟩
noncomputable def fixture1Index263 : Fin 520 := ⟨263, by decide⟩
noncomputable def fixture1Index264 : Fin 520 := ⟨264, by decide⟩
noncomputable def fixture1Index265 : Fin 520 := ⟨265, by decide⟩
noncomputable def fixture1Index266 : Fin 520 := ⟨266, by decide⟩
noncomputable def fixture1Index267 : Fin 520 := ⟨267, by decide⟩
noncomputable def fixture1Index268 : Fin 520 := ⟨268, by decide⟩
noncomputable def fixture1Index269 : Fin 520 := ⟨269, by decide⟩
noncomputable def fixture1Index270 : Fin 520 := ⟨270, by decide⟩
noncomputable def fixture1Index271 : Fin 520 := ⟨271, by decide⟩
noncomputable def fixture1Index272 : Fin 520 := ⟨272, by decide⟩
noncomputable def fixture1Index273 : Fin 520 := ⟨273, by decide⟩
noncomputable def fixture1Index274 : Fin 520 := ⟨274, by decide⟩
noncomputable def fixture1Index275 : Fin 520 := ⟨275, by decide⟩
noncomputable def fixture1Index276 : Fin 520 := ⟨276, by decide⟩
noncomputable def fixture1Index277 : Fin 520 := ⟨277, by decide⟩
noncomputable def fixture1Index278 : Fin 520 := ⟨278, by decide⟩
noncomputable def fixture1Index279 : Fin 520 := ⟨279, by decide⟩
noncomputable def fixture1Index280 : Fin 520 := ⟨280, by decide⟩
noncomputable def fixture1Index281 : Fin 520 := ⟨281, by decide⟩
noncomputable def fixture1Index282 : Fin 520 := ⟨282, by decide⟩
noncomputable def fixture1Index283 : Fin 520 := ⟨283, by decide⟩
noncomputable def fixture1Index284 : Fin 520 := ⟨284, by decide⟩
noncomputable def fixture1Index285 : Fin 520 := ⟨285, by decide⟩
noncomputable def fixture1Index286 : Fin 520 := ⟨286, by decide⟩
noncomputable def fixture1Index287 : Fin 520 := ⟨287, by decide⟩
noncomputable def fixture1Index288 : Fin 520 := ⟨288, by decide⟩
noncomputable def fixture1Index289 : Fin 520 := ⟨289, by decide⟩
noncomputable def fixture1Index290 : Fin 520 := ⟨290, by decide⟩
noncomputable def fixture1Index291 : Fin 520 := ⟨291, by decide⟩
noncomputable def fixture1Index292 : Fin 520 := ⟨292, by decide⟩
noncomputable def fixture1Index293 : Fin 520 := ⟨293, by decide⟩
noncomputable def fixture1Index294 : Fin 520 := ⟨294, by decide⟩
noncomputable def fixture1Index295 : Fin 520 := ⟨295, by decide⟩
noncomputable def fixture1Index296 : Fin 520 := ⟨296, by decide⟩
noncomputable def fixture1Index297 : Fin 520 := ⟨297, by decide⟩
noncomputable def fixture1Index298 : Fin 520 := ⟨298, by decide⟩
noncomputable def fixture1Index299 : Fin 520 := ⟨299, by decide⟩
noncomputable def fixture1Index300 : Fin 520 := ⟨300, by decide⟩
noncomputable def fixture1Index301 : Fin 520 := ⟨301, by decide⟩
noncomputable def fixture1Index302 : Fin 520 := ⟨302, by decide⟩
noncomputable def fixture1Index303 : Fin 520 := ⟨303, by decide⟩
noncomputable def fixture1Index304 : Fin 520 := ⟨304, by decide⟩
noncomputable def fixture1Index305 : Fin 520 := ⟨305, by decide⟩
noncomputable def fixture1Index306 : Fin 520 := ⟨306, by decide⟩
noncomputable def fixture1Index307 : Fin 520 := ⟨307, by decide⟩
noncomputable def fixture1Index308 : Fin 520 := ⟨308, by decide⟩
noncomputable def fixture1Index309 : Fin 520 := ⟨309, by decide⟩
noncomputable def fixture1Index310 : Fin 520 := ⟨310, by decide⟩
noncomputable def fixture1Index311 : Fin 520 := ⟨311, by decide⟩
noncomputable def fixture1Index312 : Fin 520 := ⟨312, by decide⟩
noncomputable def fixture1Index313 : Fin 520 := ⟨313, by decide⟩
noncomputable def fixture1Index314 : Fin 520 := ⟨314, by decide⟩
noncomputable def fixture1Index315 : Fin 520 := ⟨315, by decide⟩
noncomputable def fixture1Index316 : Fin 520 := ⟨316, by decide⟩
noncomputable def fixture1Index317 : Fin 520 := ⟨317, by decide⟩
noncomputable def fixture1Index318 : Fin 520 := ⟨318, by decide⟩
noncomputable def fixture1Index319 : Fin 520 := ⟨319, by decide⟩
noncomputable def fixture1Index320 : Fin 520 := ⟨320, by decide⟩
noncomputable def fixture1Index321 : Fin 520 := ⟨321, by decide⟩
noncomputable def fixture1Index322 : Fin 520 := ⟨322, by decide⟩
noncomputable def fixture1Index323 : Fin 520 := ⟨323, by decide⟩
noncomputable def fixture1Index324 : Fin 520 := ⟨324, by decide⟩
noncomputable def fixture1Index325 : Fin 520 := ⟨325, by decide⟩
noncomputable def fixture1Index326 : Fin 520 := ⟨326, by decide⟩
noncomputable def fixture1Index327 : Fin 520 := ⟨327, by decide⟩
noncomputable def fixture1Index328 : Fin 520 := ⟨328, by decide⟩
noncomputable def fixture1Index329 : Fin 520 := ⟨329, by decide⟩
noncomputable def fixture1Index330 : Fin 520 := ⟨330, by decide⟩
noncomputable def fixture1Index331 : Fin 520 := ⟨331, by decide⟩
noncomputable def fixture1Index332 : Fin 520 := ⟨332, by decide⟩
noncomputable def fixture1Index333 : Fin 520 := ⟨333, by decide⟩
noncomputable def fixture1Index334 : Fin 520 := ⟨334, by decide⟩
noncomputable def fixture1Index335 : Fin 520 := ⟨335, by decide⟩
noncomputable def fixture1Index336 : Fin 520 := ⟨336, by decide⟩
noncomputable def fixture1Index337 : Fin 520 := ⟨337, by decide⟩
noncomputable def fixture1Index338 : Fin 520 := ⟨338, by decide⟩
noncomputable def fixture1Index339 : Fin 520 := ⟨339, by decide⟩
noncomputable def fixture1Index340 : Fin 520 := ⟨340, by decide⟩
noncomputable def fixture1Index341 : Fin 520 := ⟨341, by decide⟩
noncomputable def fixture1Index342 : Fin 520 := ⟨342, by decide⟩
noncomputable def fixture1Index343 : Fin 520 := ⟨343, by decide⟩
noncomputable def fixture1Index344 : Fin 520 := ⟨344, by decide⟩
noncomputable def fixture1Index345 : Fin 520 := ⟨345, by decide⟩
noncomputable def fixture1Index346 : Fin 520 := ⟨346, by decide⟩
noncomputable def fixture1Index347 : Fin 520 := ⟨347, by decide⟩
noncomputable def fixture1Index348 : Fin 520 := ⟨348, by decide⟩
noncomputable def fixture1Index349 : Fin 520 := ⟨349, by decide⟩
noncomputable def fixture1Index350 : Fin 520 := ⟨350, by decide⟩
noncomputable def fixture1Index351 : Fin 520 := ⟨351, by decide⟩
noncomputable def fixture1Index352 : Fin 520 := ⟨352, by decide⟩
noncomputable def fixture1Index353 : Fin 520 := ⟨353, by decide⟩
noncomputable def fixture1Index354 : Fin 520 := ⟨354, by decide⟩
noncomputable def fixture1Index355 : Fin 520 := ⟨355, by decide⟩
noncomputable def fixture1Index356 : Fin 520 := ⟨356, by decide⟩
noncomputable def fixture1Index357 : Fin 520 := ⟨357, by decide⟩
noncomputable def fixture1Index358 : Fin 520 := ⟨358, by decide⟩
noncomputable def fixture1Index359 : Fin 520 := ⟨359, by decide⟩
noncomputable def fixture1Index360 : Fin 520 := ⟨360, by decide⟩
noncomputable def fixture1Index361 : Fin 520 := ⟨361, by decide⟩
noncomputable def fixture1Index362 : Fin 520 := ⟨362, by decide⟩
noncomputable def fixture1Index363 : Fin 520 := ⟨363, by decide⟩
noncomputable def fixture1Index364 : Fin 520 := ⟨364, by decide⟩
noncomputable def fixture1Index365 : Fin 520 := ⟨365, by decide⟩
noncomputable def fixture1Index366 : Fin 520 := ⟨366, by decide⟩
noncomputable def fixture1Index367 : Fin 520 := ⟨367, by decide⟩
noncomputable def fixture1Index368 : Fin 520 := ⟨368, by decide⟩
noncomputable def fixture1Index369 : Fin 520 := ⟨369, by decide⟩
noncomputable def fixture1Index370 : Fin 520 := ⟨370, by decide⟩
noncomputable def fixture1Index371 : Fin 520 := ⟨371, by decide⟩
noncomputable def fixture1Index372 : Fin 520 := ⟨372, by decide⟩
noncomputable def fixture1Index373 : Fin 520 := ⟨373, by decide⟩
noncomputable def fixture1Index374 : Fin 520 := ⟨374, by decide⟩
noncomputable def fixture1Index375 : Fin 520 := ⟨375, by decide⟩
noncomputable def fixture1Index376 : Fin 520 := ⟨376, by decide⟩
noncomputable def fixture1Index377 : Fin 520 := ⟨377, by decide⟩
noncomputable def fixture1Index378 : Fin 520 := ⟨378, by decide⟩
noncomputable def fixture1Index379 : Fin 520 := ⟨379, by decide⟩
noncomputable def fixture1Index380 : Fin 520 := ⟨380, by decide⟩
noncomputable def fixture1Index381 : Fin 520 := ⟨381, by decide⟩
noncomputable def fixture1Index382 : Fin 520 := ⟨382, by decide⟩
noncomputable def fixture1Index383 : Fin 520 := ⟨383, by decide⟩
noncomputable def fixture1Index384 : Fin 520 := ⟨384, by decide⟩
noncomputable def fixture1Index385 : Fin 520 := ⟨385, by decide⟩
noncomputable def fixture1Index386 : Fin 520 := ⟨386, by decide⟩
noncomputable def fixture1Index387 : Fin 520 := ⟨387, by decide⟩
noncomputable def fixture1Index388 : Fin 520 := ⟨388, by decide⟩
noncomputable def fixture1Index389 : Fin 520 := ⟨389, by decide⟩
noncomputable def fixture1Index390 : Fin 520 := ⟨390, by decide⟩
noncomputable def fixture1Index391 : Fin 520 := ⟨391, by decide⟩
noncomputable def fixture1Index392 : Fin 520 := ⟨392, by decide⟩
noncomputable def fixture1Index393 : Fin 520 := ⟨393, by decide⟩
noncomputable def fixture1Index394 : Fin 520 := ⟨394, by decide⟩
noncomputable def fixture1Index395 : Fin 520 := ⟨395, by decide⟩
noncomputable def fixture1Index396 : Fin 520 := ⟨396, by decide⟩
noncomputable def fixture1Index397 : Fin 520 := ⟨397, by decide⟩
noncomputable def fixture1Index398 : Fin 520 := ⟨398, by decide⟩
noncomputable def fixture1Index399 : Fin 520 := ⟨399, by decide⟩
noncomputable def fixture1Index400 : Fin 520 := ⟨400, by decide⟩
noncomputable def fixture1Index401 : Fin 520 := ⟨401, by decide⟩
noncomputable def fixture1Index402 : Fin 520 := ⟨402, by decide⟩
noncomputable def fixture1Index403 : Fin 520 := ⟨403, by decide⟩
noncomputable def fixture1Index404 : Fin 520 := ⟨404, by decide⟩
noncomputable def fixture1Index405 : Fin 520 := ⟨405, by decide⟩
noncomputable def fixture1Index406 : Fin 520 := ⟨406, by decide⟩
noncomputable def fixture1Index407 : Fin 520 := ⟨407, by decide⟩
noncomputable def fixture1Index408 : Fin 520 := ⟨408, by decide⟩
noncomputable def fixture1Index409 : Fin 520 := ⟨409, by decide⟩
noncomputable def fixture1Index410 : Fin 520 := ⟨410, by decide⟩
noncomputable def fixture1Index411 : Fin 520 := ⟨411, by decide⟩
noncomputable def fixture1Index412 : Fin 520 := ⟨412, by decide⟩
noncomputable def fixture1Index413 : Fin 520 := ⟨413, by decide⟩
noncomputable def fixture1Index414 : Fin 520 := ⟨414, by decide⟩
noncomputable def fixture1Index415 : Fin 520 := ⟨415, by decide⟩
noncomputable def fixture1Index416 : Fin 520 := ⟨416, by decide⟩
noncomputable def fixture1Index417 : Fin 520 := ⟨417, by decide⟩
noncomputable def fixture1Index418 : Fin 520 := ⟨418, by decide⟩
noncomputable def fixture1Index419 : Fin 520 := ⟨419, by decide⟩
noncomputable def fixture1Index420 : Fin 520 := ⟨420, by decide⟩
noncomputable def fixture1Index421 : Fin 520 := ⟨421, by decide⟩
noncomputable def fixture1Index422 : Fin 520 := ⟨422, by decide⟩
noncomputable def fixture1Index423 : Fin 520 := ⟨423, by decide⟩
noncomputable def fixture1Index424 : Fin 520 := ⟨424, by decide⟩
noncomputable def fixture1Index425 : Fin 520 := ⟨425, by decide⟩
noncomputable def fixture1Index426 : Fin 520 := ⟨426, by decide⟩
noncomputable def fixture1Index427 : Fin 520 := ⟨427, by decide⟩
noncomputable def fixture1Index428 : Fin 520 := ⟨428, by decide⟩
noncomputable def fixture1Index429 : Fin 520 := ⟨429, by decide⟩
noncomputable def fixture1Index430 : Fin 520 := ⟨430, by decide⟩
noncomputable def fixture1Index431 : Fin 520 := ⟨431, by decide⟩
noncomputable def fixture1Index432 : Fin 520 := ⟨432, by decide⟩
noncomputable def fixture1Index433 : Fin 520 := ⟨433, by decide⟩
noncomputable def fixture1Index434 : Fin 520 := ⟨434, by decide⟩
noncomputable def fixture1Index435 : Fin 520 := ⟨435, by decide⟩
noncomputable def fixture1Index436 : Fin 520 := ⟨436, by decide⟩
noncomputable def fixture1Index437 : Fin 520 := ⟨437, by decide⟩
noncomputable def fixture1Index438 : Fin 520 := ⟨438, by decide⟩
noncomputable def fixture1Index439 : Fin 520 := ⟨439, by decide⟩
noncomputable def fixture1Index440 : Fin 520 := ⟨440, by decide⟩
noncomputable def fixture1Index441 : Fin 520 := ⟨441, by decide⟩
noncomputable def fixture1Index442 : Fin 520 := ⟨442, by decide⟩
noncomputable def fixture1Index443 : Fin 520 := ⟨443, by decide⟩
noncomputable def fixture1Index444 : Fin 520 := ⟨444, by decide⟩
noncomputable def fixture1Index445 : Fin 520 := ⟨445, by decide⟩
noncomputable def fixture1Index446 : Fin 520 := ⟨446, by decide⟩
noncomputable def fixture1Index447 : Fin 520 := ⟨447, by decide⟩
noncomputable def fixture1Index448 : Fin 520 := ⟨448, by decide⟩
noncomputable def fixture1Index449 : Fin 520 := ⟨449, by decide⟩
noncomputable def fixture1Index450 : Fin 520 := ⟨450, by decide⟩
noncomputable def fixture1Index451 : Fin 520 := ⟨451, by decide⟩
noncomputable def fixture1Index452 : Fin 520 := ⟨452, by decide⟩
noncomputable def fixture1Index453 : Fin 520 := ⟨453, by decide⟩
noncomputable def fixture1Index454 : Fin 520 := ⟨454, by decide⟩
noncomputable def fixture1Index455 : Fin 520 := ⟨455, by decide⟩
noncomputable def fixture1Index456 : Fin 520 := ⟨456, by decide⟩
noncomputable def fixture1Index457 : Fin 520 := ⟨457, by decide⟩
noncomputable def fixture1Index458 : Fin 520 := ⟨458, by decide⟩
noncomputable def fixture1Index459 : Fin 520 := ⟨459, by decide⟩
noncomputable def fixture1Index460 : Fin 520 := ⟨460, by decide⟩
noncomputable def fixture1Index461 : Fin 520 := ⟨461, by decide⟩
noncomputable def fixture1Index462 : Fin 520 := ⟨462, by decide⟩
noncomputable def fixture1Index463 : Fin 520 := ⟨463, by decide⟩
noncomputable def fixture1Index464 : Fin 520 := ⟨464, by decide⟩
noncomputable def fixture1Index465 : Fin 520 := ⟨465, by decide⟩
noncomputable def fixture1Index466 : Fin 520 := ⟨466, by decide⟩
noncomputable def fixture1Index467 : Fin 520 := ⟨467, by decide⟩
noncomputable def fixture1Index468 : Fin 520 := ⟨468, by decide⟩
noncomputable def fixture1Index469 : Fin 520 := ⟨469, by decide⟩
noncomputable def fixture1Index470 : Fin 520 := ⟨470, by decide⟩
noncomputable def fixture1Index471 : Fin 520 := ⟨471, by decide⟩
noncomputable def fixture1Index472 : Fin 520 := ⟨472, by decide⟩
noncomputable def fixture1Index473 : Fin 520 := ⟨473, by decide⟩
noncomputable def fixture1Index474 : Fin 520 := ⟨474, by decide⟩
noncomputable def fixture1Index475 : Fin 520 := ⟨475, by decide⟩
noncomputable def fixture1Index476 : Fin 520 := ⟨476, by decide⟩
noncomputable def fixture1Index477 : Fin 520 := ⟨477, by decide⟩
noncomputable def fixture1Index478 : Fin 520 := ⟨478, by decide⟩
noncomputable def fixture1Index479 : Fin 520 := ⟨479, by decide⟩
noncomputable def fixture1Index480 : Fin 520 := ⟨480, by decide⟩
noncomputable def fixture1Index481 : Fin 520 := ⟨481, by decide⟩
noncomputable def fixture1Index482 : Fin 520 := ⟨482, by decide⟩
noncomputable def fixture1Index483 : Fin 520 := ⟨483, by decide⟩
noncomputable def fixture1Index484 : Fin 520 := ⟨484, by decide⟩
noncomputable def fixture1Index485 : Fin 520 := ⟨485, by decide⟩
noncomputable def fixture1Index486 : Fin 520 := ⟨486, by decide⟩
noncomputable def fixture1Index487 : Fin 520 := ⟨487, by decide⟩
noncomputable def fixture1Index488 : Fin 520 := ⟨488, by decide⟩
noncomputable def fixture1Index489 : Fin 520 := ⟨489, by decide⟩
noncomputable def fixture1Index490 : Fin 520 := ⟨490, by decide⟩
noncomputable def fixture1Index491 : Fin 520 := ⟨491, by decide⟩
noncomputable def fixture1Index492 : Fin 520 := ⟨492, by decide⟩
noncomputable def fixture1Index493 : Fin 520 := ⟨493, by decide⟩
noncomputable def fixture1Index494 : Fin 520 := ⟨494, by decide⟩
noncomputable def fixture1Index495 : Fin 520 := ⟨495, by decide⟩
noncomputable def fixture1Index496 : Fin 520 := ⟨496, by decide⟩
noncomputable def fixture1Index497 : Fin 520 := ⟨497, by decide⟩
noncomputable def fixture1Index498 : Fin 520 := ⟨498, by decide⟩
noncomputable def fixture1Index499 : Fin 520 := ⟨499, by decide⟩
noncomputable def fixture1Index500 : Fin 520 := ⟨500, by decide⟩
noncomputable def fixture1Index501 : Fin 520 := ⟨501, by decide⟩
noncomputable def fixture1Index502 : Fin 520 := ⟨502, by decide⟩
noncomputable def fixture1Index503 : Fin 520 := ⟨503, by decide⟩
noncomputable def fixture1Index504 : Fin 520 := ⟨504, by decide⟩
noncomputable def fixture1Index505 : Fin 520 := ⟨505, by decide⟩
noncomputable def fixture1Index506 : Fin 520 := ⟨506, by decide⟩
noncomputable def fixture1Index507 : Fin 520 := ⟨507, by decide⟩
noncomputable def fixture1Index508 : Fin 520 := ⟨508, by decide⟩
noncomputable def fixture1Index509 : Fin 520 := ⟨509, by decide⟩
noncomputable def fixture1Index510 : Fin 520 := ⟨510, by decide⟩
noncomputable def fixture1Index511 : Fin 520 := ⟨511, by decide⟩
noncomputable def fixture1Index512 : Fin 520 := ⟨512, by decide⟩
noncomputable def fixture1Index513 : Fin 520 := ⟨513, by decide⟩
noncomputable def fixture1Index514 : Fin 520 := ⟨514, by decide⟩
noncomputable def fixture1Index515 : Fin 520 := ⟨515, by decide⟩
noncomputable def fixture1Index516 : Fin 520 := ⟨516, by decide⟩
noncomputable def fixture1Index517 : Fin 520 := ⟨517, by decide⟩
noncomputable def fixture1Index518 : Fin 520 := ⟨518, by decide⟩
noncomputable def fixture1Index519 : Fin 520 := ⟨519, by decide⟩

noncomputable def fixture1RowsArray : Array (List (Fin 520)) := #[
  [fixture1Index1,fixture1Index4]
  ,[fixture1Index0,fixture1Index5]
  ,[fixture1Index7,fixture1Index8]
  ,[fixture1Index6,fixture1Index8]
  ,[fixture1Index9,fixture1Index11]
  ,[fixture1Index9,fixture1Index10]
  ,[fixture1Index13]
  ,[fixture1Index12]
  ,[]
  ,[]
  ,[fixture1Index1,fixture1Index14]
  ,[fixture1Index0,fixture1Index15]
  ,[fixture1Index1,fixture1Index16,fixture1Index18]
  ,[fixture1Index0,fixture1Index17,fixture1Index19]
  ,[fixture1Index9,fixture1Index21,fixture1Index15]
  ,[fixture1Index9,fixture1Index20,fixture1Index14]
  ,[fixture1Index9,fixture1Index23]
  ,[fixture1Index9,fixture1Index22]
  ,[fixture1Index25,fixture1Index27]
  ,[fixture1Index24,fixture1Index26]
  ,[fixture1Index1,fixture1Index28]
  ,[fixture1Index0,fixture1Index29]
  ,[fixture1Index1,fixture1Index30]
  ,[fixture1Index0,fixture1Index31]
  ,[fixture1Index33,fixture1Index8]
  ,[fixture1Index32,fixture1Index8]
  ,[fixture1Index35,fixture1Index14]
  ,[fixture1Index34,fixture1Index15]
  ,[fixture1Index9,fixture1Index37,fixture1Index39,fixture1Index40]
  ,[fixture1Index9,fixture1Index36,fixture1Index38,fixture1Index41]
  ,[fixture1Index9,fixture1Index37,fixture1Index43,fixture1Index26]
  ,[fixture1Index9,fixture1Index36,fixture1Index42,fixture1Index27]
  ,[fixture1Index1,fixture1Index16,fixture1Index44,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index45,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index50]
  ,[fixture1Index0,fixture1Index17,fixture1Index51]
  ,[fixture1Index1,fixture1Index52]
  ,[fixture1Index0,fixture1Index53]
  ,[fixture1Index9,fixture1Index37,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index60,fixture1Index8]
  ,[fixture1Index9,fixture1Index36,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index61,fixture1Index8]
  ,[fixture1Index63,fixture1Index42,fixture1Index27]
  ,[fixture1Index62,fixture1Index43,fixture1Index26]
  ,[fixture1Index9,fixture1Index65,fixture1Index8]
  ,[fixture1Index9,fixture1Index64,fixture1Index8]
  ,[fixture1Index25,fixture1Index67]
  ,[fixture1Index24,fixture1Index66]
  ,[fixture1Index69]
  ,[fixture1Index68]
  ,[fixture1Index71]
  ,[fixture1Index70]
  ,[fixture1Index73,fixture1Index41]
  ,[fixture1Index72,fixture1Index40]
  ,[fixture1Index9,fixture1Index37,fixture1Index75,fixture1Index40]
  ,[fixture1Index9,fixture1Index36,fixture1Index74,fixture1Index41]
  ,[fixture1Index9,fixture1Index77]
  ,[fixture1Index9,fixture1Index76]
  ,[fixture1Index1,fixture1Index16,fixture1Index78]
  ,[fixture1Index0,fixture1Index17,fixture1Index79]
  ,[fixture1Index1,fixture1Index16,fixture1Index80,fixture1Index83]
  ,[fixture1Index0,fixture1Index17,fixture1Index81,fixture1Index82]
  ,[fixture1Index1,fixture1Index16,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index84]
  ,[fixture1Index0,fixture1Index17,fixture1Index85]
  ,[fixture1Index1,fixture1Index86,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index0,fixture1Index87,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index63,fixture1Index42,fixture1Index41]
  ,[fixture1Index62,fixture1Index43,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index90,fixture1Index93,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index91,fixture1Index92,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index90,fixture1Index95,fixture1Index27]
  ,[fixture1Index88,fixture1Index0,fixture1Index91,fixture1Index94,fixture1Index26]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index61,fixture1Index8]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index60,fixture1Index8]
  ,[fixture1Index9,fixture1Index37,fixture1Index55,fixture1Index96,fixture1Index8]
  ,[fixture1Index9,fixture1Index36,fixture1Index54,fixture1Index97,fixture1Index8]
  ,[fixture1Index1,fixture1Index98]
  ,[fixture1Index0,fixture1Index99]
  ,[fixture1Index101]
  ,[fixture1Index100]
  ,[fixture1Index103,fixture1Index49]
  ,[fixture1Index102,fixture1Index48]
  ,[fixture1Index1,fixture1Index16,fixture1Index46,fixture1Index104]
  ,[fixture1Index0,fixture1Index17,fixture1Index47,fixture1Index105]
  ,[fixture1Index25,fixture1Index41]
  ,[fixture1Index24,fixture1Index40]
  ,[fixture1Index9,fixture1Index37,fixture1Index75,fixture1Index66]
  ,[fixture1Index9,fixture1Index36,fixture1Index74,fixture1Index67]
  ,[fixture1Index1,fixture1Index16,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index45,fixture1Index49]
  ,[fixture1Index9,fixture1Index107,fixture1Index8]
  ,[fixture1Index9,fixture1Index106,fixture1Index8]
  ,[fixture1Index109,fixture1Index97,fixture1Index8]
  ,[fixture1Index108,fixture1Index96,fixture1Index8]
  ,[fixture1Index111,fixture1Index8]
  ,[fixture1Index110,fixture1Index8]
  ,[fixture1Index1,fixture1Index16,fixture1Index112,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index113,fixture1Index45,fixture1Index49]
  ,[fixture1Index9,fixture1Index37,fixture1Index115,fixture1Index26]
  ,[fixture1Index9,fixture1Index36,fixture1Index114,fixture1Index27]
  ,[fixture1Index63,fixture1Index90,fixture1Index117,fixture1Index27]
  ,[fixture1Index62,fixture1Index91,fixture1Index116,fixture1Index26]
  ,[fixture1Index63,fixture1Index90,fixture1Index119,fixture1Index67]
  ,[fixture1Index62,fixture1Index91,fixture1Index118,fixture1Index66]
  ,[fixture1Index121,fixture1Index27]
  ,[fixture1Index120,fixture1Index26]
  ,[fixture1Index1,fixture1Index122,fixture1Index49]
  ,[fixture1Index0,fixture1Index123,fixture1Index48]
  ,[fixture1Index1,fixture1Index16,fixture1Index124]
  ,[fixture1Index0,fixture1Index17,fixture1Index125]
  ,[fixture1Index1,fixture1Index16,fixture1Index126,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index127,fixture1Index45,fixture1Index49]
  ,[fixture1Index129]
  ,[fixture1Index128]
  ,[fixture1Index9,fixture1Index37,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index96,fixture1Index8]
  ,[fixture1Index9,fixture1Index36,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index97,fixture1Index8]
  ,[fixture1Index133,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index97,fixture1Index8]
  ,[fixture1Index132,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index96,fixture1Index8]
  ,[fixture1Index135,fixture1Index8]
  ,[fixture1Index134,fixture1Index8]
  ,[fixture1Index63,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index97,fixture1Index8]
  ,[fixture1Index62,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index96,fixture1Index8]
  ,[fixture1Index9,fixture1Index37,fixture1Index39,fixture1Index66]
  ,[fixture1Index9,fixture1Index36,fixture1Index38,fixture1Index67]
  ,[fixture1Index137,fixture1Index139,fixture1Index47,fixture1Index105]
  ,[fixture1Index136,fixture1Index138,fixture1Index46,fixture1Index104]
  ,[fixture1Index137,fixture1Index141]
  ,[fixture1Index136,fixture1Index140]
  ,[fixture1Index63,fixture1Index90,fixture1Index143,fixture1Index41]
  ,[fixture1Index62,fixture1Index91,fixture1Index142,fixture1Index40]
  ,[fixture1Index1,fixture1Index16,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index144,fixture1Index146]
  ,[fixture1Index0,fixture1Index17,fixture1Index145,fixture1Index147]
  ,[fixture1Index1,fixture1Index16,fixture1Index144,fixture1Index148,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index145,fixture1Index149,fixture1Index45,fixture1Index49]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index109,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index157,fixture1Index159,fixture1Index161,fixture1Index67]
  ,[fixture1Index108,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index156,fixture1Index158,fixture1Index160,fixture1Index66]
  ,[fixture1Index109,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index157,fixture1Index159,fixture1Index163,fixture1Index41]
  ,[fixture1Index108,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index156,fixture1Index158,fixture1Index162,fixture1Index40]
  ,[fixture1Index133,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index97,fixture1Index8]
  ,[fixture1Index132,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index96,fixture1Index8]
  ,[fixture1Index165]
  ,[fixture1Index164]
  ,[fixture1Index167,fixture1Index169]
  ,[fixture1Index166,fixture1Index168]
  ,[fixture1Index167,fixture1Index141]
  ,[fixture1Index166,fixture1Index140]
  ,[fixture1Index171,fixture1Index172]
  ,[fixture1Index170,fixture1Index173]
  ,[fixture1Index1,fixture1Index16,fixture1Index174]
  ,[fixture1Index0,fixture1Index17,fixture1Index175]
  ,[fixture1Index1,fixture1Index16,fixture1Index176,fixture1Index8]
  ,[fixture1Index0,fixture1Index17,fixture1Index177,fixture1Index8]
  ,[fixture1Index171,fixture1Index178,fixture1Index61,fixture1Index8]
  ,[fixture1Index170,fixture1Index179,fixture1Index60,fixture1Index8]
  ,[fixture1Index181,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index180,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index61,fixture1Index8]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index60,fixture1Index8]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index97,fixture1Index8]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index96,fixture1Index8]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index185,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index187,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index184,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index186,fixture1Index40]
  ,[fixture1Index63,fixture1Index90,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index62,fixture1Index91,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index109,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index157,fixture1Index159,fixture1Index189,fixture1Index27]
  ,[fixture1Index108,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index156,fixture1Index158,fixture1Index188,fixture1Index26]
  ,[fixture1Index1,fixture1Index16,fixture1Index190,fixture1Index46,fixture1Index192]
  ,[fixture1Index0,fixture1Index17,fixture1Index191,fixture1Index47,fixture1Index193]
  ,[fixture1Index195]
  ,[fixture1Index194]
  ,[fixture1Index103,fixture1Index47,fixture1Index105]
  ,[fixture1Index102,fixture1Index46,fixture1Index104]
  ,[fixture1Index103,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index102,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index197,fixture1Index199,fixture1Index201]
  ,[fixture1Index196,fixture1Index198,fixture1Index200]
  ,[fixture1Index1,fixture1Index16,fixture1Index202,fixture1Index8]
  ,[fixture1Index0,fixture1Index17,fixture1Index203,fixture1Index8]
  ,[fixture1Index1,fixture1Index16,fixture1Index204]
  ,[fixture1Index0,fixture1Index17,fixture1Index205]
  ,[fixture1Index207]
  ,[fixture1Index206]
  ,[fixture1Index209,fixture1Index210,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index97,fixture1Index8]
  ,[fixture1Index208,fixture1Index211,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index96,fixture1Index8]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index97,fixture1Index8]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index96,fixture1Index8]
  ,[fixture1Index137,fixture1Index159,fixture1Index161,fixture1Index67]
  ,[fixture1Index136,fixture1Index158,fixture1Index160,fixture1Index66]
  ,[fixture1Index213,fixture1Index41]
  ,[fixture1Index212,fixture1Index40]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index157,fixture1Index159,fixture1Index189,fixture1Index27]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index156,fixture1Index158,fixture1Index188,fixture1Index26]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index215]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index214]
  ,[fixture1Index217]
  ,[fixture1Index216]
  ,[fixture1Index219]
  ,[fixture1Index218]
  ,[fixture1Index137,fixture1Index139,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index136,fixture1Index138,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index221]
  ,[fixture1Index220]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index224,fixture1Index226,fixture1Index46,fixture1Index104]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index225,fixture1Index227,fixture1Index47,fixture1Index105]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index228,fixture1Index46,fixture1Index192]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index229,fixture1Index47,fixture1Index193]
  ,[fixture1Index197,fixture1Index199,fixture1Index147]
  ,[fixture1Index196,fixture1Index198,fixture1Index146]
  ,[fixture1Index63,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index97,fixture1Index8]
  ,[fixture1Index62,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index96,fixture1Index8]
  ,[fixture1Index171,fixture1Index230,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index233,fixture1Index41]
  ,[fixture1Index170,fixture1Index231,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index232,fixture1Index40]
  ,[fixture1Index63,fixture1Index90,fixture1Index185,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index187,fixture1Index41]
  ,[fixture1Index62,fixture1Index91,fixture1Index184,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index186,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index235,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index241,fixture1Index159,fixture1Index189,fixture1Index27]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index234,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index240,fixture1Index158,fixture1Index188,fixture1Index26]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index243,fixture1Index245,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index241,fixture1Index159,fixture1Index189,fixture1Index27]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index242,fixture1Index244,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index240,fixture1Index158,fixture1Index188,fixture1Index26]
  ,[fixture1Index137,fixture1Index249]
  ,[fixture1Index136,fixture1Index248]
  ,[fixture1Index167,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index251]
  ,[fixture1Index166,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index250]
  ,[fixture1Index167,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index255,fixture1Index161,fixture1Index67]
  ,[fixture1Index166,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index254,fixture1Index160,fixture1Index66]
  ,[fixture1Index167,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index257,fixture1Index161,fixture1Index67]
  ,[fixture1Index166,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index256,fixture1Index160,fixture1Index66]
  ,[fixture1Index197,fixture1Index199,fixture1Index259]
  ,[fixture1Index196,fixture1Index198,fixture1Index258]
  ,[fixture1Index209,fixture1Index260,fixture1Index97,fixture1Index8]
  ,[fixture1Index208,fixture1Index261,fixture1Index96,fixture1Index8]
  ,[fixture1Index171,fixture1Index262]
  ,[fixture1Index170,fixture1Index263]
  ,[fixture1Index265]
  ,[fixture1Index264]
  ,[fixture1Index267,fixture1Index61,fixture1Index8]
  ,[fixture1Index266,fixture1Index60,fixture1Index8]
  ,[fixture1Index269,fixture1Index61,fixture1Index8]
  ,[fixture1Index268,fixture1Index60,fixture1Index8]
  ,[fixture1Index171,fixture1Index270,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index170,fixture1Index271,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index273,fixture1Index275,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index272,fixture1Index274,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index277]
  ,[fixture1Index276]
  ,[fixture1Index109,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index187,fixture1Index41]
  ,[fixture1Index108,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index186,fixture1Index40]
  ,[fixture1Index109,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index185,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index187,fixture1Index41]
  ,[fixture1Index108,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index184,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index186,fixture1Index40]
  ,[fixture1Index279,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index278,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index281,fixture1Index283,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index280,fixture1Index282,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index109,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index185,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index108,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index184,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index167,fixture1Index139,fixture1Index47,fixture1Index105]
  ,[fixture1Index166,fixture1Index138,fixture1Index46,fixture1Index104]
  ,[fixture1Index197,fixture1Index285,fixture1Index287,fixture1Index259]
  ,[fixture1Index196,fixture1Index284,fixture1Index286,fixture1Index258]
  ,[fixture1Index197,fixture1Index285,fixture1Index287,fixture1Index289,fixture1Index105]
  ,[fixture1Index196,fixture1Index284,fixture1Index286,fixture1Index288,fixture1Index104]
  ,[fixture1Index1,fixture1Index16,fixture1Index144,fixture1Index290,fixture1Index292,fixture1Index288,fixture1Index104]
  ,[fixture1Index0,fixture1Index17,fixture1Index145,fixture1Index291,fixture1Index293,fixture1Index289,fixture1Index105]
  ,[fixture1Index1,fixture1Index16,fixture1Index294,fixture1Index296,fixture1Index286,fixture1Index200]
  ,[fixture1Index0,fixture1Index17,fixture1Index295,fixture1Index297,fixture1Index287,fixture1Index201]
  ,[fixture1Index1,fixture1Index16,fixture1Index298]
  ,[fixture1Index0,fixture1Index17,fixture1Index299]
  ,[fixture1Index197,fixture1Index199,fixture1Index301,fixture1Index8]
  ,[fixture1Index196,fixture1Index198,fixture1Index300,fixture1Index8]
  ,[fixture1Index1,fixture1Index16,fixture1Index302,fixture1Index8]
  ,[fixture1Index0,fixture1Index17,fixture1Index303,fixture1Index8]
  ,[fixture1Index171,fixture1Index304,fixture1Index306,fixture1Index308,fixture1Index284,fixture1Index310,fixture1Index312,fixture1Index8]
  ,[fixture1Index170,fixture1Index305,fixture1Index307,fixture1Index309,fixture1Index285,fixture1Index311,fixture1Index313,fixture1Index8]
  ,[fixture1Index1,fixture1Index16,fixture1Index314,fixture1Index292,fixture1Index288,fixture1Index104]
  ,[fixture1Index0,fixture1Index17,fixture1Index315,fixture1Index293,fixture1Index289,fixture1Index105]
  ,[fixture1Index1,fixture1Index16,fixture1Index144,fixture1Index300,fixture1Index8]
  ,[fixture1Index0,fixture1Index17,fixture1Index145,fixture1Index301,fixture1Index8]
  ,[fixture1Index171,fixture1Index304,fixture1Index316,fixture1Index318,fixture1Index8]
  ,[fixture1Index170,fixture1Index305,fixture1Index317,fixture1Index319,fixture1Index8]
  ,[fixture1Index321]
  ,[fixture1Index320]
  ,[fixture1Index323]
  ,[fixture1Index322]
  ,[fixture1Index325]
  ,[fixture1Index324]
  ,[fixture1Index327]
  ,[fixture1Index326]
  ,[fixture1Index329]
  ,[fixture1Index328]
  ,[fixture1Index331]
  ,[fixture1Index330]
  ,[fixture1Index333]
  ,[fixture1Index332]
  ,[fixture1Index335]
  ,[fixture1Index334]
  ,[fixture1Index337]
  ,[fixture1Index336]
  ,[fixture1Index167,fixture1Index139,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index166,fixture1Index138,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index339,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index338,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index341]
  ,[fixture1Index340]
  ,[fixture1Index343]
  ,[fixture1Index342]
  ,[fixture1Index345]
  ,[fixture1Index344]
  ,[fixture1Index347]
  ,[fixture1Index346]
  ,[fixture1Index349,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index348,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index351]
  ,[fixture1Index350]
  ,[fixture1Index353]
  ,[fixture1Index352]
  ,[fixture1Index355,fixture1Index357,fixture1Index199,fixture1Index359,fixture1Index291,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index361,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index354,fixture1Index356,fixture1Index198,fixture1Index358,fixture1Index290,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index360,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index226,fixture1Index46,fixture1Index104]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index227,fixture1Index47,fixture1Index105]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index363,fixture1Index365,fixture1Index41]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index362,fixture1Index364,fixture1Index40]
  ,[fixture1Index63,fixture1Index90,fixture1Index367,fixture1Index283,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index187,fixture1Index41]
  ,[fixture1Index62,fixture1Index91,fixture1Index366,fixture1Index282,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index186,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index235,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index241,fixture1Index159,fixture1Index163,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index234,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index240,fixture1Index158,fixture1Index162,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index235,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index257,fixture1Index163,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index234,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index256,fixture1Index162,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index185,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index187,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index184,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index186,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index363,fixture1Index365,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index362,fixture1Index364,fixture1Index40]
  ,[fixture1Index63,fixture1Index90,fixture1Index369,fixture1Index1,fixture1Index90,fixture1Index371,fixture1Index365,fixture1Index41]
  ,[fixture1Index62,fixture1Index91,fixture1Index368,fixture1Index0,fixture1Index91,fixture1Index370,fixture1Index364,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index235,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index241,fixture1Index159,fixture1Index189,fixture1Index27]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index234,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index240,fixture1Index158,fixture1Index188,fixture1Index26]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index243,fixture1Index245,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index241,fixture1Index159,fixture1Index161,fixture1Index67]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index242,fixture1Index244,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index240,fixture1Index158,fixture1Index160,fixture1Index66]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index373,fixture1Index163,fixture1Index41]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index372,fixture1Index162,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index363,fixture1Index365,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index362,fixture1Index364,fixture1Index40]
  ,[fixture1Index63,fixture1Index90,fixture1Index367,fixture1Index365,fixture1Index41]
  ,[fixture1Index62,fixture1Index91,fixture1Index366,fixture1Index364,fixture1Index40]
  ,[fixture1Index63,fixture1Index90,fixture1Index369,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index371,fixture1Index365,fixture1Index41]
  ,[fixture1Index62,fixture1Index91,fixture1Index368,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index370,fixture1Index364,fixture1Index40]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index379,fixture1Index381,fixture1Index383,fixture1Index385,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index241,fixture1Index159,fixture1Index161,fixture1Index67]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index378,fixture1Index380,fixture1Index382,fixture1Index384,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index240,fixture1Index158,fixture1Index160,fixture1Index66]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index235,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index257,fixture1Index163,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index234,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index256,fixture1Index162,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index233,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index232,fixture1Index40]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index387,fixture1Index389,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index251]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index386,fixture1Index388,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index250]
  ,[fixture1Index167,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index393]
  ,[fixture1Index166,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index392]
  ,[fixture1Index167,fixture1Index241,fixture1Index159,fixture1Index395]
  ,[fixture1Index166,fixture1Index240,fixture1Index158,fixture1Index394]
  ,[fixture1Index397,fixture1Index161,fixture1Index67]
  ,[fixture1Index396,fixture1Index160,fixture1Index66]
  ,[fixture1Index171,fixture1Index398,fixture1Index8]
  ,[fixture1Index170,fixture1Index399,fixture1Index8]
  ,[fixture1Index171,fixture1Index260,fixture1Index97,fixture1Index8]
  ,[fixture1Index170,fixture1Index261,fixture1Index96,fixture1Index8]
  ,[fixture1Index401,fixture1Index398,fixture1Index8]
  ,[fixture1Index400,fixture1Index399,fixture1Index8]
  ,[fixture1Index401,fixture1Index262]
  ,[fixture1Index400,fixture1Index263]
  ,[fixture1Index403,fixture1Index8]
  ,[fixture1Index402,fixture1Index8]
  ,[fixture1Index171,fixture1Index230,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index185,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index170,fixture1Index231,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index184,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index405]
  ,[fixture1Index404]
  ,[fixture1Index171,fixture1Index406]
  ,[fixture1Index170,fixture1Index407]
  ,[fixture1Index409,fixture1Index8]
  ,[fixture1Index408,fixture1Index8]
  ,[fixture1Index411,fixture1Index8]
  ,[fixture1Index410,fixture1Index8]
  ,[fixture1Index413,fixture1Index415,fixture1Index8]
  ,[fixture1Index412,fixture1Index414,fixture1Index8]
  ,[fixture1Index417,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index416,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index419,fixture1Index8]
  ,[fixture1Index418,fixture1Index8]
  ,[fixture1Index421,fixture1Index155,fixture1Index275,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index420,fixture1Index154,fixture1Index274,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index273,fixture1Index423,fixture1Index283,fixture1Index155,fixture1Index425]
  ,[fixture1Index272,fixture1Index422,fixture1Index282,fixture1Index154,fixture1Index424]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index281,fixture1Index365,fixture1Index41]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index280,fixture1Index364,fixture1Index40]
  ,[fixture1Index273,fixture1Index427,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index429,fixture1Index155,fixture1Index431,fixture1Index283,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index155,fixture1Index187,fixture1Index41]
  ,[fixture1Index272,fixture1Index426,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index428,fixture1Index154,fixture1Index430,fixture1Index282,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index154,fixture1Index186,fixture1Index40]
  ,[fixture1Index63,fixture1Index90,fixture1Index185,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index62,fixture1Index91,fixture1Index184,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index197,fixture1Index285,fixture1Index309,fixture1Index285,fixture1Index311,fixture1Index361,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index196,fixture1Index284,fixture1Index308,fixture1Index284,fixture1Index310,fixture1Index360,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index432,fixture1Index46,fixture1Index192]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index433,fixture1Index47,fixture1Index193]
  ,[fixture1Index1,fixture1Index16,fixture1Index294,fixture1Index308,fixture1Index284,fixture1Index310,fixture1Index360,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index295,fixture1Index309,fixture1Index285,fixture1Index311,fixture1Index361,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index294,fixture1Index286,fixture1Index288,fixture1Index104]
  ,[fixture1Index0,fixture1Index17,fixture1Index295,fixture1Index287,fixture1Index289,fixture1Index105]
  ,[fixture1Index197,fixture1Index199,fixture1Index291,fixture1Index293,fixture1Index289,fixture1Index105]
  ,[fixture1Index196,fixture1Index198,fixture1Index290,fixture1Index292,fixture1Index288,fixture1Index104]
  ,[fixture1Index1,fixture1Index16,fixture1Index314,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index360,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index315,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index361,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index434,fixture1Index308,fixture1Index284,fixture1Index310,fixture1Index360,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index435,fixture1Index309,fixture1Index285,fixture1Index311,fixture1Index361,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index436,fixture1Index284,fixture1Index310,fixture1Index312,fixture1Index8]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index437,fixture1Index285,fixture1Index311,fixture1Index313,fixture1Index8]
  ,[fixture1Index171,fixture1Index304,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index198,fixture1Index224,fixture1Index226,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index170,fixture1Index305,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index199,fixture1Index225,fixture1Index227,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index440,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index442,fixture1Index444,fixture1Index8]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index441,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index443,fixture1Index445,fixture1Index8]
  ,[fixture1Index1,fixture1Index16,fixture1Index294,fixture1Index296,fixture1Index286,fixture1Index290,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index198,fixture1Index224,fixture1Index226,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index295,fixture1Index297,fixture1Index287,fixture1Index291,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index199,fixture1Index225,fixture1Index227,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index440,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index442,fixture1Index316,fixture1Index446]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index441,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index443,fixture1Index317,fixture1Index447]
  ,[fixture1Index171,fixture1Index304,fixture1Index306,fixture1Index308,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index448,fixture1Index398,fixture1Index8]
  ,[fixture1Index170,fixture1Index305,fixture1Index307,fixture1Index309,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index449,fixture1Index399,fixture1Index8]
  ,[fixture1Index171,fixture1Index304,fixture1Index292,fixture1Index288,fixture1Index104]
  ,[fixture1Index170,fixture1Index305,fixture1Index293,fixture1Index289,fixture1Index105]
  ,[fixture1Index171,fixture1Index304,fixture1Index306,fixture1Index308,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index446]
  ,[fixture1Index170,fixture1Index305,fixture1Index307,fixture1Index309,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index447]
  ,[fixture1Index171,fixture1Index304,fixture1Index316,fixture1Index442,fixture1Index316,fixture1Index446]
  ,[fixture1Index170,fixture1Index305,fixture1Index317,fixture1Index443,fixture1Index317,fixture1Index447]
  ,[fixture1Index171,fixture1Index304,fixture1Index450,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index452,fixture1Index8]
  ,[fixture1Index170,fixture1Index305,fixture1Index451,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index453,fixture1Index8]
  ,[fixture1Index167,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index257,fixture1Index161,fixture1Index67]
  ,[fixture1Index166,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index256,fixture1Index160,fixture1Index66]
  ,[fixture1Index167,fixture1Index241,fixture1Index159,fixture1Index455,fixture1Index159,fixture1Index457]
  ,[fixture1Index166,fixture1Index240,fixture1Index158,fixture1Index454,fixture1Index158,fixture1Index456]
  ,[fixture1Index167,fixture1Index241,fixture1Index159,fixture1Index459]
  ,[fixture1Index166,fixture1Index240,fixture1Index158,fixture1Index458]
  ,[fixture1Index461]
  ,[fixture1Index460]
  ,[fixture1Index167,fixture1Index241,fixture1Index159,fixture1Index463]
  ,[fixture1Index166,fixture1Index240,fixture1Index158,fixture1Index462]
  ,[fixture1Index465]
  ,[fixture1Index464]
  ,[fixture1Index467,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index466,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index469,fixture1Index227,fixture1Index47,fixture1Index105]
  ,[fixture1Index468,fixture1Index226,fixture1Index46,fixture1Index104]
  ,[fixture1Index471,fixture1Index47,fixture1Index193]
  ,[fixture1Index470,fixture1Index46,fixture1Index192]
  ,[fixture1Index473]
  ,[fixture1Index472]
  ,[fixture1Index475,fixture1Index357,fixture1Index199,fixture1Index359,fixture1Index291,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index361,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index474,fixture1Index356,fixture1Index198,fixture1Index358,fixture1Index290,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index360,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index477,fixture1Index381,fixture1Index479,fixture1Index481,fixture1Index283,fixture1Index155,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index476,fixture1Index380,fixture1Index478,fixture1Index480,fixture1Index282,fixture1Index154,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index483,fixture1Index1,fixture1Index90,fixture1Index371,fixture1Index365,fixture1Index41]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index482,fixture1Index0,fixture1Index91,fixture1Index370,fixture1Index364,fixture1Index40]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index477,fixture1Index485,fixture1Index1,fixture1Index90,fixture1Index371,fixture1Index283,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index281,fixture1Index365,fixture1Index41]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index476,fixture1Index484,fixture1Index0,fixture1Index91,fixture1Index370,fixture1Index282,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index280,fixture1Index364,fixture1Index40]
  ,[fixture1Index63,fixture1Index90,fixture1Index233,fixture1Index41]
  ,[fixture1Index62,fixture1Index91,fixture1Index232,fixture1Index40]
  ,[fixture1Index183,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index487,fixture1Index365,fixture1Index41]
  ,[fixture1Index182,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index486,fixture1Index364,fixture1Index40]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index387,fixture1Index489,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index387,fixture1Index389,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index257,fixture1Index163,fixture1Index41]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index386,fixture1Index488,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index386,fixture1Index388,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index256,fixture1Index162,fixture1Index40]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index379,fixture1Index381,fixture1Index383,fixture1Index385,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index241,fixture1Index159,fixture1Index161,fixture1Index67]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index378,fixture1Index380,fixture1Index382,fixture1Index384,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index240,fixture1Index158,fixture1Index160,fixture1Index66]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index387,fixture1Index385,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index237,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index251]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index386,fixture1Index384,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index236,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index250]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index387,fixture1Index385,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index257,fixture1Index161,fixture1Index67]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index386,fixture1Index384,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index256,fixture1Index160,fixture1Index66]
  ,[fixture1Index89,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index54,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index131,fixture1Index131,fixture1Index1,fixture1Index54,fixture1Index153,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index491,fixture1Index1,fixture1Index90,fixture1Index371,fixture1Index283,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index281,fixture1Index365,fixture1Index41]
  ,[fixture1Index88,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index55,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index130,fixture1Index130,fixture1Index0,fixture1Index55,fixture1Index152,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index490,fixture1Index0,fixture1Index91,fixture1Index370,fixture1Index282,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index280,fixture1Index364,fixture1Index40]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index387,fixture1Index385,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index497,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index251]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index386,fixture1Index384,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index496,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index250]
  ,[fixture1Index171,fixture1Index304,fixture1Index316,fixture1Index498,fixture1Index8]
  ,[fixture1Index170,fixture1Index305,fixture1Index317,fixture1Index499,fixture1Index8]
  ,[fixture1Index413,fixture1Index501,fixture1Index8]
  ,[fixture1Index412,fixture1Index500,fixture1Index8]
  ,[fixture1Index503,fixture1Index8]
  ,[fixture1Index502,fixture1Index8]
  ,[fixture1Index171,fixture1Index304,fixture1Index316,fixture1Index504]
  ,[fixture1Index170,fixture1Index305,fixture1Index317,fixture1Index505]
  ,[fixture1Index507]
  ,[fixture1Index506]
  ,[fixture1Index171,fixture1Index304,fixture1Index316,fixture1Index508,fixture1Index8]
  ,[fixture1Index170,fixture1Index305,fixture1Index317,fixture1Index509,fixture1Index8]
  ,[fixture1Index421,fixture1Index57,fixture1Index1,fixture1Index54,fixture1Index59,fixture1Index1,fixture1Index90,fixture1Index429,fixture1Index155,fixture1Index511,fixture1Index425]
  ,[fixture1Index420,fixture1Index56,fixture1Index0,fixture1Index55,fixture1Index58,fixture1Index0,fixture1Index91,fixture1Index428,fixture1Index154,fixture1Index510,fixture1Index424]
  ,[fixture1Index513]
  ,[fixture1Index512]
  ,[fixture1Index273,fixture1Index423,fixture1Index283,fixture1Index155,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index272,fixture1Index422,fixture1Index282,fixture1Index154,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index273,fixture1Index427,fixture1Index155,fixture1Index427,fixture1Index155,fixture1Index275,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index272,fixture1Index426,fixture1Index154,fixture1Index426,fixture1Index154,fixture1Index274,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index273,fixture1Index427,fixture1Index155,fixture1Index275,fixture1Index151,fixture1Index61,fixture1Index8]
  ,[fixture1Index272,fixture1Index426,fixture1Index154,fixture1Index274,fixture1Index150,fixture1Index60,fixture1Index8]
  ,[fixture1Index515,fixture1Index227,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index514,fixture1Index226,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index171,fixture1Index304,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index198,fixture1Index516,fixture1Index226,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index170,fixture1Index305,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index199,fixture1Index517,fixture1Index227,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index434,fixture1Index308,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index198,fixture1Index358,fixture1Index290,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index360,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index435,fixture1Index309,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index199,fixture1Index359,fixture1Index291,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index361,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index519,fixture1Index357,fixture1Index199,fixture1Index359,fixture1Index291,fixture1Index293,fixture1Index289,fixture1Index105]
  ,[fixture1Index518,fixture1Index356,fixture1Index198,fixture1Index358,fixture1Index290,fixture1Index292,fixture1Index288,fixture1Index104]
  ,[fixture1Index1,fixture1Index16,fixture1Index222,fixture1Index434,fixture1Index308,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index198,fixture1Index358,fixture1Index290,fixture1Index292,fixture1Index288,fixture1Index104]
  ,[fixture1Index0,fixture1Index17,fixture1Index223,fixture1Index435,fixture1Index309,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index199,fixture1Index359,fixture1Index291,fixture1Index293,fixture1Index289,fixture1Index105]
  ,[fixture1Index519,fixture1Index357,fixture1Index199,fixture1Index359,fixture1Index291,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index361,fixture1Index47,fixture1Index45,fixture1Index49]
  ,[fixture1Index518,fixture1Index356,fixture1Index198,fixture1Index358,fixture1Index290,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index360,fixture1Index46,fixture1Index44,fixture1Index48]
  ,[fixture1Index171,fixture1Index304,fixture1Index450,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index442,fixture1Index444,fixture1Index8]
  ,[fixture1Index170,fixture1Index305,fixture1Index451,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index443,fixture1Index445,fixture1Index8]
  ,[fixture1Index1,fixture1Index16,fixture1Index294,fixture1Index296,fixture1Index286,fixture1Index290,fixture1Index316,fixture1Index284,fixture1Index310,fixture1Index438,fixture1Index198,fixture1Index224,fixture1Index356,fixture1Index198,fixture1Index358,fixture1Index290,fixture1Index292,fixture1Index288,fixture1Index104]
  ,[fixture1Index0,fixture1Index17,fixture1Index295,fixture1Index297,fixture1Index287,fixture1Index291,fixture1Index317,fixture1Index285,fixture1Index311,fixture1Index439,fixture1Index199,fixture1Index225,fixture1Index357,fixture1Index199,fixture1Index359,fixture1Index291,fixture1Index293,fixture1Index289,fixture1Index105]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index387,fixture1Index385,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index251]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index386,fixture1Index384,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index250]
  ,[fixture1Index167,fixture1Index241,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index251]
  ,[fixture1Index166,fixture1Index240,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index250]
  ,[fixture1Index63,fixture1Index54,fixture1Index155,fixture1Index377,fixture1Index1,fixture1Index90,fixture1Index387,fixture1Index385,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index159,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index495,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index493,fixture1Index159,fixture1Index245,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index497,fixture1Index159,fixture1Index391,fixture1Index1,fixture1Index90,fixture1Index375,fixture1Index1,fixture1Index90,fixture1Index253,fixture1Index245,fixture1Index247,fixture1Index1,fixture1Index90,fixture1Index239,fixture1Index251]
  ,[fixture1Index62,fixture1Index55,fixture1Index154,fixture1Index376,fixture1Index0,fixture1Index91,fixture1Index386,fixture1Index384,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index158,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index494,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index492,fixture1Index158,fixture1Index244,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index496,fixture1Index158,fixture1Index390,fixture1Index0,fixture1Index91,fixture1Index374,fixture1Index0,fixture1Index91,fixture1Index252,fixture1Index244,fixture1Index246,fixture1Index0,fixture1Index91,fixture1Index238,fixture1Index250]
]

noncomputable def fixture1Rows (i : Fin 520) : List (Fin 520) :=
  fixture1RowsArray[i.val]'i.isLt

noncomputable def fixture1Seed (a b : Fin 3) : Fin 520 :=
  match a.val, b.val with
  | 0, 1 => fixture1Index0
  | 0, 2 => fixture1Index2
  | 1, 0 => fixture1Index1
  | 1, 2 => fixture1Index4
  | 2, 0 => fixture1Index3
  | 2, 1 => fixture1Index5
  | _, _ => fixture1Index0

end Psc.GeneratedForwardCarrier
