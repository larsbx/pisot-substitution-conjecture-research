from pathlib import Path
import hashlib, json, os, re, signal, subprocess, time

out = Path(__file__).resolve().parent
source = Path('/workspace/scratch/91efcf4b7b58/psc/proof/PscVerif/PscVerif/NamedForwardCarrierData1.lean')
lean = Path('/tmp/psc-lean/bin/lean')
raw = source.read_bytes()
digest = lambda data: hashlib.sha256(data).hexdigest()
assert digest(raw) == '7770595c93011209cad16d9e0f8acc670f9e24b8aa3dbc74429555f442d84d07'
namespace = raw.index(b'namespace Psc.GeneratedForwardCarrier\n')
substitution = raw.index(b'noncomputable def fixture1Substitution ')
start = raw.index(b'noncomputable def fixture1Chunk0 ')
end = raw.index(b'noncomputable def fixture1Packet ')
included = raw[start:end]
names = re.findall(rb'^noncomputable def ([A-Za-z0-9]+)', included, re.MULTILINE)
assert len(names) == 1536 and len(set(names)) == len(names)
assert all(re.fullmatch(rb'fixture1(?:Chunk[0-9]+|State[0-9]+|StateArray|State|Index[0-9]+|RowsArray|Rows|Seed)', name) for name in names)
assert b'Substitution' not in included and b'Packet' not in included and b'theorem ' not in included
module = raw[namespace:substitution] + included + b'end Psc.GeneratedForwardCarrier\n'
assert b'import ' not in module
(out/'included-declarations.txt').write_bytes(included)
module_path = out/'SharedDataInit.lean'
module_path.write_bytes(module)
object_path = out/'SharedDataInit.olean'
log_path = out/'compile.log'
command = [str(lean), '-o', str(object_path), str(module_path)]
receipt = {'schema':'psc-bounded-lean-data-probe-v1', 'scope':'Exact current shared-index Data1 data declarations under default Init only; no substitution, packet, checker or proof acceptance', 'source':str(source), 'source_sha256_before':digest(raw), 'source_slice_start_byte':start, 'source_slice_end_byte_exclusive':end, 'included_declaration_count':len(names), 'included_declarations_sha256':digest(included), 'module_sha256_before':digest(module), 'lean_binary_sha256':digest(lean.read_bytes()), 'lean_version':subprocess.check_output([str(lean),'--version'],text=True).strip(), 'command':command, 'cwd':str(out), 'wall_budget_seconds':120, 'rss_limit_bytes':3000000000, 'rss_sampling_interval_seconds':0.2, 'max_sampled_rss_bytes':0, 'stop_reason':None}

def tree_rss(pid):
    total = 0
    pending = [pid]
    visited = set()
    while pending:
        current = pending.pop()
        if current in visited:
            continue
        visited.add(current)
        try:
            status = Path(f'/proc/{current}/status').read_text()
            match = re.search(r'^VmRSS:\s+(\d+) kB$',status,re.MULTILINE)
            total += int(match[1])*1024 if match else 0
            pending.extend(map(int,Path(f'/proc/{current}/task/{current}/children').read_text().split()))
        except (FileNotFoundError,ProcessLookupError):
            pass
    return total

started = time.monotonic()
with log_path.open('wb') as log:
    proc = subprocess.Popen(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    receipt['pid'] = proc.pid
    while proc.poll() is None:
        rss = tree_rss(proc.pid)
        receipt['max_sampled_rss_bytes'] = max(receipt['max_sampled_rss_bytes'],rss)
        elapsed = time.monotonic()-started
        reason = 'rss_guard' if rss >= receipt['rss_limit_bytes'] else ('wall_guard' if elapsed >= receipt['wall_budget_seconds'] else None)
        if reason:
            receipt['stop_reason'] = reason
            os.killpg(proc.pid,signal.SIGTERM)
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL)
                proc.wait()
            break
        time.sleep(0.2)
    receipt['return_code'] = proc.wait()
receipt['elapsed_seconds'] = round(time.monotonic()-started,6)
receipt['source_sha256_after'] = digest(source.read_bytes())
receipt['source_unchanged'] = receipt['source_sha256_after']==receipt['source_sha256_before']
receipt['module_sha256_after'] = digest(module_path.read_bytes())
receipt['module_unchanged'] = receipt['module_sha256_after']==receipt['module_sha256_before']
receipt['compile_log_sha256'] = digest(log_path.read_bytes())
receipt['object_exists'] = object_path.is_file()
receipt['object_sha256'] = digest(object_path.read_bytes()) if object_path.is_file() else None
receipt['status'] = 'passed' if receipt['return_code']==0 and receipt['object_exists'] and receipt['source_unchanged'] and receipt['module_unchanged'] else 'stopped_or_failed'
(out/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,indent=2,sort_keys=True),flush=True)
