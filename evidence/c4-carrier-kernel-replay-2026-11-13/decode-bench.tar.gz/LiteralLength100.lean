import Lean
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def word : List (Fin 3) := [0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1]
theorem accepted : word.length = 100 := by decide +kernel
