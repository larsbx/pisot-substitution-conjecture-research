import Lean
namespace DecoderProbe
def decodeDigit (c : Char) : Option (Fin 3) :=
  if c = '0' then some 0 else if c = '1' then some 1 else if c = '2' then some 2 else none
def decodeWord (text : String) : Option (List (Fin 3)) := text.toList.mapM decodeDigit
def word (text : String) : List (Fin 3) := (decodeWord text).getD []
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem accepted : (word "0210211102110010211001021021021100102102111021100102102111021100102102111021100102110010210210211001").length = 100 := by decide +kernel
end DecoderProbe
