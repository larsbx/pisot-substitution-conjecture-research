import Lean
namespace ScanProbe
abbrev Word := List (Fin 3)
abbrev Pair := Word × Word
structure Counter where
  c0 : Int
  c1 : Int
  c2 : Int
  deriving DecidableEq

namespace Counter

def zero : Counter := ⟨0, 0, 0⟩

def get (d : Counter) (c : Fin 3) : Int :=
  if c = 0 then d.c0 else if c = 1 then d.c1 else d.c2

def step (d : Counter) (a b : Fin 3) : Counter :=
  ⟨d.c0 + (if a = 0 then 1 else 0) - (if b = 0 then 1 else 0),
   d.c1 + (if a = 1 then 1 else 0) - (if b = 1 then 1 else 0),
   d.c2 + (if a = 2 then 1 else 0) - (if b = 2 then 1 else 0)⟩

end Counter
def scan : Counter → Word → Word → Bool
  | d, [], [] => decide (d = Counter.zero)
  | d, a :: u, b :: v =>
    decide (u = [] ∨ d.step a b ≠ Counter.zero) && scan (d.step a b) u v
  | _, _, _ => false

def isBlockCheck (T : Pair) : Bool :=
  decide (T.1 ≠ []) && scan Counter.zero T.1 T.2


set_option maxRecDepth 200000
set_option maxHeartbeats 0
def chunk0 : Word := [0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1]
def chunk1 : Word := [0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0]
def chunk2 : Word := [1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1]
def chunk3 : Word := [1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0]
def chunk4 : Word := [0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0]
def chunk5 : Word := [2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0]
def chunk6 : Word := [0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2]
def chunk7 : Word := [1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1]
def chunk8 : Word := [0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0]
def chunk9 : Word := [2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1]
def chunk10 : Word := [0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0]
def chunk11 : Word := [2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1]
def chunk12 : Word := [1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0]
def chunk13 : Word := [1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1]
def chunk14 : Word := [1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1]
def chunk15 : Word := [0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2]
def chunk16 : Word := [1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1]
def chunk17 : Word := [0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1]
def chunk18 : Word := [0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1]
def chunk19 : Word := [0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0]
def chunk20 : Word := [2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0]
def chunk21 : Word := [1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1]
def chunk22 : Word := [0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1]
def chunk23 : Word := [1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1]
def chunk24 : Word := [0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1]
def chunk25 : Word := [0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2]
def chunk26 : Word := [1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0]
def chunk27 : Word := [1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0]
def chunk28 : Word := [2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1]
def chunk29 : Word := [0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0]
def chunk30 : Word := [2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0]
def chunk31 : Word := [2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0]
def chunk32 : Word := [2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1]
def chunk33 : Word := [1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0]
def chunk34 : Word := [1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1]
def chunk35 : Word := [1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0]
def chunk36 : Word := [1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2]
def chunk37 : Word := [1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0]
def chunk38 : Word := [0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2]
def chunk39 : Word := [1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2]
def chunk40 : Word := [1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0]
def chunk41 : Word := [2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0]
def chunk42 : Word := [2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1]
def chunk43 : Word := [0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1]
def chunk44 : Word := [1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1]
def chunk45 : Word := [1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0]
def chunk46 : Word := [1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2]
def chunk47 : Word := [1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1]
def chunk48 : Word := [1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0]
def chunk49 : Word := [2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1]
def chunk50 : Word := [1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0]
def chunk51 : Word := [2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0]
def chunk52 : Word := [2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2]
def chunk53 : Word := [2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1]
def chunk54 : Word := [1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0]
def chunk55 : Word := [0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1]
def chunk56 : Word := [1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0]
def chunk57 : Word := [1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1]
def chunk58 : Word := [0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2]
def chunk59 : Word := [2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1]
def chunk60 : Word := [1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1]
def chunk61 : Word := [1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2]
def chunk62 : Word := [1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0]
def chunk63 : Word := [1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2]
def chunk64 : Word := [1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0]
def chunk65 : Word := [0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2]
def chunk66 : Word := [0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0]
def chunk67 : Word := [2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0]
def chunk68 : Word := [1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2]
def chunk69 : Word := [0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1]
def chunk70 : Word := [1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2]
def chunk71 : Word := [1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1]
def chunk72 : Word := [1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1]
def chunk73 : Word := [0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0]
def chunk74 : Word := [1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1]
def chunk75 : Word := [0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1]
def chunk76 : Word := [0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1]
def chunk77 : Word := [0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1]
def chunk78 : Word := [0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1]
def chunk79 : Word := [0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1]
def chunk80 : Word := [0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1]
def chunk81 : Word := [0,2]
def chunk82 : Word := [0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1]
def chunk83 : Word := [1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0]
def chunk84 : Word := [1,1]
def top : Word := [chunk0,chunk1,chunk2,chunk3,chunk4,chunk5,chunk6,chunk7,chunk8,chunk9,chunk10,chunk11,chunk12,chunk13,chunk14,chunk15,chunk16,chunk17,chunk18,chunk19,chunk20,chunk21,chunk22,chunk23,chunk24,chunk25,chunk26,chunk27,chunk28,chunk29,chunk30,chunk31,chunk32,chunk33,chunk21,chunk34,chunk25,chunk35,chunk36,chunk26,chunk27,chunk28,chunk29,chunk5,chunk6,chunk37,chunk38,chunk39,chunk40,chunk41,chunk42,chunk43,chunk14,chunk15,chunk44,chunk45,chunk20,chunk46,chunk47,chunk48,chunk49,chunk50,chunk41,chunk51,chunk52,chunk16,chunk19,chunk53,chunk45,chunk20,chunk46,chunk54,chunk21,chunk34,chunk55,chunk24,chunk0,chunk1,chunk2,chunk3,chunk4,chunk5,chunk6,chunk7,chunk8,chunk9,chunk10,chunk11,chunk12,chunk13,chunk56,chunk2,chunk57,chunk58,chunk39,chunk40,chunk59,chunk8,chunk9,chunk10,chunk41,chunk51,chunk52,chunk60,chunk15,chunk61,chunk62,chunk31,chunk32,chunk33,chunk21,chunk22,chunk23,chunk24,chunk0,chunk1,chunk63,chunk35,chunk13,chunk3,chunk6,chunk37,chunk38,chunk39,chunk40,chunk41,chunk42,chunk43,chunk14,chunk15,chunk44,chunk45,chunk20,chunk46,chunk47,chunk48,chunk49,chunk23,chunk24,chunk25,chunk64,chunk65,chunk35,chunk27,chunk5,chunk66,chunk67,chunk38,chunk7,chunk10,chunk11,chunk12,chunk13,chunk56,chunk2,chunk3,chunk4,chunk5,chunk6,chunk7,chunk8,chunk9,chunk10,chunk11,chunk12,chunk13,chunk14,chunk15,chunk16,chunk17,chunk18,chunk19,chunk20,chunk21,chunk22,chunk23,chunk24,chunk25,chunk26,chunk27,chunk28,chunk29,chunk30,chunk31,chunk32,chunk33,chunk21,chunk34,chunk25,chunk35,chunk36,chunk26,chunk27,chunk28,chunk29,chunk5,chunk6,chunk37,chunk38,chunk39,chunk40,chunk41,chunk42,chunk43,chunk14,chunk17,chunk57,chunk17,chunk18,chunk19,chunk53,chunk45,chunk31,chunk32,chunk24,chunk25,chunk64,chunk65,chunk68,chunk61,chunk26,chunk2,chunk3,chunk4,chunk5,chunk6,chunk7,chunk8,chunk9,chunk10,chunk41,chunk42,chunk17,chunk69,chunk70,chunk71,chunk46,chunk39,chunk40,chunk59,chunk8,chunk49,chunk72,chunk15,chunk16,chunk17,chunk69,chunk70,chunk71,chunk45,chunk31,chunk32,chunk33,chunk21,chunk34,chunk25,chunk35,chunk36,chunk26,chunk27,chunk28,chunk29,chunk5,chunk6,chunk37,chunk38,chunk39,chunk40,chunk41,chunk42,chunk43,chunk14,chunk15,chunk44,chunk45,chunk20,chunk46,chunk54,chunk21,chunk73,chunk65,chunk68,chunk61,chunk74,chunk75,chunk76,chunk29,chunk5,chunk66,chunk67,chunk38,chunk7,chunk10,chunk11,chunk12,chunk13,chunk14,chunk58,chunk71,chunk46,chunk39,chunk40,chunk59,chunk8,chunk9,chunk10,chunk41,chunk42,chunk17,chunk69,chunk70,chunk71,chunk46,chunk39,chunk46,chunk54,chunk21,chunk22,chunk23,chunk24,chunk25,chunk26,chunk27,chunk28,chunk29,chunk5,chunk77,chunk78,chunk79,chunk0,chunk1,chunk63,chunk35,chunk36,chunk26,chunk2,chunk3,chunk38,chunk7,chunk80,chunk78,chunk79,chunk81].flatten
def bottom : Word := [chunk48,chunk49,chunk50,chunk41,chunk51,chunk52,chunk16,chunk19,chunk53,chunk45,chunk20,chunk46,chunk54,chunk21,chunk34,chunk55,chunk24,chunk0,chunk1,chunk2,chunk3,chunk4,chunk5,chunk6,chunk7,chunk8,chunk9,chunk10,chunk11,chunk12,chunk13,chunk56,chunk2,chunk57,chunk58,chunk39,chunk40,chunk59,chunk8,chunk9,chunk10,chunk41,chunk51,chunk52,chunk60,chunk15,chunk61,chunk62,chunk31,chunk32,chunk33,chunk21,chunk22,chunk23,chunk24,chunk0,chunk1,chunk63,chunk35,chunk13,chunk3,chunk6,chunk37,chunk38,chunk7,chunk80,chunk78,chunk8,chunk49,chunk50,chunk41,chunk51,chunk52,chunk16,chunk19,chunk53,chunk45,chunk31,chunk32,chunk24,chunk25,chunk64,chunk65,chunk68,chunk61,chunk74,chunk75,chunk76,chunk29,chunk32,chunk34,chunk55,chunk24,chunk25,chunk64,chunk65,chunk35,chunk13,chunk56,chunk2,chunk57,chunk58,chunk39,chunk40,chunk59,chunk8,chunk9,chunk10,chunk41,chunk51,chunk52,chunk60,chunk15,chunk61,chunk62,chunk31,chunk32,chunk33,chunk21,chunk34,chunk25,chunk35,chunk36,chunk26,chunk2,chunk3,chunk38,chunk7,chunk80,chunk78,chunk79,chunk0,chunk10,chunk41,chunk42,chunk43,chunk14,chunk15,chunk44,chunk45,chunk20,chunk46,chunk54,chunk21,chunk73,chunk65,chunk68,chunk61,chunk74,chunk75,chunk19,chunk53,chunk45,chunk31,chunk32,chunk24,chunk25,chunk64,chunk65,chunk68,chunk61,chunk26,chunk2,chunk3,chunk4,chunk5,chunk6,chunk7,chunk8,chunk9,chunk10,chunk41,chunk42,chunk17,chunk69,chunk70,chunk71,chunk46,chunk39,chunk40,chunk59,chunk8,chunk49,chunk72,chunk15,chunk16,chunk17,chunk69,chunk70,chunk71,chunk45,chunk31,chunk32,chunk33,chunk21,chunk34,chunk25,chunk35,chunk36,chunk26,chunk27,chunk28,chunk29,chunk5,chunk6,chunk37,chunk38,chunk39,chunk40,chunk41,chunk42,chunk43,chunk14,chunk17,chunk57,chunk17,chunk18,chunk19,chunk53,chunk45,chunk31,chunk32,chunk24,chunk25,chunk64,chunk65,chunk35,chunk27,chunk5,chunk66,chunk67,chunk77,chunk82,chunk34,chunk55,chunk24,chunk0,chunk1,chunk2,chunk3,chunk4,chunk5,chunk66,chunk67,chunk38,chunk39,chunk40,chunk59,chunk8,chunk49,chunk72,chunk15,chunk16,chunk17,chunk69,chunk70,chunk71,chunk45,chunk31,chunk32,chunk33,chunk21,chunk34,chunk25,chunk35,chunk36,chunk26,chunk2,chunk3,chunk38,chunk7,chunk80,chunk78,chunk8,chunk11,chunk14,chunk17,chunk57,chunk58,chunk83,chunk6,chunk71,chunk45,chunk20,chunk46,chunk54,chunk21,chunk73,chunk65,chunk68,chunk61,chunk26,chunk27,chunk67,chunk77,chunk82,chunk34,chunk55,chunk24,chunk25,chunk64,chunk65,chunk35,chunk27,chunk5,chunk66,chunk67,chunk77,chunk82,chunk34,chunk78,chunk8,chunk9,chunk10,chunk41,chunk42,chunk17,chunk69,chunk70,chunk71,chunk46,chunk39,chunk46,chunk54,chunk21,chunk22,chunk23,chunk24,chunk25,chunk26,chunk27,chunk28,chunk29,chunk5,chunk77,chunk78,chunk79,chunk0,chunk10,chunk11,chunk57,chunk58,chunk84].flatten
theorem accepted : isBlockCheck (top,bottom) = true := by decide +kernel
end ScanProbe
