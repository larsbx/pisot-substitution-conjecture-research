import Lean
namespace ScanProbe
abbrev Word := List (Fin 3)
abbrev Pair := Word × Word
structure Counter where
  c0 : Int
  c1 : Int
  c2 : Int
  deriving DecidableEq

namespace Counter

def zero : Counter := ⟨0, 0, 0⟩

def get (d : Counter) (c : Fin 3) : Int :=
  if c = 0 then d.c0 else if c = 1 then d.c1 else d.c2

def step (d : Counter) (a b : Fin 3) : Counter :=
  ⟨d.c0 + (if a = 0 then 1 else 0) - (if b = 0 then 1 else 0),
   d.c1 + (if a = 1 then 1 else 0) - (if b = 1 then 1 else 0),
   d.c2 + (if a = 2 then 1 else 0) - (if b = 2 then 1 else 0)⟩

end Counter
def scan : Counter → Word → Word → Bool
  | d, [], [] => decide (d = Counter.zero)
  | d, a :: u, b :: v =>
    decide (u = [] ∨ d.step a b ≠ Counter.zero) && scan (d.step a b) u v
  | _, _, _ => false

def isBlockCheck (T : Pair) : Bool :=
  decide (T.1 ≠ []) && scan Counter.zero T.1 T.2


set_option maxRecDepth 200000
set_option maxHeartbeats 0
def chunk0 : Word := [0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0]
def chunk1 : Word := [2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2,1,0,2,1]
def chunk2 : Word := [1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,0,2,1,1,1]
def chunk3 : Word := [0,2,1,1,0,0]
def chunk4 : Word := [1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2]
def chunk5 : Word := [1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0,1,0,2]
def chunk6 : Word := [1,0,2,1,1,1,0,2,1,1,0,0,1,0,2,1,1,0,0,1,0,2,1,0,2,1,0,2,1,1,0,0]
def chunk7 : Word := [1,0,2,1,0,2]
def top : Word := [chunk0,chunk1,chunk2,chunk3].flatten
def bottom : Word := [chunk4,chunk5,chunk6,chunk7].flatten
theorem accepted : isBlockCheck (top,bottom) = true := by decide +kernel
end ScanProbe
