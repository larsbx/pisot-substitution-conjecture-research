#!/bin/bash
cd /home/user/pisot-substitution-conjecture-research/mojo
for start in $(seq 0 5000 135000); do
  end=$((start+5000))
  log=/tmp/claude-0/-home-user/08bcf83c-cb65-5d16-8257-f8c4ffee500a/scratchpad/uh4/chunk_$start.log
  if grep -q '^real' $log 2>/dev/null; then continue; fi
  ( time ~/.pixi/bin/pixi run mojo run -I . vertex_coincidence_census.mojo len4 $start $end records ) > $log 2>&1
done
echo ALLDONE > /tmp/claude-0/-home-user/08bcf83c-cb65-5d16-8257-f8c4ffee500a/scratchpad/uh4/done
